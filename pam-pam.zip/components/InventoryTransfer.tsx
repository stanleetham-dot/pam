
import React, { useState } from 'react';
import { useInventory } from '../context/InventoryContext';
import { ArrowRightLeft, Search, MapPin, Scan, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import Scanner from './Scanner';
import { Product } from '../types';

const InventoryTransfer: React.FC = () => {
    const { products, searchProduct, moveProduct } = useInventory();
    
    // Transfer State
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [targetLocation, setTargetLocation] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [scannerOpen, setScannerOpen] = useState(false);
    const [scannerMode, setScannerMode] = useState<'PRODUCT' | 'LOCATION'>('PRODUCT');
    
    // Feedback State
    const [msg, setMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);

    const handleProductSearch = (term: string) => {
        setSearchQuery(term);
        if (!term) { setSelectedProduct(null); return; }
        
        const found = searchProduct(term);
        if (found) {
            setSelectedProduct(found);
            setMsg(null);
        } else {
            setSelectedProduct(null);
            // Don't show error immediately while typing
        }
    };

    const handleTransfer = () => {
        if (!selectedProduct || !targetLocation) {
            setMsg({ type: 'error', text: 'Please select a product and target location.' });
            return;
        }

        if (targetLocation === selectedProduct.location) {
             setMsg({ type: 'error', text: 'New location must be different from current location.' });
             return;
        }

        const result = moveProduct(selectedProduct.barcode, targetLocation);
        
        if (result.success) {
            setMsg({ type: 'success', text: `Successfully moved ${selectedProduct.name} to ${targetLocation}` });
            setSelectedProduct(null);
            setTargetLocation('');
            setSearchQuery('');
        } else {
            setMsg({ type: 'error', text: result.message });
        }
    };

    const handleScan = (code: string) => {
        setScannerOpen(false);
        if (scannerMode === 'PRODUCT') {
            handleProductSearch(code);
        } else {
            setTargetLocation(code.toUpperCase());
        }
    };

    return (
        <div className="p-6 bg-gray-50 min-h-screen">
            <h1 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <ArrowRightLeft className="text-blue-600" /> Inventory Transfer
            </h1>

            {scannerOpen && (
                <Scanner 
                    onScan={handleScan} 
                    onClose={() => setScannerOpen(false)} 
                    title={scannerMode === 'PRODUCT' ? "Scan Product" : "Scan Location Label"}
                    type={scannerMode === 'PRODUCT' ? 'product' : 'location'}
                />
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
                {/* Source Selection */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs">1</span>
                        Select Source Product
                    </h3>
                    
                    <div className="relative mb-6">
                        <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Search Product</label>
                        <div className="relative">
                            <input 
                                className="w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-gray-900"
                                placeholder="Scan SKU, Barcode or Name"
                                value={searchQuery}
                                onChange={e => handleProductSearch(e.target.value)}
                            />
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                            <button 
                                onClick={() => { setScannerMode('PRODUCT'); setScannerOpen(true); }}
                                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-blue-600 p-1"
                            >
                                <Scan size={20} />
                            </button>
                        </div>
                    </div>

                    {selectedProduct ? (
                        <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 animate-in fade-in">
                            <div className="flex gap-4">
                                <div className="w-16 h-16 bg-white rounded-lg border border-blue-100 flex items-center justify-center overflow-hidden shrink-0">
                                    {selectedProduct.imageUrl ? <img src={selectedProduct.imageUrl} className="w-full h-full object-cover" /> : <div className="text-xs text-gray-400">No Img</div>}
                                </div>
                                <div>
                                    <h4 className="font-bold text-gray-900">{selectedProduct.name}</h4>
                                    <p className="text-xs text-gray-500 font-mono mb-1">{selectedProduct.sku}</p>
                                    <div className="flex items-center gap-2 text-sm text-blue-800 font-medium">
                                        <MapPin size={14} /> Current: {selectedProduct.location}
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">Stock: {selectedProduct.stock} {selectedProduct.unit}</p>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="p-8 text-center border-2 border-dashed border-gray-100 rounded-xl bg-gray-50/50">
                            <Search className="mx-auto text-gray-300 mb-2" size={32} />
                            <p className="text-sm text-gray-400">Search or scan a product to begin</p>
                        </div>
                    )}
                </div>

                {/* Destination Selection */}
                <div className={`bg-white p-6 rounded-xl shadow-sm border border-gray-200 transition-opacity ${!selectedProduct ? 'opacity-50 pointer-events-none' : 'opacity-100'}`}>
                    <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs">2</span>
                        Select Destination
                    </h3>

                    <div className="relative mb-6">
                        <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">New Location</label>
                        <div className="relative">
                            <input 
                                className="w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-mono text-gray-900"
                                placeholder="Scan or Type Location"
                                value={targetLocation}
                                onChange={e => setTargetLocation(e.target.value)}
                            />
                            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                            <button 
                                onClick={() => { setScannerMode('LOCATION'); setScannerOpen(true); }}
                                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-blue-600 p-1"
                            >
                                <Scan size={20} />
                            </button>
                        </div>
                    </div>

                    {msg && (
                        <div className={`p-4 rounded-lg mb-6 flex items-start gap-3 ${msg.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
                            {msg.type === 'success' ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
                            <p className="text-sm font-medium">{msg.text}</p>
                        </div>
                    )}

                    <div className="flex justify-end pt-4 border-t border-gray-100">
                        <button 
                            onClick={handleTransfer}
                            disabled={!targetLocation || !selectedProduct}
                            className="px-6 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-md transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            Confirm Transfer <ArrowRight size={18} />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default InventoryTransfer;

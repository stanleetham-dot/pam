
import React, { useState, useEffect, useMemo } from 'react';
import { Product, Transaction, UserProfile, ShelfLog } from '../types';
import { 
  X, Edit2, Save, Box, ArrowRight, Info, 
  Calendar, DollarSign, MapPin, 
  Layers, Scan, CheckCircle2,
  TrendingUp, AlertTriangle, ShieldCheck, ArrowRightLeft,
  ArrowDownToLine, Hourglass, BarChart3, Clock, FileText, AlertCircle,
  Warehouse, History, Package, Hash, Archive, User
} from 'lucide-react';
import Scanner from './Scanner';
import { useInventory } from '../context/InventoryContext';
import { ORIGIN_OPTIONS } from '../constants';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (product: Product, reason?: string) => void;
  transactions: Transaction[];
  currentUser: UserProfile | null;
  initialIsEditing?: boolean;
  allowStockEditing?: boolean;
  showWholesalePrice?: boolean;
  allowEdit?: boolean;
}

type ModalTab = 'OVERVIEW' | 'INVENTORY' | 'HISTORY';

const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  onUpdate,
  transactions,
  currentUser,
  initialIsEditing = false,
  allowStockEditing = false,
  showWholesalePrice = false,
  allowEdit = true
}) => {
  const { shelfLogs, products, inventory } = useInventory(); 
  const [activeTab, setActiveTab] = useState<ModalTab>('OVERVIEW');
  const [isEditing, setIsEditing] = useState(initialIsEditing);
  const [formData, setFormData] = useState<Product | null>(null);
  const [isScanningLocation, setIsScanningLocation] = useState(false);
  const [isScanningBarcode, setIsScanningBarcode] = useState(false);
  
  // Specific Edit States
  const [adjustmentReason, setAdjustmentReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  // Derived Data
  const categories = Array.from(new Set((products || []).map(p => p.category))).filter((c): c is string => !!c).sort();

  useEffect(() => {
    if (product) {
      setFormData({ ...product });
      setIsEditing(initialIsEditing && allowEdit);
      setAdjustmentReason('');
      setError(null);
      setActiveTab('OVERVIEW');
    }
  }, [product, isOpen, initialIsEditing, allowEdit]);

  // --- Logic Hooks ---

  // 1. Warehouse Distribution Calculation
  const warehouseDistribution = useMemo(() => {
      if (!product) return [];
      const dist: Record<string, number> = {};
      
      // Filter inventory items for this product
      const productItems = inventory.filter(i => i.productId === product.id);
      
      if (productItems.length > 0) {
          productItems.forEach(item => {
              const whName = item.warehouse || 'Unassigned';
              dist[whName] = (dist[whName] || 0) + item.quantity;
          });
      } else {
          // Fallback if no detailed inventory items exist yet (legacy data)
          const whName = product.warehouse || 'Main Warehouse';
          dist[whName] = product.stock;
      }

      return Object.entries(dist)
          .map(([name, qty]) => ({ name, qty }))
          .sort((a, b) => b.qty - a.qty);
  }, [inventory, product]);

  // 2. Unified History Timeline (Transactions + Shelf Logs)
  const historyTimeline = useMemo(() => {
      if (!product) return [];
      
      const timeline = [];

      // Add Transactions
      transactions.filter(t => t.productId === product.id).forEach(t => {
          timeline.push({
              id: `TX-${t.id}`,
              date: new Date(t.timestamp),
              type: 'TRANSACTION',
              subtype: t.type,
              title: t.type === 'TRANSFER' ? 'Stock Transfer' : t.type,
              description: t.referenceId || (t.type === 'INBOUND' ? 'Stock In' : 'Stock Out'),
              location: `${t.fromLocation ? t.fromLocation + ' → ' : ''}${t.toLocation || ''}`,
              user: t.user,
              quantity: t.quantity,
              icon: t.type === 'INBOUND' ? ArrowDownToLine : t.type === 'OUTBOUND' ? TrendingUp : ArrowRightLeft,
              color: t.type === 'INBOUND' ? 'text-purple-600 bg-purple-50' : t.type === 'OUTBOUND' ? 'text-green-600 bg-green-50' : 'text-blue-600 bg-blue-50'
          });
      });

      // Add Shelf Logs
      shelfLogs.filter(l => l.productId === product.id).forEach(l => {
          timeline.push({
              id: `LOG-${l.id}`,
              date: new Date(l.timestamp),
              type: 'SHELF',
              subtype: l.method,
              title: 'Shelf Move',
              description: `Method: ${l.method}`,
              location: `${l.oldLocation} → ${l.newLocation}`,
              user: l.operator,
              quantity: null,
              icon: Layers,
              color: 'text-orange-600 bg-orange-50'
          });
      });

      return timeline.sort((a, b) => b.date.getTime() - a.date.getTime());
  }, [transactions, shelfLogs, product]);

  // 3. Expiry Calculations
  const getDaysRemaining = (dateStr?: string) => {
      if (!dateStr || dateStr === 'N/A') return null;
      const today = new Date(); today.setHours(0,0,0,0);
      const exp = new Date(dateStr);
      if (isNaN(exp.getTime())) return null;
      return Math.ceil((exp.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  };

  const getNearestExpiry = () => {
      if (!formData?.expiryLogs || formData.expiryLogs.length === 0) return formData?.expiryDate;
      const activeLogs = formData.expiryLogs
        .filter(l => l.status === 'ACTIVE' && l.expiryDate !== 'N/A')
        .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
      return activeLogs.length > 0 ? activeLogs[0].expiryDate : formData.expiryDate;
  };

  const nearestExpiryDate = getNearestExpiry();
  const daysToNearestExpiry = getDaysRemaining(nearestExpiryDate);

  if (!isOpen || !product || !formData) return null;

  const isStockChanged = formData.stock !== product.stock;

  const handleSave = () => {
    if (formData) {
        if (isStockChanged && !adjustmentReason && allowStockEditing) {
            setError('Please provide a reason for the stock adjustment.');
            return;
        }
        
        // Ensure numbers are numbers
        const cleanData = {
            ...formData,
            standardPrice: Number(formData.standardPrice),
            wholesalePrice: Number(formData.wholesalePrice),
            wholesalePrice2: Number(formData.wholesalePrice2),
            purchasePrice: Number(formData.purchasePrice),
            stock: Number(formData.stock),
            shelfLife: Number(formData.shelfLife),
        };

        onUpdate(cleanData, isStockChanged ? adjustmentReason : undefined);
        setIsEditing(false);
        setError(null);
    }
  };

  const formatDateReadable = (dateStr?: string) => {
    if (!dateStr || dateStr === 'N/A' || dateStr === '-' || !dateStr.trim()) return '-';
    try {
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch { return dateStr; }
  };

  const inputClass = "w-full bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm font-medium text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-colors disabled:bg-gray-100 disabled:text-gray-500";
  const labelClass = "block text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-1.5";

  return (
    <div className="fixed inset-0 bg-slate-900/60 z-[60] flex items-center justify-center p-4 backdrop-blur-md transition-colors">
      {isScanningLocation && <Scanner onScan={(code) => { setFormData({...formData, location: code}); setIsScanningLocation(false); }} onClose={() => setIsScanningLocation(false)} title="Scan Location" type="location" />}
      {isScanningBarcode && <Scanner onScan={(code) => { setFormData({...formData, barcode: code}); setIsScanningBarcode(false); }} onClose={() => setIsScanningBarcode(false)} title="Scan Barcode" type="product" />}
      
      <div className="bg-white dark:bg-slate-900 rounded-[2rem] w-full max-w-6xl shadow-2xl flex flex-col h-[90vh] overflow-hidden animate-in zoom-in-95 border border-white/20 dark:border-slate-800">
        
        {/* --- HEADER --- */}
        <div className="bg-white dark:bg-slate-900 border-b border-gray-100 dark:border-slate-800 p-6 flex flex-col md:flex-row justify-between items-start gap-6 shrink-0 transition-colors">
          <div className="flex gap-6 items-start flex-1 w-full">
            {/* Image */}
            <div className="w-28 h-28 rounded-2xl bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 flex items-center justify-center overflow-hidden shadow-sm shrink-0 relative group">
               {formData.imageUrl ? <img src={formData.imageUrl} className="w-full h-full object-cover" /> : <Box size={40} className="text-gray-300 dark:text-gray-600" />}
               {isEditing && (
                   <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                       <span className="text-white text-xs font-bold">Change URL</span>
                   </div>
               )}
            </div>
            
            {/* Title & Key Stats */}
            <div className="flex-1 min-w-0">
              <div className="flex flex-col gap-1 mb-3">
                {isEditing ? (
                    <input 
                        className="text-2xl font-black text-gray-900 dark:text-white bg-transparent border-b-2 border-blue-500 outline-none w-full" 
                        value={formData.name} 
                        onChange={e => setFormData({...formData, name: e.target.value})}
                        placeholder="Product Name"
                    />
                ) : (
                    <h2 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight leading-tight">{formData.name}</h2>
                )}
                
                <div className="flex flex-wrap items-center gap-2 mt-1">
                    {/* Category Badge */}
                    {isEditing ? (
                        <select className="bg-gray-100 dark:bg-slate-800 border-none rounded-lg px-2 py-1 text-xs font-bold outline-none" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                            {categories.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-slate-700">
                            {formData.category}
                        </span>
                    )}

                    {/* Stock Status Badge */}
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold border ${formData.stock > 20 ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-400' : formData.stock > 0 ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400' : 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400'}`}>
                        {formData.stock > 0 ? <CheckCircle2 size={10}/> : <AlertCircle size={10}/>}
                        {formData.stock > 20 ? 'In Stock' : formData.stock > 0 ? 'Low Stock' : 'Out of Stock'}
                    </span>

                    {/* Expiry Status Badge */}
                    {daysToNearestExpiry !== null && (
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold border ${daysToNearestExpiry < 0 ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-900/20 dark:text-rose-400' : daysToNearestExpiry < 30 ? 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/20 dark:text-orange-400' : 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400'}`}>
                            <Clock size={10} />
                            {daysToNearestExpiry < 0 ? 'Expired' : `${daysToNearestExpiry} Days Left`}
                        </span>
                    )}
                </div>
              </div>
              
              <div className="flex items-center gap-4 text-xs font-bold text-gray-400 dark:text-gray-500">
                <div className="flex items-center gap-2 bg-gray-50 dark:bg-slate-800/50 px-3 py-1.5 rounded-lg border border-gray-100 dark:border-slate-800">
                    <Scan size={14} className="text-gray-400" />
                    {isEditing ? (
                        <div className="flex items-center gap-2">
                            <input className="bg-transparent outline-none w-24" value={formData.barcode} onChange={e => setFormData({...formData, barcode: e.target.value})} />
                            <button onClick={() => setIsScanningBarcode(true)}><Scan size={12} className="text-blue-500"/></button>
                        </div>
                    ) : (
                        <span className="font-mono text-gray-600 dark:text-gray-300">{formData.barcode}</span>
                    )}
                </div>
                <div className="flex items-center gap-2 bg-gray-50 dark:bg-slate-800/50 px-3 py-1.5 rounded-lg border border-gray-100 dark:border-slate-800">
                    <Hash size={14} className="text-gray-400" />
                    {isEditing ? (
                        <input className="bg-transparent outline-none w-24" value={formData.sku} onChange={e => setFormData({...formData, sku: e.target.value})} />
                    ) : (
                        <span className="font-mono text-gray-600 dark:text-gray-300">{formData.sku}</span>
                    )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3 items-end">
             {isEditing ? (
                 <button onClick={handleSave} className="px-6 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-all flex items-center gap-2 shadow-lg shadow-blue-200 dark:shadow-none active:scale-95"><Save size={18} /> Save Changes</button>
             ) : (
                 allowEdit && (
                    <button onClick={() => setIsEditing(true)} className="px-5 py-2.5 bg-gray-900 dark:bg-white text-white dark:text-gray-900 font-bold rounded-xl hover:bg-gray-800 dark:hover:bg-gray-200 transition-all flex items-center gap-2 shadow-md"><Edit2 size={16} /> Edit Product</button>
                 )
             )}
             <button onClick={onClose} className="p-2.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full transition-colors"><X size={24} /></button>
          </div>
        </div>

        {/* --- TABS --- */}
        <div className="flex border-b border-gray-200 dark:border-slate-800 px-6 bg-white dark:bg-slate-900">
            {[
                { id: 'OVERVIEW', label: 'Overview', icon: FileText },
                { id: 'INVENTORY', label: 'Inventory & Expiry', icon: Layers },
                { id: 'HISTORY', label: 'History & Logs', icon: History },
            ].map(tab => (
                <button 
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as ModalTab)}
                    className={`flex items-center gap-2 px-6 py-4 text-sm font-bold border-b-2 transition-all ${activeTab === tab.id ? 'border-blue-600 text-blue-600 dark:text-blue-400' : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-500 dark:hover:text-gray-300'}`}
                >
                    <tab.icon size={16} /> {tab.label}
                </button>
            ))}
        </div>

        {/* --- CONTENT --- */}
        <div className="flex-1 overflow-y-auto p-8 bg-gray-50 dark:bg-slate-950/50 scroll-smooth">
            
            {/* TAB: OVERVIEW */}
            {activeTab === 'OVERVIEW' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in slide-in-from-bottom-4">
                    
                    {/* Left: General Info */}
                    <div className="lg:col-span-2 space-y-8">
                        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800">
                            <h4 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-6 border-b border-gray-100 dark:border-slate-800 pb-2">
                                <Info size={18} className="text-blue-500"/> General Information
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label className={labelClass}>Product Brand</label>
                                    {isEditing ? (
                                        <input className={inputClass} value={formData.brand} onChange={e => setFormData({...formData,brand: e.target.value})} />
                                    ) : (
                                        <p className="text-base font-medium text-gray-900 dark:text-white">{formData.brand || '-'}</p>
                                    )}
                                </div>
                                <div>
                                    <label className={labelClass}>Origin</label>
                                    {isEditing ? (
                                        <select className={inputClass} value={formData.origin} onChange={e => setFormData({...formData, origin: e.target.value})}>
                                            <option value="">Select Origin</option>
                                            {ORIGIN_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                                        </select>
                                    ) : (
                                        <div className="flex items-center gap-2">
                                            <MapPin size={14} className="text-gray-400" />
                                            <p className="text-base font-medium text-gray-900 dark:text-white">{formData.origin || '-'}</p>
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <label className={labelClass}>Specification</label>
                                    {isEditing ? (
                                        <input className={inputClass} value={formData.specification} onChange={e => setFormData({...formData, specification: e.target.value})} />
                                    ) : (
                                        <p className="text-base font-medium text-gray-900 dark:text-white">{formData.specification || '-'}</p>
                                    )}
                                </div>
                                <div>
                                    <label className={labelClass}>Base Unit</label>
                                    {isEditing ? (
                                        <select className={inputClass} value={formData.unit} onChange={e => setFormData({...formData, unit: e.target.value})}>
                                            <option value="PCS">PCS</option><option value="BOX">BOX</option><option value="KG">KG</option><option value="CTN">CTN</option><option value="SET">SET</option>
                                        </select>
                                    ) : (
                                        <p className="text-base font-medium text-gray-900 dark:text-white">{formData.unit || '-'}</p>
                                    )}
                                </div>
                                <div className="md:col-span-2">
                                    <label className={labelClass}>Description / Notes</label>
                                    {isEditing ? (
                                        <textarea className={inputClass} rows={3} value={formData.description || ''} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Enter detailed product description..." />
                                    ) : (
                                        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{formData.description || 'No description provided.'}</p>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Shelf Life Config */}
                        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800">
                            <h4 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-6 border-b border-gray-100 dark:border-slate-800 pb-2">
                                <Hourglass size={18} className="text-orange-500"/> Shelf Life Rules
                            </h4>
                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className={labelClass}>Shelf Life (Months)</label>
                                    {isEditing ? (
                                        <input type="number" className={inputClass} value={formData.shelfLife} onChange={e => setFormData({...formData, shelfLife: Number(e.target.value)})} />
                                    ) : (
                                        <p className="text-base font-medium text-gray-900 dark:text-white">{formData.shelfLife ? `${formData.shelfLife} Months` : 'Not Set'}</p>
                                    )}
                                </div>
                                <div>
                                    <label className={labelClass}>Manufacturing Date</label>
                                    {isEditing ? (
                                        <input type="date" className={inputClass} value={formData.mfgDate} onChange={e => setFormData({...formData, mfgDate: e.target.value})} />
                                    ) : (
                                        <p className="text-base font-medium text-gray-900 dark:text-white">{formatDateReadable(formData.mfgDate)}</p>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Right: Pricing & Quick Stock Edit */}
                    <div className="space-y-8">
                        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800">
                            <h4 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-6 border-b border-gray-100 dark:border-slate-800 pb-2">
                                <DollarSign size={18} className="text-green-500"/> Financials
                            </h4>
                            <div className="space-y-4">
                                <div className="flex justify-between items-center py-2 border-b border-dashed border-gray-100 dark:border-slate-800">
                                    <span className="text-sm text-gray-500 dark:text-gray-400">Standard Price</span>
                                    {isEditing ? (
                                        <input type="number" step="0.01" className="w-24 text-right bg-gray-50 dark:bg-slate-800 border rounded px-2 py-1 text-sm font-bold" value={formData.standardPrice} onChange={e => setFormData({...formData, standardPrice: parseFloat(e.target.value) || 0})} />
                                    ) : (
                                        <span className="text-lg font-black text-gray-900 dark:text-white">${Number(formData.standardPrice).toFixed(2)}</span>
                                    )}
                                </div>
                                {showWholesalePrice && (
                                    <>
                                        <div className="flex justify-between items-center py-2 border-b border-dashed border-gray-100 dark:border-slate-800">
                                            <span className="text-sm text-gray-500 dark:text-gray-400">Wholesale 1</span>
                                            {isEditing ? (
                                                <input type="number" step="0.01" className="w-24 text-right bg-gray-50 dark:bg-slate-800 border rounded px-2 py-1 text-sm font-bold" value={formData.wholesalePrice} onChange={e => setFormData({...formData, wholesalePrice: parseFloat(e.target.value) || 0})} />
                                            ) : (
                                                <span className="text-base font-bold text-gray-700 dark:text-gray-300">${Number(formData.wholesalePrice).toFixed(2)}</span>
                                            )}
                                        </div>
                                        <div className="flex justify-between items-center py-2 border-b border-dashed border-gray-100 dark:border-slate-800">
                                            <span className="text-sm text-gray-500 dark:text-gray-400">Wholesale 2</span>
                                            {isEditing ? (
                                                <input type="number" step="0.01" className="w-24 text-right bg-gray-50 dark:bg-slate-800 border rounded px-2 py-1 text-sm font-bold" value={formData.wholesalePrice2} onChange={e => setFormData({...formData, wholesalePrice2: parseFloat(e.target.value) || 0})} />
                                            ) : (
                                                <span className="text-base font-bold text-gray-700 dark:text-gray-300">${Number(formData.wholesalePrice2).toFixed(2)}</span>
                                            )}
                                        </div>
                                    </>
                                )}
                                {(currentUser?.role === 'ADMIN' || currentUser?.role === 'MANAGER') && (
                                    <div className="flex justify-between items-center py-2 bg-yellow-50 dark:bg-yellow-900/10 px-3 rounded-lg mt-2">
                                        <span className="text-xs font-bold text-yellow-800 dark:text-yellow-500 uppercase">Cost Price</span>
                                        {isEditing ? (
                                            <input type="number" step="0.01" className="w-24 text-right bg-white dark:bg-slate-900 border rounded px-2 py-1 text-sm font-bold" value={formData.purchasePrice} onChange={e => setFormData({...formData, purchasePrice: parseFloat(e.target.value) || 0})} />
                                        ) : (
                                            <span className="text-sm font-bold text-yellow-700 dark:text-yellow-400">${Number(formData.purchasePrice).toFixed(2)}</span>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Quick Stock Location */}
                        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800">
                            <h4 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                                <MapPin size={18} className="text-purple-500"/> Current Location
                            </h4>
                            {isEditing ? (
                                <div className="flex gap-2">
                                    <input className={inputClass} value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} />
                                    <button onClick={() => setIsScanningLocation(true)} className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-200 transition-colors"><Scan size={20} /></button>
                                </div>
                            ) : (
                                <div className="text-center py-4 bg-gray-50 dark:bg-slate-900/50 rounded-xl border border-dashed border-gray-200 dark:border-slate-700">
                                    <p className="text-3xl font-black text-gray-900 dark:text-white tracking-wide font-mono">{formData.location}</p>
                                    <p className="text-xs text-gray-400 dark:text-gray-500 uppercase font-bold mt-1">Bin / Shelf ID</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* TAB: INVENTORY */}
            {activeTab === 'INVENTORY' && (
                <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Stock Counter */}
                        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex items-center justify-between">
                            <div>
                                <p className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-2">Total Physical Stock</p>
                                {isEditing && allowStockEditing ? (
                                    <div className="flex items-center gap-2">
                                        <input type="number" className="w-32 text-3xl font-black bg-transparent border-b-2 border-blue-500 outline-none text-gray-900 dark:text-white" value={formData.stock} onChange={e => setFormData({...formData, stock: parseInt(e.target.value) || 0})} />
                                        <span className="text-sm font-bold text-gray-400">{formData.unit}</span>
                                    </div>
                                ) : (
                                    <h3 className="text-4xl font-black text-gray-900 dark:text-white">{formData.stock} <span className="text-sm font-medium text-gray-400">{formData.unit}</span></h3>
                                )}
                                {isStockChanged && isEditing && (
                                    <div className="mt-2">
                                        <input className="w-full text-xs border-b border-gray-200 bg-transparent py-1 outline-none text-red-500 placeholder:text-red-300" placeholder="Required: Adjustment Reason" value={adjustmentReason} onChange={e => setAdjustmentReason(e.target.value)} />
                                    </div>
                                )}
                            </div>
                            <div className="w-16 h-16 rounded-full bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600 dark:text-blue-400">
                                <Box size={32} />
                            </div>
                        </div>

                        {/* Nearest Expiry Highlight */}
                        <div className={`p-6 rounded-2xl shadow-sm border flex items-center justify-between ${daysToNearestExpiry && daysToNearestExpiry < 30 ? 'bg-red-50 border-red-100 dark:bg-red-900/10 dark:border-red-900/30' : 'bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800'}`}>
                            <div>
                                <p className={`text-xs font-bold uppercase tracking-wider mb-2 ${daysToNearestExpiry && daysToNearestExpiry < 30 ? 'text-red-500' : 'text-gray-400 dark:text-gray-500'}`}>Nearest Expiration</p>
                                <h3 className={`text-3xl font-black ${daysToNearestExpiry && daysToNearestExpiry < 30 ? 'text-red-700 dark:text-red-400' : 'text-gray-900 dark:text-white'}`}>
                                    {formatDateReadable(nearestExpiryDate)}
                                </h3>
                                <p className="text-sm font-medium mt-1 opacity-70">
                                    {daysToNearestExpiry !== null ? (daysToNearestExpiry < 0 ? `${Math.abs(daysToNearestExpiry)} Days Overdue` : `${daysToNearestExpiry} Days Remaining`) : 'No Expiry Set'}
                                </p>
                            </div>
                            <div className={`w-16 h-16 rounded-full flex items-center justify-center ${daysToNearestExpiry && daysToNearestExpiry < 30 ? 'bg-white/50 text-red-600' : 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400'}`}>
                                <Calendar size={32} />
                            </div>
                        </div>
                    </div>

                    {/* Warehouse Distribution */}
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-6">
                        <h4 className="text-sm font-bold text-gray-800 dark:text-white flex items-center gap-2 mb-4">
                            <Warehouse size={16} className="text-blue-500"/> Warehouse Distribution
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {warehouseDistribution.length > 0 ? (
                                warehouseDistribution.map((w, idx) => (
                                    <div key={idx} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-slate-950/50 rounded-lg border border-gray-100 dark:border-slate-800">
                                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{w.name}</span>
                                        <span className="text-sm font-bold text-gray-900 dark:text-white bg-white dark:bg-slate-800 px-2 py-1 rounded shadow-sm">
                                            {w.qty}
                                        </span>
                                    </div>
                                ))
                            ) : (
                                <p className="text-sm text-gray-400 dark:text-gray-500 italic">No distribution data available.</p>
                            )}
                        </div>
                    </div>

                    {/* Expiry Logs Table */}
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden">
                        <div className="p-5 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50">
                            <h4 className="text-sm font-bold text-gray-800 dark:text-white flex items-center gap-2">
                                <Layers size={16} className="text-blue-500"/> Batch & Expiry Records
                            </h4>
                            <span className="text-xs font-bold text-gray-400 bg-white dark:bg-slate-800 px-2 py-1 rounded border border-gray-200 dark:border-slate-700">
                                {formData.expiryLogs?.length || 0} Records
                            </span>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-gray-50 dark:bg-slate-950 text-gray-500 dark:text-gray-400 uppercase font-bold text-xs">
                                    <tr>
                                        <th className="px-6 py-4">Status</th>
                                        <th className="px-6 py-4">Batch Number</th>
                                        <th className="px-6 py-4">Expiry Date</th>
                                        <th className="px-6 py-4">Mfg Date</th>
                                        <th className="px-6 py-4 text-right">Quantity</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                                    {formData.expiryLogs && formData.expiryLogs.length > 0 ? (
                                        formData.expiryLogs.sort((a,b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime()).map(log => {
                                            const days = getDaysRemaining(log.expiryDate);
                                            const isExpired = days !== null && days < 0;
                                            const isUrgent = days !== null && days <= 30 && days >= 0;
                                            
                                            return (
                                                <tr key={log.id} className="hover:bg-blue-50/30 dark:hover:bg-blue-900/10 transition-colors">
                                                    <td className="px-6 py-4">
                                                        {log.status === 'REMOVED' ? (
                                                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-slate-700">
                                                                <Archive size={10} /> Archived
                                                            </span>
                                                        ) : isExpired ? (
                                                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/20 dark:text-red-400">
                                                                <AlertTriangle size={10} /> Expired
                                                            </span>
                                                        ) : isUrgent ? (
                                                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-900/20 dark:text-amber-400">
                                                                <Clock size={10} /> Urgent
                                                            </span>
                                                        ) : (
                                                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/20 dark:text-green-400">
                                                                <CheckCircle2 size={10} /> Active
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4 font-mono font-bold text-gray-700 dark:text-gray-300">{log.batchNumber || '-'}</td>
                                                    <td className="px-6 py-4">
                                                        <div className="font-medium text-gray-900 dark:text-white">{formatDateReadable(log.expiryDate)}</div>
                                                        {log.status === 'ACTIVE' && !isExpired && (
                                                            <div className="text-[10px] text-gray-400 font-medium">{days} days remaining</div>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4 text-gray-600 dark:text-gray-400">{formatDateReadable(log.mfgDate)}</td>
                                                    <td className="px-6 py-4 text-right font-black text-gray-900 dark:text-white tabular-nums">{log.quantity}</td>
                                                </tr>
                                            );
                                        })
                                    ) : (
                                        <tr>
                                            <td colSpan={5} className="py-12 text-center text-gray-400 dark:text-gray-500 italic">No expiry records found for this product.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

            {/* TAB: HISTORY */}
            {activeTab === 'HISTORY' && (
                <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800">
                        <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex items-center justify-between">
                            <h4 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                                <History size={18} className="text-purple-500"/> Audit Timeline
                            </h4>
                        </div>
                        <div className="max-h-[600px] overflow-y-auto p-4 no-scrollbar space-y-4">
                            {historyTimeline.length > 0 ? (
                                historyTimeline.map(item => (
                                    <div key={item.id} className="flex gap-4 p-4 hover:bg-gray-50 dark:hover:bg-slate-800/50 rounded-xl transition-colors border border-gray-100 dark:border-slate-800">
                                        <div className={`mt-1 w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${item.color}`}>
                                            <item.icon size={20} />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <h5 className="text-sm font-bold text-gray-900 dark:text-white">{item.title}</h5>
                                                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{item.description}</p>
                                                </div>
                                                <span className="text-[10px] font-medium text-gray-400 dark:text-gray-500">
                                                    {item.date.toLocaleString()}
                                                </span>
                                            </div>
                                            <div className="mt-2 flex items-center gap-4 text-xs">
                                                <span className="font-mono text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-slate-800 px-2 py-1 rounded">
                                                    {item.location}
                                                </span>
                                                <span className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                                                    <User size={10} /> {item.user || 'System'}
                                                </span>
                                                {item.quantity !== null && (
                                                    <span className={`font-bold ml-auto ${item.quantity > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                                        {item.quantity > 0 ? '+' : ''}{item.quantity} Units
                                                    </span>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <div className="py-20 text-center text-gray-400 dark:text-gray-500">
                                    <History size={48} className="mx-auto mb-3 opacity-20" />
                                    <p>No history available.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

        </div>

        {/* Footer Info */}
        <div className="bg-gray-50 dark:bg-slate-900 border-t border-gray-200 dark:border-slate-800 px-8 py-3 flex justify-between items-center text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase shrink-0">
          <div className="flex items-center gap-4">
             <span className="flex items-center gap-1"><ShieldCheck size={12} className="text-emerald-500"/> System Verified</span>
             <span>Last Audit: {formatDateReadable(product.updatedAt)}</span>
          </div>
          <div className="font-mono">UUID: {product.id}</div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailModal;

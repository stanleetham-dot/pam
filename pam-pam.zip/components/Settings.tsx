
import React, { useState } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    Lock, Globe, RefreshCcw, Trash2, Sun, Moon, 
    Zap, ChevronRight, CheckCircle2,
    Loader2, Save, ArrowLeft
} from 'lucide-react';

const Toggle: React.FC<{ checked: boolean; onChange: (val: boolean) => void; colorClass?: string }> = ({ checked, onChange, colorClass = 'bg-blue-600' }) => (
    <button 
        onClick={() => onChange(!checked)}
        className={`w-12 h-6 rounded-full transition-colors duration-300 ease-in-out relative focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-200 ${checked ? colorClass : 'bg-gray-200'}`}
    >
        <span 
            className={`block w-5 h-5 bg-white rounded-full shadow-sm transform transition-transform duration-300 ease-in-out absolute top-0.5 left-0.5 ${checked ? 'translate-x-6' : 'translate-x-0'}`} 
        />
    </button>
);

interface SettingsProps {
    embedded?: boolean;
}

const Settings: React.FC<SettingsProps> = ({ embedded = false }) => {
    const { currentUser, changePassword, theme, setGlobalTheme, language, setGlobalLanguage } = useInventory();
    
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    // View State
    const [view, setView] = useState<'MAIN' | 'PASSWORD'>('MAIN');

    // Setting States
    const [infraredEnabled, setInfraredEnabled] = useState(true);
    
    // Action States
    const [checkingUpdate, setCheckingUpdate] = useState(false);
    const [updateMsg, setUpdateMsg] = useState('');
    const [clearingCache, setClearingCache] = useState(false);
    
    // Password Form State
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [passMsg, setPassMsg] = useState<{type: 'success'|'error', text: string} | null>(null);

    const handleCheckUpdate = () => {
        setCheckingUpdate(true);
        setUpdateMsg('');
        setTimeout(() => {
            setCheckingUpdate(false);
            setUpdateMsg(t('App is up to date (v1.2.4)', '应用已是最新版本 (v1.2.4)'));
            setTimeout(() => setUpdateMsg(''), 3000);
        }, 1500);
    };

    const handleClearCache = () => {
        if(window.confirm(t("Are you sure? This will clear local preferences.", "确定吗？这将清除本地偏好设置。"))) {
            setClearingCache(true);
            setTimeout(() => {
                localStorage.removeItem('nexus_sidebar_expanded');
                localStorage.removeItem('nexus_login_history');
                setClearingCache(false);
                alert(t("Cache cleared successfully.", "缓存清除成功。"));
            }, 1000);
        }
    };

    const handlePasswordSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newPassword !== confirmPassword) {
            setPassMsg({type: 'error', text: t('Passwords do not match', '密码不匹配')});
            return;
        }
        if (newPassword.length < 6) {
            setPassMsg({type: 'error', text: t('Password must be at least 6 characters', '密码至少需要6个字符')});
            return;
        }
        changePassword(newPassword);
        setPassMsg({type: 'success', text: t('Password updated successfully', '密码更新成功')});
        setNewPassword('');
        setConfirmPassword('');
        setTimeout(() => {
            setPassMsg(null);
            setView('MAIN');
        }, 1500);
    };

    const containerClasses = embedded 
        ? "p-4 bg-gray-50 dark:bg-slate-950 transition-colors h-full overflow-y-auto"
        : "p-6 md:p-10 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors";

    if (view === 'PASSWORD') {
        return (
            <div className={containerClasses}>
                <div className="max-w-xl mx-auto">
                    <button onClick={() => setView('MAIN')} className="mb-6 flex items-center gap-2 text-gray-500 hover:text-gray-800 dark:hover:text-gray-300 font-medium transition-colors">
                        <ArrowLeft size={20} /> {t('Back to Settings', '返回设置')}
                    </button>
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-8">
                        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-1">{t('Change Password', '修改密码')}</h2>
                        <p className="text-gray-500 text-sm mb-6">{t('Update credentials for', '更新凭证')} @{currentUser?.username}</p>
                        
                        <form onSubmit={handlePasswordSubmit} className="space-y-5">
                            <div>
                                <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1.5">{t('New Password', '新密码')}</label>
                                <input 
                                    type="password"
                                    value={newPassword}
                                    onChange={e => setNewPassword(e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-gray-900"
                                    placeholder={t('Enter new password', '输入新密码')}
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1.5">{t('Confirm Password', '确认密码')}</label>
                                <input 
                                    type="password"
                                    value={confirmPassword}
                                    onChange={e => setConfirmPassword(e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-gray-900"
                                    placeholder={t('Confirm new password', '确认新密码')}
                                    required
                                />
                            </div>
                            
                            {passMsg && (
                                <div className={`p-4 rounded-xl text-sm flex items-center gap-2 font-medium ${passMsg.type === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100'}`}>
                                    <CheckCircle2 size={18} />
                                    {passMsg.text}
                                </div>
                            )}

                            <button type="submit" className="w-full py-3.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-blue-900/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2">
                                <Save size={18} /> {t('Update Password', '更新密码')}
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className={containerClasses}>
            <div className="max-w-2xl mx-auto">
                {!embedded && (
                    <>
                        <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">{t('Settings', '设置')}</h1>
                        <p className="text-gray-500 mb-8">{t('Manage app preferences and account security', '管理应用偏好和账户安全')}</p>
                    </>
                )}

                <div className="space-y-6">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden">
                        <div 
                            onClick={() => setView('PASSWORD')}
                            className="flex items-center justify-between p-5 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors cursor-pointer border-b border-gray-100 dark:border-slate-800 group"
                        >
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                                    <Lock size={20} />
                                </div>
                                <span className="font-bold text-gray-700 dark:text-gray-200">{t('Change Password', '修改密码')}</span>
                            </div>
                            <ChevronRight size={20} className="text-gray-400 group-hover:text-gray-600 dark:group-hover:text-gray-300" />
                        </div>

                        <div className="flex items-center justify-between p-5 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors border-b border-gray-100 dark:border-slate-800">
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                                    <Globe size={20} />
                                </div>
                                <span className="font-bold text-gray-700 dark:text-gray-200">{t('Language', '语言')}</span>
                            </div>
                            <div className="flex items-center gap-2 bg-gray-100 dark:bg-slate-800 p-1 rounded-lg">
                                <button 
                                    onClick={() => setGlobalLanguage('EN')}
                                    className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${language === 'EN' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:text-gray-400'}`}
                                >
                                    English
                                </button>
                                <button 
                                    onClick={() => setGlobalLanguage('ZH')}
                                    className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${language === 'ZH' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:text-gray-400'}`}
                                >
                                    中文
                                </button>
                            </div>
                        </div>

                        <div className="flex items-center justify-between p-5 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
                            <div className="flex items-center gap-4">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${theme === 'light' ? 'bg-orange-50 text-orange-500' : 'bg-indigo-900/30 text-indigo-400'}`}>
                                    {theme === 'light' ? <Sun size={20} /> : <Moon size={20} />}
                                </div>
                                <span className="font-bold text-gray-700 dark:text-gray-200">{t('Dark Mode', '深色模式')}</span>
                            </div>
                            <Toggle checked={theme === 'dark'} onChange={(val) => setGlobalTheme(val ? 'dark' : 'light')} colorClass="bg-indigo-600" />
                        </div>
                    </div>

                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden">
                        <div 
                            onClick={handleCheckUpdate}
                            className="flex items-center justify-between p-5 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors cursor-pointer border-b border-gray-100 dark:border-slate-800"
                        >
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 flex items-center justify-center">
                                    <RefreshCcw size={20} className={checkingUpdate ? 'animate-spin' : ''} />
                                </div>
                                <div>
                                    <span className="font-bold text-gray-700 dark:text-gray-200 block">{t('Check for Updates', '检查更新')}</span>
                                    {updateMsg && <span className="text-xs text-green-600 font-medium animate-in fade-in">{updateMsg}</span>}
                                </div>
                            </div>
                            {checkingUpdate ? <Loader2 size={20} className="animate-spin text-gray-400" /> : <ChevronRight size={20} className="text-gray-400" />}
                        </div>

                        <div 
                            onClick={handleClearCache}
                            className="flex items-center justify-between p-5 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        >
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 flex items-center justify-center">
                                    <Trash2 size={20} />
                                </div>
                                <span className="font-bold text-gray-700 dark:text-gray-200">{t('Clear Cache', '清除缓存')}</span>
                            </div>
                            {clearingCache ? <Loader2 size={20} className="animate-spin text-gray-400" /> : <span className="text-xs font-bold text-gray-400 bg-gray-100 dark:bg-slate-800 px-2 py-1 rounded">24 MB</span>}
                        </div>
                    </div>

                    <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl shadow-lg shadow-blue-200 dark:shadow-blue-900/20 text-white overflow-hidden p-1">
                        <div className="flex items-center justify-between p-5 bg-white/10 rounded-xl backdrop-blur-sm">
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-white shadow-inner">
                                    <Zap size={22} fill="currentColor" />
                                </div>
                                <div>
                                    <span className="font-bold text-lg block">{t('Infrared Scanning', '红外扫描')}</span>
                                    <span className="text-blue-100 text-xs opacity-90">{t('Enhanced barcode detection', '增强型条码检测')}</span>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                <span className="text-xs font-bold uppercase tracking-wider opacity-80">{infraredEnabled ? 'ON' : 'OFF'}</span>
                                <button 
                                    onClick={() => setInfraredEnabled(!infraredEnabled)}
                                    className={`w-14 h-8 rounded-full transition-all duration-300 ease-in-out relative border-2 border-transparent ${infraredEnabled ? 'bg-white' : 'bg-blue-900/50'}`}
                                >
                                    <span 
                                        className={`block w-6 h-6 rounded-full shadow-md transform transition-transform duration-300 ease-in-out absolute top-0.5 left-0.5 ${infraredEnabled ? 'translate-x-6 bg-blue-600' : 'translate-x-0 bg-white'}`} 
                                    />
                                </button>
                            </div>
                        </div>
                    </div>

                    <div className="text-center text-xs text-gray-400 pt-8 pb-4">
                        Pam Pam WMS v1.2.4 • Build 2026.01.01
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Settings;

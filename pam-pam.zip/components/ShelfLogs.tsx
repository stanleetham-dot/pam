import React, { useState, useMemo, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    Search, MapPin, Calendar, User, 
    ArrowRight, Filter, FileDown, 
    Layers, Scan, RefreshCcw, Package,
    Clock, Database, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight
} from 'lucide-react';
import * as XLSX from 'xlsx';

const ShelfLogs: React.FC = () => {
    const { shelfLogs } = useInventory();
    const [searchTerm, setSearchTerm] = useState('');
    const [methodFilter, setMethodFilter] = useState('ALL');
    
    // Pagination State
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, methodFilter]);

    const filteredLogs = useMemo(() => {
        return shelfLogs.filter(log => {
            const matchesSearch = 
                log.productName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                log.barcode.includes(searchTerm) || 
                log.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                log.newLocation.toLowerCase().includes(searchTerm.toLowerCase()) ||
                log.operator.toLowerCase().includes(searchTerm.toLowerCase());
            
            const matchesMethod = methodFilter === 'ALL' || log.method === methodFilter;
            
            return matchesSearch && matchesMethod;
        });
    }, [shelfLogs, searchTerm, methodFilter]);

    const totalItems = filteredLogs.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentLogs = filteredLogs.slice(indexOfFirstItem, indexOfLastItem);

    const handlePageChange = (page: number) => {
        if (page >= 1 && page <= totalPages) setCurrentPage(page);
    };

    const handleExport = () => {
        const data = filteredLogs.map(l => ({
            'Timestamp': new Date(l.timestamp).toLocaleString(),
            'Product': l.productName,
            'Barcode': l.barcode,
            'SKU': l.sku,
            'From': l.oldLocation,
            'To': l.newLocation,
            'Operator': l.operator,
            'Method': l.method
        }));
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Shelf Logs");
        XLSX.writeFile(wb, `Shelf_Logs_${new Date().toISOString().slice(0, 10)}.xlsx`);
    };

    return (
        <div className="p-6 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors duration-300">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
                        <Layers className="text-blue-600 dark:text-blue-400" />
                        Shelf Movement Logs
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Real-time audit trail of all product-to-location assignments.</p>
                </div>

                <div className="flex items-center gap-2">
                    <button 
                        onClick={handleExport}
                        className="px-4 py-2 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-xl text-gray-700 dark:text-gray-300 font-bold shadow-sm hover:bg-gray-50 dark:hover:bg-slate-800 transition-all flex items-center gap-2"
                    >
                        <FileDown size={18} /> Export
                    </button>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden flex flex-col transition-colors">
                <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex flex-col md:flex-row gap-4 bg-gray-50/30 dark:bg-slate-900/30">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                        <input 
                            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-all dark:text-white"
                            placeholder="Search by product, SKU, barcode, location or operator..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                        <span className="text-xs font-bold text-gray-400 uppercase whitespace-nowrap px-2">Method:</span>
                        {['ALL', 'SCAN', 'IMPORT', 'MANUAL'].map(m => (
                            <button 
                                key={m}
                                onClick={() => setMethodFilter(m)}
                                className={`px-4 py-1.5 rounded-full text-xs font-bold border transition-all whitespace-nowrap ${
                                    methodFilter === m 
                                    ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-200 dark:shadow-none' 
                                    : 'bg-white dark:bg-slate-800 text-gray-500 dark:text-gray-400 border-gray-200 dark:border-slate-700 hover:border-gray-300'
                                }`}
                            >
                                {m}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="overflow-x-auto flex-1">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800 text-gray-500 dark:text-gray-400 text-xs font-bold uppercase tracking-wider transition-colors">
                            <tr>
                                <th className="px-6 py-4">Timestamp</th>
                                <th className="px-6 py-4">Product Details</th>
                                <th className="px-6 py-4">Movement</th>
                                <th className="px-6 py-4">Method</th>
                                <th className="px-6 py-4">Operator</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-slate-800 transition-colors">
                            {currentLogs.map(log => (
                                <tr key={log.id} className="hover:bg-blue-50/30 dark:hover:bg-blue-900/10 transition-colors group">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-gray-100 dark:bg-slate-800 rounded-lg text-gray-500 dark:text-gray-400 group-hover:bg-blue-100 dark:group-hover:bg-blue-900/30 group-hover:text-blue-600 transition-colors">
                                                <Clock size={16} />
                                            </div>
                                            <div>
                                                <p className="text-sm font-bold text-gray-900 dark:text-white">{new Date(log.timestamp).toLocaleDateString('en-GB')}</p>
                                                <p className="text-xs text-gray-400 font-mono">{new Date(log.timestamp).toLocaleTimeString()}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex flex-col">
                                            <span className="text-sm font-bold text-gray-800 dark:text-gray-200">{log.productName}</span>
                                            <div className="flex items-center gap-2 mt-0.5">
                                                <span className="text-[10px] font-bold text-gray-400 font-mono bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 px-1.5 py-0.5 rounded">SKU: {log.sku}</span>
                                                <span className="text-[10px] font-bold text-gray-400 font-mono bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 px-1.5 py-0.5 rounded">B: {log.barcode}</span>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-4">
                                            <div className="flex flex-col items-center">
                                                <span className="text-[10px] font-black text-gray-300 uppercase leading-none mb-1">From</span>
                                                <span className="text-xs font-mono text-gray-500 dark:text-gray-500">{log.oldLocation || 'N/A'}</span>
                                            </div>
                                            <ArrowRight className="text-gray-300" size={16} />
                                            <div className="flex flex-col items-center">
                                                <span className="text-[10px] font-black text-blue-400 uppercase leading-none mb-1">To</span>
                                                <span className="text-sm font-mono font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 px-2 py-0.5 rounded border border-blue-100 dark:border-blue-900/30 shadow-sm">{log.newLocation}</span>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter border ${
                                            log.method === 'SCAN' ? 'bg-purple-50 text-purple-700 border-purple-100 dark:bg-purple-900/20 dark:text-purple-400 dark:border-purple-800' :
                                            log.method === 'IMPORT' ? 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800' :
                                            'bg-gray-100 text-gray-600 border-gray-200 dark:bg-slate-800 dark:text-gray-400 dark:border-slate-700'
                                        }`}>
                                            {log.method === 'SCAN' ? <Scan size={10} /> : log.method === 'IMPORT' ? <FileDown size={10} /> : <User size={10} />}
                                            {log.method}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300">
                                            <div className="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-[10px] font-black text-blue-600 dark:text-blue-400">
                                                {log.operator.charAt(0)}
                                            </div>
                                            <span className="font-medium">{log.operator}</span>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {filteredLogs.length === 0 && (
                        <div className="py-32 text-center flex flex-col items-center">
                            <Database size={64} className="text-gray-200 dark:text-slate-800 mb-4" />
                            <p className="text-gray-400 dark:text-gray-600 font-bold uppercase tracking-widest">No movement logs found</p>
                        </div>
                    )}
                </div>

                {/* Pagination Footer */}
                <div className="p-4 border-t border-gray-200 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 bg-gray-50/50 dark:bg-slate-950/50 transition-colors">
                     <div className="flex items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
                         <span className="text-xs font-bold uppercase tracking-wider">Rows per page</span>
                         <select 
                             className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-2 py-1 outline-none text-xs font-bold cursor-pointer transition-colors text-gray-700 dark:text-gray-300"
                             value={itemsPerPage}
                             onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                         >
                             <option value={10}>10</option>
                             <option value={20}>20</option>
                             <option value={50}>50</option>
                             <option value={100}>100</option>
                         </select>
                         <div className="h-4 w-px bg-gray-300 dark:bg-slate-700 mx-2"></div>
                         <span className="text-xs font-medium">
                             Showing {totalItems === 0 ? 0 : indexOfFirstItem + 1}-{Math.min(indexOfLastItem, totalItems)} of {totalItems}
                         </span>
                     </div>
                     
                     <div className="flex items-center gap-2">
                         <button onClick={() => handlePageChange(1)} disabled={currentPage === 1} className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors text-gray-600 dark:text-gray-400"><ChevronsLeft size={16} /></button>
                         <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors text-gray-600 dark:text-gray-400"><ChevronLeft size={16} /></button>
                         
                         <span className="px-4 text-xs font-bold text-gray-700 dark:text-gray-300">
                             Page {currentPage} of {totalPages || 1}
                         </span>

                         <button onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages || totalPages === 0} className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors text-gray-600 dark:text-gray-400"><ChevronRight size={16} /></button>
                         <button onClick={() => handlePageChange(totalPages)} disabled={currentPage === totalPages || totalPages === 0} className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors text-gray-600 dark:text-gray-400"><ChevronsRight size={16} /></button>
                     </div>
                 </div>
            </div>
        </div>
    );
};

export default ShelfLogs;
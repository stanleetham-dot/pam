
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { DistributionOrder } from '../types';
import { 
    Truck, MapPin, Phone, CheckCircle2, Navigation, 
    ChevronLeft, Package, Clock, XCircle,
    User, Menu, LogOut, ArrowRight,
    Camera, PenTool, X, FileText,
    Map as MapIcon, List, BellRing,
    Home, History, Settings, MoreHorizontal, UserCircle,
    Check, Trash2, RefreshCcw, Calendar, ImageIcon, Maximize2
} from 'lucide-react';
import L from 'leaflet';
import SettingsView from './Settings';

// Helper for distance calculation
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
}

const SignatureCanvas = ({ onEnd, onClear }: { onEnd: (data: string | null) => void, onClear: () => void }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const isDrawing = useRef(false);
    const hasDrawn = useRef(false);

    useEffect(() => {
        const canvas = canvasRef.current;
        const container = containerRef.current;
        if (!canvas || !container) return;

        const updateSize = () => {
            const rect = container.getBoundingClientRect();
            const dpr = window.devicePixelRatio || 1;
            canvas.style.width = `${rect.width}px`;
            canvas.style.height = `${rect.height}px`;
            canvas.width = rect.width * dpr;
            canvas.height = rect.height * dpr;
            const ctx = canvas.getContext('2d');
            if (ctx) {
                ctx.scale(dpr, dpr);
                ctx.lineWidth = 3;
                ctx.lineCap = 'round';
                ctx.lineJoin = 'round';
                ctx.strokeStyle = '#000';
            }
        };
        updateSize();
        window.addEventListener('resize', updateSize);
        return () => window.removeEventListener('resize', updateSize);
    }, []);

    const getPos = (e: React.MouseEvent | React.TouchEvent) => {
        const canvas = canvasRef.current;
        if (!canvas) return { x: 0, y: 0 };
        const rect = canvas.getBoundingClientRect();
        let clientX, clientY;
        if ('touches' in e) {
            clientX = e.touches[0].clientX;
            clientY = e.touches[0].clientY;
        } else {
            clientX = (e as React.MouseEvent).clientX;
            clientY = (e as React.MouseEvent).clientY;
        }
        return { x: clientX - rect.left, y: clientY - rect.top };
    };

    const start = (e: React.MouseEvent | React.TouchEvent) => {
        if (e.cancelable) e.preventDefault(); 
        isDrawing.current = true;
        const { x, y } = getPos(e);
        const ctx = canvasRef.current?.getContext('2d');
        if (ctx) { ctx.beginPath(); ctx.moveTo(x, y); }
    };

    const move = (e: React.MouseEvent | React.TouchEvent) => {
        if (!isDrawing.current) return;
        if (e.cancelable) e.preventDefault();
        const { x, y } = getPos(e);
        const ctx = canvasRef.current?.getContext('2d');
        if (ctx) { ctx.lineTo(x, y); ctx.stroke(); hasDrawn.current = true; }
    };

    const end = () => {
        if (!isDrawing.current) return;
        isDrawing.current = false;
        if (canvasRef.current && hasDrawn.current) {
            onEnd(canvasRef.current.toDataURL());
        }
    };
    
    const clear = () => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (canvas && ctx) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            hasDrawn.current = false;
            onEnd(null);
            onClear();
        }
    };

    return (
        <div ref={containerRef} className="relative w-full h-48 bg-gray-50 dark:bg-slate-800 rounded-xl border-2 border-dashed border-gray-300 dark:border-slate-700 overflow-hidden touch-none select-none">
            <canvas 
                ref={canvasRef}
                className="w-full h-full block cursor-crosshair touch-none"
                onMouseDown={start} onMouseMove={move} onMouseUp={end} onMouseLeave={end}
                onTouchStart={start} onTouchMove={move} onTouchEnd={end}
            />
            <button onClick={clear} type="button" className="absolute top-2 right-2 p-2 bg-white dark:bg-slate-700 rounded-full shadow-sm text-gray-500 hover:text-red-500 transition-colors border border-gray-200 dark:border-slate-600 z-10"><X size={16} /></button>
            {!hasDrawn.current && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40">
                    <span className="text-gray-400 font-bold uppercase tracking-widest text-sm flex items-center gap-2"><PenTool size={16}/> Sign Here</span>
                </div>
            )}
        </div>
    );
};

const DriverMap: React.FC<{ orders: DistributionOrder[]; onSelect: (id: string) => void; currentLocation: {lat: number, lng: number} | null }> = ({ orders, onSelect, currentLocation }) => {
    const mapContainerRef = useRef<HTMLDivElement>(null);
    const mapInstanceRef = useRef<L.Map | null>(null);
    const markersRef = useRef<L.Marker[]>([]);
    const { theme } = useInventory();

    // Init Map
    useEffect(() => {
        if (!mapContainerRef.current || mapInstanceRef.current) return;

        const map = L.map(mapContainerRef.current, {
            center: [1.3521, 103.8198],
            zoom: 12,
            zoomControl: false,
            attributionControl: false
        });

        L.control.zoom({ position: 'topright' }).addTo(map);
        mapInstanceRef.current = map;

        return () => {
            map.remove();
            mapInstanceRef.current = null;
        };
    }, []);

    // Theme & Tiles
    useEffect(() => {
        if (!mapInstanceRef.current) return;
        
        // Remove existing tile layers
        mapInstanceRef.current.eachLayer((layer) => {
            if (layer instanceof L.TileLayer) {
                mapInstanceRef.current?.removeLayer(layer);
            }
        });

        const url = theme === 'dark' 
            ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png' 
            : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
        
        L.tileLayer(url, {
            maxZoom: 19,
            subdomains: 'abcd',
        }).addTo(mapInstanceRef.current);
    }, [theme]);

    // Markers
    useEffect(() => {
        if (!mapInstanceRef.current) return;
        const map = mapInstanceRef.current;

        // Clear existing
        markersRef.current.forEach(m => m.remove());
        markersRef.current = [];

        const bounds = L.latLngBounds([]);

        // Driver Location
        if (currentLocation) {
            const driverSvg = `
                <div style="display: flex; align-items: center; justify-content: center;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#2563eb" stroke="white" stroke-width="3"/>
                    </svg>
                </div>
            `;
            const driverIcon = L.divIcon({
                html: driverSvg,
                className: 'custom-driver-icon',
                iconSize: [24, 24],
                iconAnchor: [12, 12]
            });
            const driverMarker = L.marker([currentLocation.lat, currentLocation.lng], { icon: driverIcon, zIndexOffset: 1000 }).addTo(map);
            markersRef.current.push(driverMarker);
            bounds.extend([currentLocation.lat, currentLocation.lng]);
        }

        // Orders
        orders.forEach(order => {
            if (order.deliveryDetails?.latitude && order.deliveryDetails?.longitude) {
                const color = theme === 'dark' ? '#3b82f6' : '#2563eb';
                
                const pinSvg = `
                    <div style="position: relative;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="${color}" stroke="white" stroke-width="1.5" filter="drop-shadow(0px 2px 2px rgba(0,0,0,0.3))">
                            <path d="M12 0C7.58 0 4 3.58 4 8c0 5.25 7 13 7 13s7-7.75 7-13c0-4.42-3.58-8-8-8zm0 11c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3z"/>
                        </svg>
                        <span style="position: absolute; top: 2px; left: 0; right: 0; text-align: center; color: white; font-size: 10px; font-weight: bold;">${order.orderNumber.slice(-3)}</span>
                    </div>
                `;

                const icon = L.divIcon({
                    html: pinSvg,
                    className: 'custom-pin-icon',
                    iconSize: [32, 32],
                    iconAnchor: [16, 32]
                });

                const marker = L.marker([order.deliveryDetails.latitude, order.deliveryDetails.longitude], { icon })
                    .addTo(map)
                    .on('click', () => onSelect(order.id));
                
                markersRef.current.push(marker);
                bounds.extend([order.deliveryDetails.latitude, order.deliveryDetails.longitude]);
            }
        });

        if (bounds.isValid()) {
            map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
        } else if (currentLocation) {
            map.setView([currentLocation.lat, currentLocation.lng], 14);
        }

    }, [orders, currentLocation, theme]);

    return (
        <div className="w-full h-full relative bg-gray-100 dark:bg-slate-900">
            <style>{`
                .custom-driver-icon, .custom-pin-icon { background: transparent; border: none; }
            `}</style>
            <div ref={mapContainerRef} className="w-full h-full z-0" />
        </div>
    );
};

// --- MAIN APP COMPONENT ---

const MobileDriverApp: React.FC = () => {
    const { currentUser, distributionOrders, updateDistributionOrder, logout, language, refreshData } = useInventory();
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    // View Management
    const [currentTab, setCurrentTab] = useState<'HOME' | 'MAP' | 'HISTORY' | 'PROFILE' | 'SETTINGS'>('HOME');
    const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
    const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [previewImage, setPreviewImage] = useState<string | null>(null);

    // POD & Actions
    const [geofencePromptedOrders, setGeofencePromptedOrders] = useState<Set<string>>(new Set());
    const [geofenceAlertOrder, setGeofenceAlertOrder] = useState<DistributionOrder | null>(null);
    const [isPODOpen, setIsPODOpen] = useState(false);
    const [podData, setPodData] = useState<{ image: string | null; signature: string | null; note: string }>({ image: null, signature: null, note: '' });
    const [completionStatus, setCompletionStatus] = useState<'Delivered' | 'Delivery Failed'>('Delivered');
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Data Filtering
    const myOrders = useMemo(() => {
        if (!currentUser) return [];
        return distributionOrders.filter(o => o.assignedDriverId === currentUser.id);
    }, [distributionOrders, currentUser]);

    const activeOrders = useMemo(() => myOrders.filter(o => 
        ['Shipped', 'In Transit', 'Ready to Ship'].includes(o.status)
    ), [myOrders]);

    const historyOrders = useMemo(() => myOrders.filter(o => 
        ['Delivered', 'Delivery Failed', 'Completed'].includes(o.status)
    ).sort((a, b) => new Date(b.deliveryTimestamp || b.createTime).getTime() - new Date(a.deliveryTimestamp || a.createTime).getTime()), [myOrders]);

    const selectedOrder = useMemo(() => myOrders.find(o => o.id === selectedOrderId), [myOrders, selectedOrderId]);

    // Force refresh on mount
    useEffect(() => {
        refreshData();
    }, []);

    // Geolocation
    useEffect(() => {
        if (!navigator.geolocation) return;
        const watcherId = navigator.geolocation.watchPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                setCurrentLocation({ lat: latitude, lng: longitude });
                // Check geofences
                activeOrders.forEach(order => {
                    if (geofencePromptedOrders.has(order.id)) return;
                    if (!order.deliveryDetails?.latitude || !order.deliveryDetails?.longitude) return;
                    const dist = calculateDistance(latitude, longitude, order.deliveryDetails.latitude, order.deliveryDetails.longitude);
                    if (dist <= (order.deliveryDetails.geofenceRadius || 500)) {
                        setGeofenceAlertOrder(order);
                        setGeofencePromptedOrders(prev => new Set(prev).add(order.id));
                        if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
                    }
                });
            },
            (err) => console.error(err),
            { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 }
        );
        return () => navigator.geolocation.clearWatch(watcherId);
    }, [activeOrders, geofencePromptedOrders]);

    // Handlers
    const handleNavigate = (address: string, coords?: { lat: number; lng: number }) => {
        const query = coords ? `${coords.lat},${coords.lng}` : encodeURIComponent(address);
        window.open(`https://www.google.com/maps/dir/?api=1&destination=${query}`, '_blank');
    };

    const handleCall = (phone: string) => window.open(`tel:${phone}`);

    const completeDelivery = () => {
        if (!selectedOrder) return;
        updateDistributionOrder({ 
            ...selectedOrder, 
            status: completionStatus,
            deliveryTimestamp: new Date().toISOString(),
            proofOfDelivery: podData.image || undefined,
            signature: podData.signature || undefined,
            driverNote: podData.note || selectedOrder.driverNote 
        });
        setIsPODOpen(false);
        setSelectedOrderId(null);
    };

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (evt) => { if (evt.target?.result) setPodData(prev => ({ ...prev, image: evt.target!.result as string })); };
        reader.readAsDataURL(file);
    };

    const handleRefresh = async () => {
        setIsRefreshing(true);
        await refreshData();
        setTimeout(() => setIsRefreshing(false), 500);
    };

    // --- RENDERERS ---

    const renderJobCard = (order: DistributionOrder, isHistory = false) => (
        <div key={order.id} onClick={() => setSelectedOrderId(order.id)} className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-slate-800 active:scale-[0.98] transition-transform mb-3 relative overflow-hidden group">
            {isHistory && order.status === 'Delivered' && (
                <div className="absolute right-0 top-0 bg-green-500/10 text-green-600 dark:text-green-400 p-1.5 rounded-bl-xl">
                    <CheckCircle2 size={16} />
                </div>
            )}
            
            <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-gray-400">#{order.orderNumber.slice(-4)}</span>
                    {!isHistory && (
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            order.status === 'In Transit' ? 'bg-blue-100 text-blue-700 animate-pulse' :
                            'bg-gray-100 text-gray-700'
                        }`}>{order.status}</span>
                    )}
                </div>
                {order.deliveryDetails?.deliveryTime && !isHistory && (
                    <div className="text-[10px] font-bold text-orange-600 bg-orange-50 dark:bg-orange-900/20 px-2 py-0.5 rounded flex items-center gap-1">
                        <Clock size={10} /> {order.deliveryDetails.deliveryTime}
                    </div>
                )}
            </div>
            
            <h3 className="font-bold text-gray-900 dark:text-white text-base mb-1 truncate pr-6">{order.deliveryDetails?.recipient}</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 leading-relaxed mb-3">
                {order.deliveryDetails?.address}
            </p>

            <div className="flex items-center justify-between border-t border-gray-100 dark:border-slate-800 pt-3">
                <span className="text-xs text-gray-400 flex items-center gap-1"><Package size={12}/> {order.items.length} Items</span>
                
                {!isHistory ? (
                    <div className="flex gap-2">
                        <button onClick={(e) => { e.stopPropagation(); handleCall(order.deliveryDetails?.phone || ''); }} className="p-2 bg-gray-100 dark:bg-slate-800 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors"><Phone size={14} /></button>
                        <button onClick={(e) => { e.stopPropagation(); handleNavigate(order.deliveryDetails?.address || '', order.deliveryDetails?.latitude ? {lat: order.deliveryDetails.latitude, lng: order.deliveryDetails.longitude!} : undefined); }} className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-600 dark:text-blue-400 hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors"><Navigation size={14} /></button>
                    </div>
                ) : (
                    <div className="flex items-center gap-3">
                        {order.proofOfDelivery && (
                            <div className="flex items-center gap-1 text-[10px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 px-1.5 py-0.5 rounded border border-blue-100 dark:border-blue-900/30">
                                <ImageIcon size={10} /> Photo
                            </div>
                        )}
                        {order.signature && (
                            <div className="flex items-center gap-1 text-[10px] font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-900/20 px-1.5 py-0.5 rounded border border-purple-100 dark:border-purple-900/30">
                                <PenTool size={10} /> Signed
                            </div>
                        )}
                        <span className="text-[10px] text-gray-400 flex items-center gap-1 ml-auto">
                            <Clock size={10} />
                            {new Date(order.deliveryTimestamp || order.createTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </span>
                    </div>
                )}
            </div>
        </div>
    );

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 text-gray-900 dark:text-white font-sans overflow-hidden">
            
            {/* LIGHTBOX FOR IMAGES */}
            {previewImage && (
                <div className="fixed inset-0 z-[100] bg-black flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={() => setPreviewImage(null)}>
                    <button className="absolute top-4 right-4 p-3 bg-white/20 hover:bg-white/40 rounded-full text-white backdrop-blur-md transition-colors z-10" onClick={() => setPreviewImage(null)}>
                        <X size={24}/>
                    </button>
                    <img 
                        src={previewImage} 
                        className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" 
                        onClick={(e) => e.stopPropagation()} 
                    />
                </div>
            )}

            {/* --- MAIN CONTENT AREA --- */}
            <div className="flex-1 overflow-y-auto pb-20 relative">
                
                {/* 1. HOME TAB */}
                {currentTab === 'HOME' && (
                    <div className="p-4 pt-12">
                        <div className="flex justify-between items-center mb-6">
                            <div>
                                <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{t("Welcome back,", "欢迎回来，")}</p>
                                <h1 className="text-2xl font-black">{currentUser?.name}</h1>
                            </div>
                            <button 
                                onClick={handleRefresh}
                                className={`p-2 rounded-full bg-white dark:bg-slate-900 shadow-sm border border-gray-100 dark:border-slate-800 text-gray-500 ${isRefreshing ? 'animate-spin' : ''}`}
                            >
                                <RefreshCcw size={20} />
                            </button>
                        </div>

                        {/* Summary Cards */}
                        <div className="grid grid-cols-2 gap-3 mb-6">
                            <div className="bg-blue-600 text-white p-4 rounded-2xl shadow-lg shadow-blue-200 dark:shadow-none">
                                <div className="text-3xl font-black mb-1">{activeOrders.length}</div>
                                <div className="text-xs font-medium opacity-80 uppercase tracking-wide">Active Jobs</div>
                            </div>
                            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm">
                                <div className="text-3xl font-black text-gray-900 dark:text-white mb-1">{historyOrders.length}</div>
                                <div className="text-xs font-medium text-gray-400 uppercase tracking-wide">Completed</div>
                            </div>
                        </div>

                        <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Current Route</h2>
                        {activeOrders.length === 0 ? (
                            <div className="text-center py-10 text-gray-400">
                                <Package size={48} className="mx-auto mb-2 opacity-20" />
                                <p className="text-sm font-medium">No active jobs assigned.</p>
                            </div>
                        ) : (
                            <div className="space-y-1">
                                {activeOrders.map(order => renderJobCard(order))}
                            </div>
                        )}
                    </div>
                )}

                {/* 2. MAP TAB */}
                {currentTab === 'MAP' && (
                    <div className="h-full w-full relative">
                        <DriverMap orders={activeOrders} onSelect={setSelectedOrderId} currentLocation={currentLocation} />
                        {selectedOrderId && (
                            <div className="absolute bottom-20 left-4 right-4 z-10">
                                {renderJobCard(selectedOrder!)}
                            </div>
                        )}
                    </div>
                )}

                {/* 3. HISTORY TAB */}
                {currentTab === 'HISTORY' && (
                    <div className="p-4 pt-12">
                        <h2 className="text-2xl font-black mb-6">Job History</h2>
                        {historyOrders.length === 0 ? (
                            <div className="text-center py-10 text-gray-400">
                                <History size={48} className="mx-auto mb-2 opacity-20" />
                                <p className="text-sm font-medium">No completed jobs yet.</p>
                            </div>
                        ) : (
                            <div className="space-y-1">
                                {historyOrders.map(order => renderJobCard(order, true))}
                            </div>
                        )}
                    </div>
                )}

                {/* 4. PROFILE TAB */}
                {currentTab === 'PROFILE' && (
                    <div className="p-4 pt-12">
                        <div className="flex flex-col items-center mb-8">
                            <div className="w-24 h-24 bg-gray-200 dark:bg-slate-800 rounded-full flex items-center justify-center text-4xl mb-4 overflow-hidden border-4 border-white dark:border-slate-900 shadow-lg">
                                {currentUser?.avatar ? <img src={currentUser.avatar} className="w-full h-full object-cover" /> : "🤠"}
                            </div>
                            <h2 className="text-2xl font-black">{currentUser?.name}</h2>
                            <p className="text-gray-500 text-sm">@{currentUser?.username}</p>
                        </div>

                        <div className="space-y-3">
                            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 flex items-center justify-between border border-gray-100 dark:border-slate-800">
                                <span className="font-bold text-sm">Vehicle Type</span>
                                <span className="text-sm text-gray-500">Van</span>
                            </div>
                            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 flex items-center justify-between border border-gray-100 dark:border-slate-800">
                                <span className="font-bold text-sm">App Version</span>
                                <span className="text-sm text-gray-500">v2.4.0</span>
                            </div>
                            
                            <button 
                                onClick={() => setCurrentTab('SETTINGS')}
                                className="w-full bg-white dark:bg-slate-900 text-gray-900 dark:text-white font-bold py-4 rounded-2xl mt-4 flex items-center justify-between px-6 border border-gray-100 dark:border-slate-800 shadow-sm active:scale-95 transition-transform"
                            >
                                <div className="flex items-center gap-3">
                                    <Settings size={20} className="text-gray-500" />
                                    <span>{t('Settings', '设置')}</span>
                                </div>
                                <ChevronLeft size={20} className="rotate-180 text-gray-400" />
                            </button>

                            <button 
                                onClick={logout}
                                className="w-full bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 font-bold py-4 rounded-2xl mt-8 flex items-center justify-center gap-2 active:scale-95 transition-transform"
                            >
                                <LogOut size={20} /> Sign Out
                            </button>
                        </div>
                    </div>
                )}

                {/* 5. SETTINGS TAB */}
                {currentTab === 'SETTINGS' && (
                    <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950">
                        <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex items-center gap-4 bg-white dark:bg-slate-900 sticky top-0 z-10 shrink-0">
                             <button onClick={() => setCurrentTab('PROFILE')} className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-600 dark:text-white transition-colors">
                                <ChevronLeft size={24} />
                             </button>
                             <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t('Settings', '设置')}</h2>
                        </div>
                        <div className="flex-1 overflow-y-auto">
                            <SettingsView embedded={true} />
                        </div>
                    </div>
                )}
            </div>

            {/* --- BOTTOM NAVIGATION --- */}
            {currentTab !== 'SETTINGS' && (
                <div className="absolute bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-gray-200 dark:border-slate-800 px-6 py-3 flex justify-between items-center z-40 safe-area-pb">
                    <button onClick={() => setCurrentTab('HOME')} className={`flex flex-col items-center gap-1 transition-colors ${currentTab === 'HOME' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'}`}>
                        <Home size={24} strokeWidth={currentTab === 'HOME' ? 2.5 : 2} />
                        <span className="text-[10px] font-bold">Home</span>
                    </button>
                    <button onClick={() => setCurrentTab('MAP')} className={`flex flex-col items-center gap-1 transition-colors ${currentTab === 'MAP' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'}`}>
                        <MapIcon size={24} strokeWidth={currentTab === 'MAP' ? 2.5 : 2} />
                        <span className="text-[10px] font-bold">Map</span>
                    </button>
                    <button onClick={() => setCurrentTab('HISTORY')} className={`flex flex-col items-center gap-1 transition-colors ${currentTab === 'HISTORY' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'}`}>
                        <History size={24} strokeWidth={currentTab === 'HISTORY' ? 2.5 : 2} />
                        <span className="text-[10px] font-bold">History</span>
                    </button>
                    <button onClick={() => setCurrentTab('PROFILE')} className={`flex flex-col items-center gap-1 transition-colors ${currentTab === 'PROFILE' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'}`}>
                        <UserCircle size={24} strokeWidth={currentTab === 'PROFILE' ? 2.5 : 2} />
                        <span className="text-[10px] font-bold">Profile</span>
                    </button>
                </div>
            )}

            {/* --- JOB DETAIL SHEET (Slide Over) --- */}
            <div className={`fixed inset-0 z-[60] bg-white dark:bg-slate-900 transition-transform duration-300 transform ${selectedOrder && currentTab !== 'MAP' ? 'translate-x-0' : 'translate-x-full'} flex flex-col`}>
                {selectedOrder && (
                    <>
                        <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex items-center gap-4 bg-white dark:bg-slate-950">
                            <button onClick={() => setSelectedOrderId(null)} className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800">
                                <ChevronLeft size={24} />
                            </button>
                            <div className="flex-1">
                                <h2 className="font-bold text-lg text-gray-900 dark:text-white truncate pr-2">{selectedOrder.deliveryDetails?.recipient}</h2>
                                <p className="text-xs text-gray-500 font-mono">#{selectedOrder.orderNumber}</p>
                            </div>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap ${
                                selectedOrder.status === 'Delivered' ? 'bg-green-100 text-green-700' :
                                selectedOrder.status === 'In Transit' ? 'bg-blue-100 text-blue-700' : 
                                'bg-gray-100 text-gray-700'
                            }`}>
                                {selectedOrder.status}
                            </span>
                        </div>

                        <div className="flex-1 overflow-y-auto p-5 space-y-6">
                            
                            {/* --- ACTIONS FOR ACTIVE JOBS --- */}
                            {['Ready to Ship', 'Shipped', 'In Transit'].includes(selectedOrder.status) && (
                                <div className="grid grid-cols-2 gap-4">
                                    <button 
                                        onClick={() => handleNavigate(selectedOrder.deliveryDetails?.address || '')}
                                        className="bg-blue-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-transform"
                                    >
                                        <Navigation size={18} /> Navigate
                                    </button>
                                    <button 
                                        onClick={() => handleCall(selectedOrder.deliveryDetails?.phone || '')}
                                        className="bg-gray-100 dark:bg-slate-800 text-gray-900 dark:text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 active:scale-95 transition-transform"
                                    >
                                        <Phone size={18} /> Call
                                    </button>
                                </div>
                            )}

                            {/* --- COMPLETED JOB RECEIPT (POD) --- */}
                            {['Delivered', 'Delivery Failed'].includes(selectedOrder.status) && (
                                <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-700 overflow-hidden">
                                    <div className={`p-4 ${selectedOrder.status === 'Delivered' ? 'bg-green-500' : 'bg-red-500'} text-white flex justify-between items-center`}>
                                        <div>
                                            <h3 className="font-bold text-lg">{selectedOrder.status === 'Delivered' ? 'Delivery Successful' : 'Delivery Failed'}</h3>
                                            <p className="text-xs opacity-90 flex items-center gap-1 mt-1">
                                                <Clock size={12} /> {selectedOrder.deliveryTimestamp ? new Date(selectedOrder.deliveryTimestamp).toLocaleString() : 'N/A'}
                                            </p>
                                        </div>
                                        <div className="bg-white/20 p-2 rounded-full">
                                            {selectedOrder.status === 'Delivered' ? <CheckCircle2 size={24} /> : <XCircle size={24} />}
                                        </div>
                                    </div>
                                    
                                    <div className="p-4 space-y-4">
                                        {selectedOrder.proofOfDelivery && (
                                            <div>
                                                <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase mb-2 block">Proof of Delivery</span>
                                                <div className="rounded-xl overflow-hidden border border-gray-100 dark:border-slate-700 bg-gray-50 dark:bg-slate-900 h-48 relative group">
                                                    <img 
                                                        src={selectedOrder.proofOfDelivery} 
                                                        className="w-full h-full object-cover" 
                                                        alt="POD" 
                                                        onClick={() => setPreviewImage(selectedOrder.proofOfDelivery!)}
                                                    />
                                                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                                        <span className="text-white text-xs font-bold border border-white px-3 py-1 rounded-full flex items-center gap-1"><Maximize2 size={12}/> Tap to View</span>
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                        
                                        {selectedOrder.signature && (
                                            <div>
                                                <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase mb-2 block">Recipient Signature</span>
                                                <div className="bg-gray-50 dark:bg-white rounded-xl p-2 border border-gray-100 h-24 flex items-center justify-center">
                                                    <img src={selectedOrder.signature} className="max-h-full max-w-full" alt="Signature" />
                                                </div>
                                            </div>
                                        )}

                                        {selectedOrder.driverNote && (
                                            <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-xl border border-yellow-100 dark:border-yellow-900/50">
                                                <span className="text-[10px] font-bold text-yellow-600 dark:text-yellow-400 uppercase block mb-1">Driver Note</span>
                                                <p className="text-sm text-yellow-800 dark:text-yellow-200 italic">"{selectedOrder.driverNote}"</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}

                            {/* Address Card */}
                            <div className="bg-gray-50 dark:bg-slate-900 p-4 rounded-2xl border border-gray-100 dark:border-slate-800">
                                <div className="flex gap-3">
                                    <MapPin className="text-gray-400 mt-1 shrink-0" size={20} />
                                    <div>
                                        <p className="text-sm font-medium leading-relaxed text-gray-800 dark:text-gray-200">
                                            {selectedOrder.deliveryDetails?.address}
                                            {selectedOrder.deliveryDetails?.unit && `, ${selectedOrder.deliveryDetails.unit}`}
                                        </p>
                                        <p className="text-xs text-gray-500 mt-1 font-mono">{selectedOrder.deliveryDetails?.postCode}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Items */}
                            <div>
                                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Items ({selectedOrder.items.length})</h3>
                                <div className="space-y-3">
                                    {selectedOrder.items.map((item, i) => (
                                        <div key={i} className="flex items-center justify-between p-3 border border-gray-100 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 bg-gray-100 dark:bg-slate-800 rounded flex items-center justify-center text-gray-400 font-bold text-xs">{i+1}</div>
                                                <div>
                                                    <p className="text-sm font-bold text-gray-900 dark:text-white">{item.productName}</p>
                                                    <p className="text-xs text-gray-500">{item.productCode}</p>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <span className="font-bold text-lg text-gray-800 dark:text-gray-200">x{item.pickedQty}</span>
                                                <p className="text-[10px] text-gray-400">{item.distributionUnit}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Footer Action */}
                        <div className="p-4 border-t border-gray-100 dark:border-slate-800 safe-area-pb bg-white dark:bg-slate-950">
                            {['Ready to Ship', 'Shipped'].includes(selectedOrder.status) ? (
                                <button 
                                    onClick={() => {
                                        updateDistributionOrder({ ...selectedOrder, status: 'In Transit' });
                                        setSelectedOrderId(null);
                                    }}
                                    className="w-full bg-black dark:bg-white dark:text-black text-white py-4 rounded-xl font-black uppercase tracking-wider shadow-xl active:scale-[0.98] transition-transform"
                                >
                                    Start Route
                                </button>
                            ) : selectedOrder.status === 'In Transit' ? (
                                <div className="grid grid-cols-4 gap-3">
                                    <button 
                                        onClick={() => { setCompletionStatus('Delivery Failed'); setIsPODOpen(true); }}
                                        className="col-span-1 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-xl flex items-center justify-center font-bold"
                                    >
                                        <X size={24} />
                                    </button>
                                    <button 
                                        onClick={() => { setCompletionStatus('Delivered'); setIsPODOpen(true); }}
                                        className="col-span-3 bg-green-600 text-white py-4 rounded-xl font-black uppercase tracking-wider shadow-lg flex items-center justify-center gap-2"
                                    >
                                        <CheckCircle2 size={24} /> Complete
                                    </button>
                                </div>
                            ) : null}
                        </div>
                    </>
                )}
            </div>

            {/* --- POD MODAL --- */}
            {isPODOpen && (
                <div className="fixed inset-0 z-[70] bg-white dark:bg-slate-950 flex flex-col animate-in slide-in-from-bottom-10">
                    <div className="p-4 flex justify-between items-center border-b border-gray-100 dark:border-slate-800">
                        <h2 className="font-black text-lg text-gray-900 dark:text-white">{completionStatus === 'Delivered' ? 'Proof of Delivery' : 'Report Failure'}</h2>
                        <button onClick={() => setIsPODOpen(false)} className="p-2 bg-gray-100 dark:bg-slate-800 rounded-full"><X size={20}/></button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-6 space-y-6">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-400 uppercase">Photo Proof</label>
                            {podData.image ? (
                                <div className="relative h-64 bg-black rounded-xl overflow-hidden group">
                                    <img src={podData.image} className="w-full h-full object-contain" />
                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button onClick={() => setPodData(p => ({...p, image: null}))} className="bg-red-600 text-white px-4 py-2 rounded-lg font-bold shadow-lg transform active:scale-95 transition-transform flex items-center gap-2">
                                            <Trash2 size={16}/> Retake
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <button onClick={() => fileInputRef.current?.click()} className="w-full h-48 border-2 border-dashed border-gray-300 dark:border-slate-700 rounded-xl flex flex-col items-center justify-center text-gray-400 gap-2 hover:bg-gray-50 dark:hover:bg-slate-900 transition-colors">
                                    <Camera size={32} /> <span className="text-sm font-bold">Tap to Capture</span>
                                </button>
                            )}
                            <input type="file" accept="image/*" ref={fileInputRef} className="hidden" onChange={handleImageUpload} />
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-400 uppercase">Signature</label>
                            <SignatureCanvas onEnd={(d) => setPodData(p => ({...p, signature: d}))} onClear={() => setPodData(p => ({...p, signature: null}))} />
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-400 uppercase">Note</label>
                            <textarea className="w-full p-4 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-xl outline-none text-gray-900 dark:text-white" rows={3} placeholder="Add a comment..." value={podData.note} onChange={e => setPodData(p => ({...p, note: e.target.value}))} />
                        </div>
                    </div>
                    <div className="p-4 border-t border-gray-100 dark:border-slate-800 safe-area-pb">
                        <button onClick={completeDelivery} className="w-full py-4 bg-blue-600 text-white font-black uppercase rounded-xl shadow-lg active:scale-95 transition-transform">Confirm</button>
                    </div>
                </div>
            )}

            {/* Geofence Alert */}
            {geofenceAlertOrder && (
                <div className="fixed bottom-20 left-4 right-4 bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-2xl border-2 border-blue-500 z-50 animate-in slide-in-from-bottom-10 flex items-center justify-between">
                    <div>
                        <h4 className="font-bold text-blue-600">Arrived at Destination!</h4>
                        <p className="text-xs text-gray-500">You are near {geofenceAlertOrder.deliveryDetails?.recipient}</p>
                    </div>
                    <button onClick={() => { setSelectedOrderId(geofenceAlertOrder.id); setGeofenceAlertOrder(null); setCompletionStatus('Delivered'); setIsPODOpen(true); }} className="bg-blue-600 text-white px-4 py-2 rounded-lg font-bold text-sm">Start Drop-off</button>
                </div>
            )}
        </div>
    );
};

export default MobileDriverApp;

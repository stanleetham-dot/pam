
import React, { useState } from 'react';
import { Package, Truck, Calendar, Search, Filter, Plus } from 'lucide-react';
import { Parcel } from '../types';

const ParcelManagement: React.FC = () => {
    // Mock Data
    const [parcels, setParcels] = useState<Parcel[]>([
        { id: '1', trackingNumber: 'TRK-987654321', carrier: 'FedEx', status: 'RECEIVED', weight: 12.5, dimensions: '10x10x10', receivedAt: '2023-10-25 09:30' },
        { id: '2', trackingNumber: 'TRK-123456789', carrier: 'UPS', status: 'PROCESSING', weight: 5.2, dimensions: '5x5x5', receivedAt: '2023-10-25 10:15' },
        { id: '3', trackingNumber: 'DHL-555111222', carrier: 'DHL', status: 'SHIPPED', weight: 2.0, dimensions: '20x10x5', receivedAt: '2023-10-24 14:00' },
    ]);

    const getStatusColor = (status: string) => {
        switch(status) {
            case 'RECEIVED': return 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-900/50';
            case 'PROCESSING': return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400 border-yellow-200 dark:border-yellow-900/50';
            case 'PUTAWAY': return 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 border-purple-200 dark:border-purple-900/50';
            case 'SHIPPED': return 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 border-green-200 dark:border-green-900/50';
            default: return 'bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400';
        }
    };

    return (
        <div className="p-6 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors duration-300">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
                        <Package className="text-blue-600 dark:text-blue-400" /> Parcel Management
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Track inbound and outbound parcels.</p>
                </div>
                <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium flex items-center gap-2 shadow-sm transition-all transform active:scale-95">
                    <Plus size={18} /> Register Parcel
                </button>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden transition-colors duration-300">
                <div className="p-4 border-b border-gray-200 dark:border-slate-800 flex gap-4 bg-gray-50/30 dark:bg-slate-950/30">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={16} />
                        <input className="w-full pl-9 pr-4 py-2 border border-gray-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-gray-400" placeholder="Search tracking number..." />
                    </div>
                    <div className="flex gap-2">
                        <button className="px-3 py-2 border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 transition-colors"><Filter size={16}/> Filter</button>
                    </div>
                </div>
                
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800 transition-colors duration-300">
                            <tr>
                                <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Tracking Number</th>
                                <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Carrier</th>
                                <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Details</th>
                                <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Received At</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                            {parcels.map(parcel => (
                                <tr key={parcel.id} className="hover:bg-gray-50 dark:hover:bg-slate-800/50 transition-colors">
                                    <td className="px-6 py-4 font-mono font-medium text-gray-800 dark:text-gray-100">{parcel.trackingNumber}</td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300 text-sm">
                                            <Truck size={16} className="text-gray-400 dark:text-gray-500" /> {parcel.carrier}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold border transition-colors ${getStatusColor(parcel.status)}`}>
                                            {parcel.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                                        <span className="font-bold text-gray-700 dark:text-gray-300">{parcel.weight} kg</span> • {parcel.dimensions}
                                    </td>
                                    <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-400">
                                        <div className="flex items-center gap-2">
                                            <Calendar size={14} className="text-gray-400 dark:text-gray-500" /> {parcel.receivedAt}
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {parcels.length === 0 && (
                        <div className="p-12 text-center text-gray-400 dark:text-gray-600">
                            <Package size={48} className="mx-auto mb-3 opacity-20" />
                            <p>No parcels found matching your search.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ParcelManagement;


import React, { useState } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    LogOut, ChevronLeft, Package, CheckSquare, 
    Scan, ShoppingCart, ClipboardList, Home, 
    User, Search, Settings, Truck, AlertTriangle, RefreshCcw
} from 'lucide-react';
import DistributionOrderManager from './DistributionOrderManager';
import InventoryList from './InventoryList';
import SkuLookup from './SkuLookup';
import SettingsView from './Settings';
import DiscrepancyCheck from './DiscrepancyCheck';

const MobileHeader: React.FC<{ 
    title: string; 
    onBack?: () => void; 
    onHome?: () => void;
    showLogout?: boolean;
    onLogout?: () => void;
    userName?: string;
    onRefresh?: () => void;
}> = ({ title, onBack, onHome, showLogout, onLogout, userName, onRefresh }) => (
    <div className="bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-slate-800 p-4 sticky top-0 z-20 shadow-sm flex items-center justify-between h-16 shrink-0 transition-colors">
        <div className="flex items-center gap-3 overflow-hidden">
            {onBack ? (
                <button 
                    onClick={onBack} 
                    className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-600 dark:text-gray-300 transition-colors"
                >
                    <ChevronLeft size={24} />
                </button>
            ) : (
                <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold shadow-md">
                    <User size={20} />
                </div>
            )}
            <div>
                <h2 className="text-lg font-black text-gray-900 dark:text-white truncate leading-tight">{title}</h2>
                {userName && <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">Hello, {userName}</p>}
            </div>
        </div>
        <div className="flex items-center gap-2">
            {onRefresh && (
                <button 
                    onClick={onRefresh} 
                    className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-500 dark:text-gray-400 transition-colors"
                >
                    <RefreshCcw size={20} />
                </button>
            )}
            {onHome && (
                <button 
                    onClick={onHome} 
                    className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-500 dark:text-gray-400 transition-colors"
                >
                    <Home size={20} />
                </button>
            )}
            {showLogout && onLogout && (
                <button 
                    onClick={onLogout} 
                    className="p-2 rounded-full bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors"
                >
                    <LogOut size={20} />
                </button>
            )}
        </div>
    </div>
);

const MenuButton: React.FC<{ 
    title: string; 
    icon: React.ElementType; 
    colorClass: string; 
    onClick: () => void;
    desc: string;
}> = ({ title, icon: Icon, colorClass, onClick, desc }) => (
    <button 
        onClick={onClick}
        className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-gray-100 dark:border-slate-800 shadow-sm hover:shadow-md active:scale-95 transition-all flex flex-col items-start gap-4 group h-full justify-between"
    >
        <div className={`p-4 rounded-2xl ${colorClass} bg-opacity-10 dark:bg-opacity-20`}>
            <Icon size={32} className={colorClass.replace('bg-', 'text-')} />
        </div>
        <div className="text-left">
            <span className="block font-bold text-lg text-gray-900 dark:text-white mb-1">{title}</span>
            <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">{desc}</span>
        </div>
    </button>
);

// Extracted ContentWrapper to be a standalone component
const ContentWrapper: React.FC<{ 
    children: React.ReactNode; 
    title: string; 
    onBack: () => void;
    onHome: () => void;
    onRefresh?: () => void;
}> = ({ children, title, onBack, onHome, onRefresh }) => (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 overflow-hidden">
        <MobileHeader title={title} onBack={onBack} onHome={onHome} onRefresh={onRefresh} />
        <div className="flex-1 overflow-hidden relative">
            {children}
        </div>
    </div>
);

const MobileBranchApp: React.FC = () => {
    const { currentUser, logout, language, refreshData } = useInventory();
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    const [currentView, setCurrentView] = useState<'MENU' | 'ORDERS' | 'INVENTORY' | 'SCAN' | 'SETTINGS'>('MENU');
    const [isRefreshing, setIsRefreshing] = useState(false);

    const handleBack = () => {
        setCurrentView('MENU');
    };

    const handleRefresh = async () => {
        setIsRefreshing(true);
        await refreshData();
        setTimeout(() => setIsRefreshing(false), 500);
    };

    if (currentView === 'MENU') {
        return (
            <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 p-6 overflow-y-auto">
                <MobileHeader 
                    title="Branch Portal" 
                    userName={currentUser?.name}
                    showLogout={true}
                    onLogout={logout}
                    onRefresh={handleRefresh}
                />

                <div className="grid grid-cols-2 gap-4 mt-6 pb-20">
                    <MenuButton 
                        title={t("Discrepancy", "差异检查")}
                        desc={t("Resolve issues", "解决收货问题")}
                        icon={AlertTriangle}
                        colorClass="bg-amber-600 text-amber-600"
                        onClick={() => setCurrentView('ORDERS')}
                    />
                    <MenuButton 
                        title={t("Inventory", "库存查询")}
                        desc={t("Check branch stock", "查看分店库存")}
                        icon={Package}
                        colorClass="bg-emerald-600 text-emerald-600"
                        onClick={() => setCurrentView('INVENTORY')}
                    />
                    <MenuButton 
                        title={t("Scan Ops", "扫描作业")}
                        desc={t("Move & Audit", "移动与审计")}
                        icon={Scan}
                        colorClass="bg-purple-600 text-purple-600"
                        onClick={() => setCurrentView('SCAN')}
                    />
                    <MenuButton 
                        title={t("Settings", "设置")}
                        desc={t("App preferences", "应用偏好")}
                        icon={Settings}
                        colorClass="bg-gray-600 text-gray-600"
                        onClick={() => setCurrentView('SETTINGS')}
                    />
                </div>
            </div>
        );
    }

    switch (currentView) {
        case 'ORDERS':
            return (
                <ContentWrapper title={t("Discrepancy Check", "差异检查")} onBack={handleBack} onHome={() => setCurrentView('MENU')} onRefresh={handleRefresh}>
                    <DiscrepancyCheck />
                </ContentWrapper>
            );
        case 'INVENTORY':
            return (
                <ContentWrapper title={t("Inventory Query", "库存查询")} onBack={handleBack} onHome={() => setCurrentView('MENU')} onRefresh={handleRefresh}>
                    <InventoryList enableExport={false} enableImport={false} allowEdit={false} />
                </ContentWrapper>
            );
        case 'SCAN':
            return (
                <ContentWrapper title={t("SKU Lookup", "SKU查询")} onBack={handleBack} onHome={() => setCurrentView('MENU')}>
                    <SkuLookup onClose={handleBack} />
                </ContentWrapper>
            );
        case 'SETTINGS':
            return (
                <ContentWrapper title={t("Settings", "设置")} onBack={handleBack} onHome={() => setCurrentView('MENU')}>
                    <SettingsView embedded={true} />
                </ContentWrapper>
            );
        default:
            return null;
    }
};

export default MobileBranchApp;

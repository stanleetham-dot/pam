
import React, { useState, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    Lock, User, ArrowRight, Eye, EyeOff, 
    LayoutDashboard, Mail, ArrowLeft, 
    CheckCircle2, Activity, Package,
    Sun, Moon, KeyRound
} from 'lucide-react';
import { supabase } from '../supabaseClient';

const Login: React.FC = () => {
  const { login, theme, setGlobalTheme, addNotification } = useInventory();
  const [view, setView] = useState<'LOGIN' | 'FORGOT' | 'RESET'>('LOGIN');
  
  // Login State
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Forgot Password State
  const [resetEmail, setResetEmail] = useState('');
  const [resetStatus, setResetStatus] = useState<'IDLE' | 'SENDING' | 'SENT'>('IDLE');

  // Reset Password State
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Check for recovery hash on mount
  useEffect(() => {
      const hash = window.location.hash;
      if (hash && hash.includes('type=recovery')) {
          setView('RESET');
          window.history.replaceState(null, '', window.location.pathname);
      }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const cleanUsername = username.trim();
    const cleanPassword = password.trim();

    try {
      const result = await login(cleanUsername, cleanPassword);
      if (!result.success) {
        addNotification('error', 'Login Failed', result.message || 'Invalid username or password');
      }
    } catch (err: any) {
        console.error("Login component caught error:", err);
        addNotification('error', 'System Error', 'An unexpected error occurred. Please check console.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
      e.preventDefault();
      setResetStatus('SENDING');
      
      setTimeout(() => {
          setResetStatus('SENT');
          addNotification('success', 'Email Sent', 'Reset instructions sent to ' + resetEmail);
      }, 1500);
  };

  const handleResetPassword = async (e: React.FormEvent) => {
      e.preventDefault();
      
      if (newPassword.length < 6) {
          addNotification('warning', 'Weak Password', 'Password must be at least 6 characters');
          return;
      }
      if (newPassword !== confirmPassword) {
          addNotification('error', 'Mismatch', 'Passwords do not match');
          return;
      }

      setIsLoading(true);
      try {
          const { data: { session } } = await supabase.auth.getSession();
          if (session) {
              const { error } = await supabase.auth.updateUser({ password: newPassword });
              if (error) throw error;
          } else {
              await new Promise(resolve => setTimeout(resolve, 1000));
          }
          
          addNotification('success', 'Success', 'Password successfully updated. Please login.');
          setView('LOGIN');
          setPassword('');
      } catch (err: any) {
          console.error("Reset password error:", err);
          addNotification('error', 'Reset Failed', err.message || 'Failed to reset password');
      } finally {
          setIsLoading(false);
      }
  };

  const toggleTheme = () => {
    setGlobalTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <div className="min-h-screen flex font-sans bg-gray-50 dark:bg-slate-950 selection:bg-blue-100 dark:selection:bg-blue-900 selection:text-blue-900 transition-colors duration-300">
      
      {/* LEFT PANEL: Brand & Aesthetics */}
      <div className="hidden lg:flex lg:w-[55%] relative overflow-hidden bg-slate-900">
        <div className="absolute inset-0 z-0">
             <img 
                src="https://shippingandhandlingtx.com/wp-content/uploads/2022/11/Houston-Warehousing-What-Kind-of-Warehouse-Do-You-Need.jpeg" 
                alt="Modern Warehouse" 
                className="w-full h-full object-cover opacity-30 animate-pulse-slow"
                style={{ animationDuration: '30s' }}
             />
             <div className="absolute inset-0 bg-gradient-to-tr from-slate-900 via-blue-900/90 to-slate-900/50 mix-blend-multiply" />
        </div>

        <div className="relative z-10 w-full h-full flex flex-col justify-between p-20 text-white">
            <div className="flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-700">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/30 backdrop-blur-sm border border-white/10">
                    <LayoutDashboard className="text-white" size={20} />
                </div>
                <span className="text-2xl font-bold tracking-tight">Pam Pam WMS</span>
            </div>

            <div className="space-y-8 max-w-lg animate-in fade-in slide-in-from-left-4 duration-1000 delay-200">
                <h1 className="text-5xl font-bold leading-tight tracking-tight">
                    Inventory <br/>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">Intelligence</span>
                </h1>
                <p className="text-lg text-slate-300 leading-relaxed font-light">
                    Orchestrate your supply chain with AI-driven insights, real-time tracking, and seamless automation designed for the modern warehouse.
                </p>
            </div>

            <div className="flex gap-6 animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-500">
                <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl flex items-center gap-4 min-w-[200px] hover:bg-white/10 transition-colors cursor-default">
                    <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-300 border border-emerald-500/20">
                        <Activity size={20} />
                    </div>
                    <div>
                        <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">System Status</p>
                        <p className="text-white font-semibold">Operational</p>
                    </div>
                </div>
                <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl flex items-center gap-4 min-w-[200px] hover:bg-white/10 transition-colors cursor-default">
                    <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-300 border border-blue-500/20">
                        <Package size={20} />
                    </div>
                    <div>
                        <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Managed Assets</p>
                        <p className="text-white font-semibold">1.2M+ Units</p>
                    </div>
                </div>
            </div>
        </div>
      </div>

      {/* RIGHT PANEL: Form Interaction */}
      <div className="flex-1 flex flex-col justify-center items-center p-6 lg:p-12 relative bg-white dark:bg-slate-900 transition-colors">
         
         <button 
           onClick={toggleTheme}
           className="absolute top-6 right-6 p-3 rounded-2xl bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-slate-700 transition-all shadow-sm border border-gray-200 dark:border-slate-700 group active:scale-95"
           title={theme === 'light' ? "Switch to Dark Mode" : "Switch to Light Mode"}
         >
           {theme === 'light' ? (
             <Moon size={20} className="group-hover:-rotate-12 transition-transform" />
           ) : (
             <Sun size={20} className="group-hover:rotate-45 transition-transform" />
           )}
         </button>

         <div className="w-full max-w-[400px]">
            <div className="lg:hidden flex items-center gap-2 mb-10 justify-center">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg">
                     <LayoutDashboard className="text-white" size={16} />
                </div>
                <span className="text-2xl font-bold text-gray-900 dark:text-white">Pam Pam</span>
            </div>

            {view === 'LOGIN' ? (
                <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                    <div className="mb-10">
                        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Welcome back</h2>
                        <p className="text-gray-500 dark:text-gray-400">Please enter your details to sign in.</p>
                    </div>

                    <form className="space-y-6" onSubmit={handleSubmit}>
                        <div className="space-y-4">
                            <div className="group">
                                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Email or Username</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                        <User className="h-5 w-5 text-gray-400 group-focus-within:text-blue-600 transition-colors" />
                                    </div>
                                    <input
                                        type="text"
                                        required
                                        value={username}
                                        onChange={(e) => setUsername(e.target.value)}
                                        className={`block w-full pl-11 pr-4 py-3 border rounded-xl leading-5 bg-white dark:bg-slate-800 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-sm border-gray-200 dark:border-slate-700`}
                                        placeholder="Enter email or username"
                                    />
                                </div>
                            </div>

                            <div className="group">
                                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Password</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                        <Lock className="h-5 w-5 text-gray-400 group-focus-within:text-blue-600 transition-colors" />
                                    </div>
                                    <input
                                        type={showPassword ? "text" : "password"}
                                        required
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        className={`block w-full pl-11 pr-11 py-3 border rounded-xl leading-5 bg-white dark:bg-slate-800 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-sm border-gray-200 dark:border-slate-700`}
                                        placeholder="Enter password"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-600 transition-colors focus:outline-none"
                                        tabIndex={-1}
                                    >
                                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-between">
                            <div className="flex items-center">
                                <input
                                    id="remember-me"
                                    name="remember-me"
                                    type="checkbox"
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-slate-700 rounded cursor-pointer transition-colors bg-white dark:bg-slate-800"
                                />
                                <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-600 dark:text-gray-400 cursor-pointer hover:text-gray-900 dark:hover:text-white select-none">
                                    Remember me
                                </label>
                            </div>

                            <button 
                                type="button"
                                onClick={() => { setView('FORGOT'); }}
                                className="text-sm font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 hover:underline transition-colors outline-none focus:ring-2 focus:ring-offset-1 focus:ring-blue-500 rounded"
                            >
                                Forgot password?
                            </button>
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            className={`w-full flex justify-center py-3.5 px-4 border border-transparent rounded-xl shadow-lg shadow-blue-600/20 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all transform active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none ${isLoading ? 'cursor-not-allowed' : ''}`}
                        >
                            {isLoading ? (
                                <div className="flex items-center gap-2">
                                    <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                    <span>Verifying...</span>
                                </div>
                            ) : (
                                <div className="flex items-center gap-2">
                                    Sign In <ArrowRight size={18} />
                                </div>
                            )}
                        </button>
                    </form>
                </div>
            ) : view === 'RESET' ? (
                <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                    <button 
                        onClick={() => { setView('LOGIN'); }} 
                        className="flex items-center gap-2 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white font-medium text-sm mb-8 transition-colors group"
                    >
                        <div className="p-1.5 rounded-full bg-gray-100 dark:bg-slate-800 group-hover:bg-gray-200 dark:group-hover:bg-slate-700 transition-colors">
                            <ArrowLeft size={16} />
                        </div>
                        Back to Login
                    </button>
                    
                    <div className="mb-8">
                        <div className="w-14 h-14 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center mb-6 shadow-sm border border-blue-100 dark:border-blue-900/30">
                            <KeyRound size={24} />
                        </div>
                        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Reset Password</h2>
                        <p className="mt-2 text-gray-500 dark:text-gray-400 leading-relaxed">
                            Create a new password for your account.
                        </p>
                    </div>

                    <form className="space-y-6" onSubmit={handleResetPassword}>
                        <div className="space-y-4">
                            <div className="group">
                                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">New Password</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                        <Lock className="h-5 w-5 text-gray-400 group-focus-within:text-blue-600 transition-colors" />
                                    </div>
                                    <input
                                        type={showPassword ? "text" : "password"}
                                        required
                                        value={newPassword}
                                        onChange={(e) => setNewPassword(e.target.value)}
                                        className={`block w-full pl-11 pr-11 py-3 border rounded-xl leading-5 bg-white dark:bg-slate-800 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-sm border-gray-200 dark:border-slate-700`}
                                        placeholder="Enter new password"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-600 transition-colors focus:outline-none"
                                        tabIndex={-1}
                                    >
                                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                    </button>
                                </div>
                            </div>

                            <div className="group">
                                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Confirm Password</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                        <Lock className="h-5 w-5 text-gray-400 group-focus-within:text-blue-600 transition-colors" />
                                    </div>
                                    <input
                                        type={showPassword ? "text" : "password"}
                                        required
                                        value={confirmPassword}
                                        onChange={(e) => setConfirmPassword(e.target.value)}
                                        className={`block w-full pl-11 pr-11 py-3 border rounded-xl leading-5 bg-white dark:bg-slate-800 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-sm border-gray-200 dark:border-slate-700`}
                                        placeholder="Confirm new password"
                                    />
                                </div>
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            className={`w-full flex justify-center py-3.5 px-4 border border-transparent rounded-xl shadow-lg shadow-blue-600/20 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all transform active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none ${isLoading ? 'cursor-not-allowed' : ''}`}
                        >
                            {isLoading ? (
                                <div className="flex items-center gap-2">
                                    <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                    <span>Updating...</span>
                                </div>
                            ) : (
                                'Set New Password'
                            )}
                        </button>
                    </form>
                </div>
            ) : (
                <div className="animate-in fade-in slide-in-from-right-4 duration-500">
                    <button 
                        onClick={() => { setView('LOGIN'); setResetStatus('IDLE'); }} 
                        className="flex items-center gap-2 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white font-medium text-sm mb-8 transition-colors group"
                    >
                        <div className="p-1.5 rounded-full bg-gray-100 dark:bg-slate-800 group-hover:bg-gray-200 dark:group-hover:bg-slate-700 transition-colors">
                            <ArrowLeft size={16} />
                        </div>
                        Back to Login
                    </button>
                    
                    <div className="mb-8">
                        <div className="w-14 h-14 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center mb-6 shadow-sm border border-blue-100 dark:border-blue-900/30">
                            <Lock size={24} />
                        </div>
                        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Forgot Password?</h2>
                        <p className="mt-2 text-gray-500 dark:text-gray-400 leading-relaxed">
                            No worries! Enter the email address associated with your account and we'll send you a recovery link.
                        </p>
                    </div>

                    {resetStatus === 'SENT' ? (
                        <div className="bg-green-50 dark:bg-green-900/10 border border-green-100 dark:border-green-900/30 rounded-xl p-8 text-center animate-in zoom-in-95 duration-300">
                            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white dark:border-slate-800 shadow-sm">
                                <CheckCircle2 size={32} />
                            </div>
                            <h3 className="text-green-800 dark:text-green-300 font-bold text-xl mb-2">Check your inbox</h3>
                            <p className="text-green-700/80 dark:text-green-400 text-sm mb-6">
                                We've sent password reset instructions to <br/><span className="font-bold text-green-800 dark:text-green-200">{resetEmail}</span>
                            </p>
                            <button 
                                onClick={() => setView('LOGIN')}
                                className="w-full py-3 bg-white dark:bg-slate-800 text-green-700 dark:text-green-400 font-bold text-sm rounded-lg border border-green-200 dark:border-green-900/50 hover:bg-green-50 dark:hover:bg-slate-700 transition-colors shadow-sm"
                            >
                                Return to Login
                            </button>
                            <button 
                                onClick={() => setView('RESET')}
                                className="mt-4 text-xs text-green-600 dark:text-green-500 hover:underline opacity-80"
                            >
                                (Demo) Simulate clicking reset link
                            </button>
                        </div>
                    ) : (
                        <form className="space-y-6" onSubmit={handleForgotPassword}>
                            <div className="group">
                                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Email Address</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                        <Mail className="h-5 w-5 text-gray-400 group-focus-within:text-blue-600 transition-colors" />
                                    </div>
                                    <input
                                        type="email"
                                        required
                                        value={resetEmail}
                                        onChange={(e) => setResetEmail(e.target.value)}
                                        className="block w-full pl-11 pr-4 py-3 border border-gray-200 dark:border-slate-700 rounded-xl leading-5 bg-white dark:bg-slate-800 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-sm"
                                        placeholder="name@company.com"
                                        autoFocus
                                    />
                                </div>
                            </div>

                            <button
                                type="submit"
                                disabled={resetStatus === 'SENDING'}
                                className={`w-full flex justify-center py-3.5 px-4 border border-transparent rounded-xl shadow-lg shadow-blue-600/20 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all transform active:scale-[0.98] disabled:opacity-70`}
                            >
                                {resetStatus === 'SENDING' ? (
                                    <div className="flex items-center gap-2">
                                        <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                        <span>Sending Link...</span>
                                    </div>
                                ) : (
                                    'Send Reset Link'
                                )}
                            </button>
                        </form>
                    )}
                </div>
            )}
         </div>

         {/* Footer Links */}
         <div className="absolute bottom-6 w-full text-center">
             <div className="flex justify-center gap-6 text-sm text-gray-400 dark:text-gray-500 font-medium">
                <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Terms of Service</a>
                <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Help Center</a>
             </div>
         </div>
      </div>
    </div>
  );
};

export default Login;

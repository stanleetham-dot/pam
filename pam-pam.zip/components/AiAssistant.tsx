
import React, { useState, useRef, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { Send, Bot, User, Loader2, Sparkles, Mic, MicOff, MessageSquare, Radio, X, Image as ImageIcon, Paperclip } from 'lucide-react';
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";

interface Message {
  role: 'user' | 'model';
  text: string;
  image?: string;
  timestamp: Date;
}

// --- Audio Helpers ---

function base64ToUint8Array(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Convert Float32Array (from AudioBuffer) to PCM Int16 ArrayBuffer
function floatTo16BitPCM(input: Float32Array): ArrayBuffer {
  const output = new DataView(new ArrayBuffer(input.length * 2));
  for (let i = 0; i < input.length; i++) {
    let s = Math.max(-1, Math.min(1, input[i]));
    s = s < 0 ? s * 0x8000 : s * 0x7FFF;
    output.setInt16(i * 2, s, true); // Little endian
  }
  return output.buffer;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const AiAssistant: React.FC = () => {
  const { products, stats, transactions, currentUser, language } = useInventory();
  
  const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

  const [mode, setMode] = useState<'TEXT' | 'VOICE'>('TEXT');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: t("Hello! I'm Pam Pam AI. I can analyze your inventory, identify trends, or help you find specific items. You can also upload images for analysis.", "你好！我是 Pam Pam AI。我可以分析您的库存，识别趋势，或帮助您查找特定商品。您也可以上传图片进行分析。"), timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [isTextLoading, setIsTextLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Image Upload State
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [attachedImageMime, setAttachedImageMime] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isLiveConnected, setIsLiveConnected] = useState(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const [liveStatus, setLiveStatus] = useState<'DISCONNECTED' | 'CONNECTING' | 'LISTENING' | 'SPEAKING'>('DISCONNECTED');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const scheduledSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const liveSessionRef = useRef<Promise<any> | null>(null);

  useEffect(() => {
    if (mode === 'TEXT' && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, mode]);

  useEffect(() => {
    return () => {
      disconnectLive();
    };
  }, []);

  const getSystemInstruction = () => {
    const inventorySummary = products.slice(0, 50).map(p => `${p.name} (${p.stock} ${p.unit})`).join(', ');
    const langInstruction = language === 'ZH' ? 'Reply in Chinese (Simplified).' : 'Reply in English.';
    
    return `
      You are Pam Pam, an expert warehouse AI assistant. 
      You are talking to ${currentUser?.name || 'a user'}.
      ${langInstruction}
      
      Current Operational Stats:
      - Total SKUs: ${stats.totalProducts}
      - Low Stock Items: ${stats.lowStockItems}
      - Capacity: ${stats.warehouseCapacity}%
      
      Recent Activity:
      ${transactions.slice(0, 3).map(t => `- ${t.type}: ${t.productName} (${t.quantity})`).join('\n')}

      Partial Inventory List (Top 50):
      ${inventorySummary}

      Guidelines:
      1. Be concise, friendly, and professional.
      2. If asked about stock, use the provided data.
      3. If data is missing, admit it politely.
      4. For complex reasoning, think step-by-step.
      5. If an image is provided, analyze it in the context of warehouse operations (e.g., identify products, read labels, check condition).
    `;
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (evt) => {
        const base64 = evt.target?.result as string;
        setAttachedImage(base64);
        setAttachedImageMime(file.type);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleTextSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !attachedImage) || isTextLoading) return;

    const userMsg: Message = { 
        role: 'user', 
        text: input, 
        image: attachedImage || undefined,
        timestamp: new Date() 
    };
    
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setAttachedImage(null);
    setAttachedImageMime('');
    setIsTextLoading(true);

    try {
      if ((window as any).aistudio && (window as any).aistudio.openSelectKey) {
          const hasKey = await (window as any).aistudio.hasSelectedApiKey();
          if (!hasKey) {
              await (window as any).aistudio.openSelectKey();
          }
      }
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const parts: any[] = [];
      
      if (userMsg.image) {
          const base64Data = userMsg.image.split(',')[1];
          const mimeType = userMsg.image.match(/[^:]\w+\/[\w-+\d.]+(?=;|,)/)?.[0] || 'image/jpeg';
          
          parts.push({
              inlineData: {
                  mimeType: mimeType,
                  data: base64Data
              }
          });
      }

      parts.push({ text: getSystemInstruction() + "\n\nUser Question: " + userMsg.text });

      // Use Thinking Mode for complex reasoning with gemini-3-pro-preview
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: [
            { role: 'user', parts: parts }
        ],
        config: {
            thinkingConfig: { thinkingBudget: 32768 } // Maximum thinking budget for deep reasoning
        }
      });

      const text = response.text || t("I'm sorry, I couldn't generate a response.", "抱歉，我无法生成回复。");
      setMessages(prev => [...prev, { role: 'model', text: text, timestamp: new Date() }]);

    } catch (error: any) {
      console.error("AI Error:", error);
      if (error?.message?.includes("Requested entity was not found.")) {
          await (window as any).aistudio?.openSelectKey();
      }
      setMessages(prev => [...prev, { role: 'model', text: t("I encountered an error connecting to the AI service.", "连接 AI 服务时出错。"), timestamp: new Date() }]);
    } finally {
      setIsTextLoading(false);
    }
  };

  const connectLive = async () => {
    if (isLiveConnected) return;
    setLiveStatus('CONNECTING');

    try {
      if ((window as any).aistudio && (window as any).aistudio.openSelectKey) {
          const hasKey = await (window as any).aistudio.hasSelectedApiKey();
          if (!hasKey) {
              await (window as any).aistudio.openSelectKey();
          }
      }

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContext({ sampleRate: 16000 });
      audioContextRef.current = ctx;
      nextStartTimeRef.current = ctx.currentTime;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: getSystemInstruction(),
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
        },
        callbacks: {
          onopen: async () => {
            setIsLiveConnected(true);
            setLiveStatus('LISTENING');
            
            try {
              const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
              const source = ctx.createMediaStreamSource(stream);
              const processor = ctx.createScriptProcessor(4096, 1, 1);
              
              processor.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                const pcm16 = floatTo16BitPCM(inputData);
                const base64 = arrayBufferToBase64(pcm16);
                
                sessionPromise.then(session => {
                    session.sendRealtimeInput({
                        media: {
                            mimeType: 'audio/pcm;rate=16000',
                            data: base64
                        }
                    });
                });
              };

              source.connect(processor);
              processor.connect(ctx.destination);
              
              inputSourceRef.current = source;
              processorRef.current = processor;
            } catch (err) {
              console.error("Mic Error", err);
              setLiveStatus('DISCONNECTED');
            }
          },
          onmessage: async (msg: LiveServerMessage) => {
            const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData) {
                setLiveStatus('SPEAKING');
                const audioCtx = audioContextRef.current;
                if (audioCtx) {
                    const audioBuffer = await decodeAudioData(
                        base64ToUint8Array(audioData),
                        audioCtx,
                        24000,
                        1
                    );
                    
                    const source = audioCtx.createBufferSource();
                    source.buffer = audioBuffer;
                    source.connect(audioCtx.destination);
                    
                    const now = audioCtx.currentTime;
                    nextStartTimeRef.current = Math.max(nextStartTimeRef.current, now);
                    
                    source.start(nextStartTimeRef.current);
                    nextStartTimeRef.current += audioBuffer.duration;
                    
                    scheduledSourcesRef.current.push(source);
                    
                    source.onended = () => {
                        scheduledSourcesRef.current = scheduledSourcesRef.current.filter(s => s !== source);
                        if (scheduledSourcesRef.current.length === 0) {
                            setLiveStatus('LISTENING');
                        }
                    };
                }
            }

            if (msg.serverContent?.interrupted) {
                scheduledSourcesRef.current.forEach(s => s.stop());
                scheduledSourcesRef.current = [];
                if (audioContextRef.current) nextStartTimeRef.current = audioContextRef.current.currentTime;
                setLiveStatus('LISTENING');
            }
          },
          onclose: () => {
            setIsLiveConnected(false);
            setLiveStatus('DISCONNECTED');
          },
          onerror: (err) => {
            console.error("Live API Error", err);
            setLiveStatus('DISCONNECTED');
            setIsLiveConnected(false);
          }
        }
      });
      
      liveSessionRef.current = sessionPromise;

    } catch (err) {
      console.error("Connection failed", err);
      setLiveStatus('DISCONNECTED');
    }
  };

  const disconnectLive = () => {
    if (liveSessionRef.current) {
        liveSessionRef.current.then((session: any) => session.close());
        liveSessionRef.current = null;
    }
    
    if (inputSourceRef.current) inputSourceRef.current.disconnect();
    if (processorRef.current) processorRef.current.disconnect();
    
    if (audioContextRef.current) {
        audioContextRef.current.close();
        audioContextRef.current = null;
    }
    
    setIsLiveConnected(false);
    setLiveStatus('DISCONNECTED');
  };

  const toggleMic = () => {
      if (inputSourceRef.current && inputSourceRef.current.mediaStream) {
          inputSourceRef.current.mediaStream.getAudioTracks().forEach(track => {
              track.enabled = !track.enabled;
          });
          setIsMicOn(!isMicOn);
      }
  };

  const handleModeSwitch = (newMode: 'TEXT' | 'VOICE') => {
      if (mode === newMode) return;
      if (newMode === 'TEXT') {
          disconnectLive();
      }
      setMode(newMode);
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-2xl shadow-sm overflow-hidden border border-gray-200 dark:border-slate-800 transition-colors">
      {/* Header */}
      <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${mode === 'VOICE' && isLiveConnected ? 'bg-red-50 text-red-500 animate-pulse' : 'bg-blue-50 text-blue-600'} dark:bg-slate-800 dark:text-blue-400`}>
            {mode === 'VOICE' ? <Radio size={20} /> : <Bot size={20} />}
          </div>
          <div>
            <h3 className="font-bold text-gray-800 dark:text-white">Pam Pam AI</h3>
            <div className="flex items-center gap-1.5">
               <span className={`w-2 h-2 rounded-full ${mode === 'VOICE' && isLiveConnected ? 'bg-green-500' : 'bg-gray-300'}`}></span>
               <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">{mode === 'VOICE' && isLiveConnected ? 'Live Active' : 'Ready'}</span>
            </div>
          </div>
        </div>
        <div className="flex bg-gray-100 dark:bg-slate-800 p-1 rounded-lg">
            <button onClick={() => handleModeSwitch('TEXT')} className={`p-2 rounded-md transition-all ${mode === 'TEXT' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}><MessageSquare size={18}/></button>
            <button onClick={() => handleModeSwitch('VOICE')} className={`p-2 rounded-md transition-all ${mode === 'VOICE' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}><Mic size={18}/></button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/30 dark:bg-slate-950/30" ref={scrollRef}>
        {mode === 'TEXT' ? (
            <>
                {messages.map((msg, idx) => (
                    <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400' : 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'}`}>
                            {msg.role === 'user' ? <User size={16}/> : <Sparkles size={16}/>}
                        </div>
                        <div className={`p-3 rounded-2xl max-w-[80%] text-sm ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white dark:bg-slate-800 text-gray-800 dark:text-gray-200 border border-gray-100 dark:border-slate-700 rounded-tl-none shadow-sm'}`}>
                            {msg.image && (
                                <img src={msg.image} alt="User upload" className="max-w-full rounded-lg mb-2 border border-white/20" />
                            )}
                            <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                            <span className={`text-[10px] block mt-1 opacity-70 ${msg.role === 'user' ? 'text-indigo-200' : 'text-gray-400'}`}>{msg.timestamp.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
                        </div>
                    </div>
                ))}
                {isTextLoading && (
                    <div className="flex gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0"><Sparkles size={16}/></div>
                        <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl rounded-tl-none shadow-sm border border-gray-100 dark:border-slate-700 flex items-center gap-2">
                            <Loader2 size={16} className="animate-spin text-blue-500"/>
                            <span className="text-xs text-gray-500 dark:text-gray-400">Thinking...</span>
                        </div>
                    </div>
                )}
            </>
        ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8">
                <div className={`relative w-32 h-32 rounded-full flex items-center justify-center mb-8 transition-all duration-500 ${liveStatus === 'LISTENING' ? 'bg-blue-50 dark:bg-blue-900/20 scale-110' : liveStatus === 'SPEAKING' ? 'bg-green-50 dark:bg-green-900/20 scale-125' : 'bg-gray-100 dark:bg-slate-800'}`}>
                    {liveStatus === 'LISTENING' && <div className="absolute inset-0 rounded-full border-4 border-blue-500 opacity-20 animate-ping"></div>}
                    {liveStatus === 'SPEAKING' && <div className="absolute inset-0 rounded-full border-4 border-green-500 opacity-20 animate-ping"></div>}
                    
                    {liveStatus === 'CONNECTING' ? <Loader2 size={48} className="text-blue-500 animate-spin"/> :
                     liveStatus === 'SPEAKING' ? <Radio size={48} className="text-green-500 animate-pulse"/> :
                     <Mic size={48} className={isLiveConnected ? "text-blue-500" : "text-gray-400"}/>}
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                    {liveStatus === 'DISCONNECTED' ? t("Voice Mode Ready", "语音模式就绪") : 
                     liveStatus === 'CONNECTING' ? t("Connecting...", "连接中...") :
                     liveStatus === 'LISTENING' ? t("Listening...", "正在聆听...") : 
                     t("Speaking...", "正在说话...")}
                </h3>
                
                <p className="text-gray-500 dark:text-gray-400 max-w-xs mx-auto mb-8 text-sm">
                    {liveStatus === 'DISCONNECTED' ? t("Tap the button below to start a voice conversation with Pam Pam.", "点击下方按钮开始与 Pam Pam 进行语音对话。") : 
                     t("I'm listening to your questions about inventory.", "我正在聆听关于库存的问题。")}
                </p>

                {!isLiveConnected ? (
                    <button 
                        onClick={connectLive}
                        className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-bold shadow-lg shadow-blue-200 dark:shadow-blue-900/20 transition-all transform hover:scale-105 flex items-center gap-2"
                    >
                        <Mic size={20} /> {t("Start Conversation", "开始对话")}
                    </button>
                ) : (
                    <div className="flex gap-4">
                        <button 
                            onClick={toggleMic}
                            className={`p-4 rounded-full transition-all ${isMicOn ? 'bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200' : 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'}`}
                        >
                            {isMicOn ? <Mic size={24} /> : <MicOff size={24} />}
                        </button>
                        <button 
                            onClick={disconnectLive}
                            className="px-8 py-4 bg-red-600 hover:bg-red-700 text-white rounded-full font-bold shadow-lg shadow-red-200 dark:shadow-red-900/20 transition-all transform hover:scale-105"
                        >
                            {t("End Call", "结束通话")}
                        </button>
                    </div>
                )}
            </div>
        )}
      </div>

      {/* Input Area (Text Mode Only) */}
      {mode === 'TEXT' && (
          <div className="p-4 bg-white dark:bg-slate-900 border-t border-gray-100 dark:border-slate-800">
            {attachedImage && (
                <div className="relative mb-3 inline-block">
                    <img src={attachedImage} alt="Preview" className="h-16 w-16 object-cover rounded-lg border border-gray-200 dark:border-slate-700" />
                    <button onClick={() => { setAttachedImage(null); setAttachedImageMime(''); }} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600"><X size={12}/></button>
                </div>
            )}
            <form onSubmit={handleTextSend} className="flex gap-2">
                <button 
                    type="button" 
                    onClick={() => fileInputRef.current?.click()}
                    className="p-3 text-gray-400 hover:text-blue-600 dark:text-gray-500 dark:hover:text-blue-400 hover:bg-gray-50 dark:hover:bg-slate-800 rounded-xl transition-colors"
                >
                    <Paperclip size={20} />
                </button>
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleImageSelect}
                />
                <input 
                    className="flex-1 bg-gray-50 dark:bg-slate-800 border-none rounded-xl px-4 text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:text-white placeholder:text-gray-400"
                    placeholder={t("Ask Pam Pam...", "询问 Pam Pam...")}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    disabled={isTextLoading}
                />
                <button 
                    type="submit" 
                    disabled={!input.trim() && !attachedImage || isTextLoading}
                    className="p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-md transition-all active:scale-95"
                >
                    <Send size={20} />
                </button>
            </form>
          </div>
      )}
    </div>
  );
};

export default AiAssistant;


import React, { useState, useRef } from 'react';
import { useInventory } from '../context/InventoryContext';
import { DistributionOutlet } from '../types';
import { 
    Search, Plus, MapPin, Phone, Truck, Clock, Calendar, 
    Edit2, Trash2, Save, X, Building, AlertTriangle, User, Mail,
    FileDown, UploadCloud, RefreshCcw, CheckCircle2, Copy
} from 'lucide-react';
import * as XLSX from 'xlsx';

const InputField = ({ label, value, onChange, required = false, placeholder = '', icon: Icon }: any) => (
    <div className="space-y-1.5">
        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            {required && <span className="text-red-500 mr-1">*</span>}{label}
        </label>
        <div className="relative group">
            {Icon && (
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-500 transition-colors">
                    <Icon size={16} />
                </div>
            )}
            <input 
                className={`w-full ${Icon ? 'pl-10' : 'px-4'} pr-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm font-medium text-gray-900 dark:text-white placeholder:text-gray-400`}
                value={value}
                onChange={e => onChange(e.target.value)}
                placeholder={placeholder}
            />
        </div>
    </div>
);

const SelectField = ({ label, value, onChange, options, icon: Icon }: any) => (
    <div className="space-y-1.5">
        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            {label}
        </label>
        <div className="relative group">
            {Icon && (
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-500 transition-colors">
                    <Icon size={16} />
                </div>
            )}
            <select 
                className={`w-full ${Icon ? 'pl-10' : 'px-4'} pr-10 py-2.5 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm font-medium text-gray-900 dark:text-white appearance-none cursor-pointer`}
                value={value}
                onChange={e => onChange(e.target.value)}
            >
                {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
            </select>
            <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
                <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
            </div>
        </div>
    </div>
);

const DistributionMethodManager: React.FC = () => {
    const { outlets, addOutlet, bulkAddOutlets, updateOutlet, deleteOutlet, language } = useInventory();
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [deleteId, setDeleteId] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    // Import Analysis State
    const [importConflict, setImportConflict] = useState<{
        isOpen: boolean;
        newItems: Omit<DistributionOutlet, 'id'>[];
        conflicts: { newData: Omit<DistributionOutlet, 'id'>; existingId: string }[];
    }>({ isOpen: false, newItems: [], conflicts: [] });

    const [formData, setFormData] = useState<Partial<DistributionOutlet>>({
        recipient: '',
        phone: '',
        deliveryMethod: 'Door-to-door Small Cargo',
        postCode: '',
        address: '',
        unit: '',
        deliveryTime: '',
        sendPeriod: ''
    });

    const filteredOutlets = (outlets || []).filter(outlet => 
        (outlet.recipient?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
        (outlet.address?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
        (outlet.phone || '').includes(searchTerm)
    );

    const handleEdit = (outlet: DistributionOutlet) => {
        setFormData(outlet);
        setEditingId(outlet.id);
        setIsModalOpen(true);
    };

    const handleAdd = () => {
        setFormData({
            recipient: '',
            phone: '',
            deliveryMethod: 'Door-to-door Small Cargo',
            postCode: '',
            address: '',
            unit: '',
            deliveryTime: '',
            sendPeriod: ''
        });
        setEditingId(null);
        setIsModalOpen(true);
    };

    const handleSave = () => {
        // Validation with clear user feedback
        const missingFields = [];
        if (!formData.recipient) missingFields.push(t('Recipient', '收件人'));
        if (!formData.phone) missingFields.push(t('Phone', '电话'));
        if (!formData.address) missingFields.push(t('Address', '地址'));
        if (!formData.postCode) missingFields.push(t('PostCode', '邮编'));

        if (missingFields.length > 0) {
            alert(`${t("Please fill in required fields:", "请填写必填字段：")} ${missingFields.join(', ')}`);
            return;
        }

        try {
            if (editingId) {
                if (updateOutlet) updateOutlet({ ...formData, id: editingId } as DistributionOutlet);
            } else {
                if (addOutlet) addOutlet(formData as Omit<DistributionOutlet, 'id'>);
            }
            setIsModalOpen(false);
        } catch (error) {
            console.error("Failed to save outlet", error);
            alert(t("Failed to save. Please try again.", "保存失败，请重试。"));
        }
    };

    const confirmDelete = (id: string) => {
        setDeleteId(id);
        setIsDeleteModalOpen(true);
    };

    const executeDelete = () => {
        if (deleteId) {
            if (deleteOutlet) deleteOutlet(deleteId);
            setIsDeleteModalOpen(false);
            setDeleteId(null);
        }
    };

    const handleDownloadTemplate = () => {
        const headers = [
            'Recipient Name', 'Phone Number', 'Delivery Method', 'Postal Code', 
            'Street Address', 'Unit Number', 'Preferred Delivery Time', 'Send Period'
        ];
        const sampleData = [
            ['Acme Corp', '+65 9123 4567', 'Door-to-door Small Cargo', '123456', '123 Tech Park Drive', '#04-01', '09:00 - 12:00', 'Mon-Fri']
        ];
        
        const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleData]);
        
        // Adjust column widths
        const wscols = [
            {wch: 20}, {wch: 15}, {wch: 25}, {wch: 10}, 
            {wch: 30}, {wch: 10}, {wch: 20}, {wch: 15}
        ];
        ws['!cols'] = wscols;

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Outlets Template");
        XLSX.writeFile(wb, "Distribution_Outlet_Import_Template.xlsx");
    };

    const handleBulkImport = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (evt) => {
            try {
                const data = evt.target?.result;
                const wb = XLSX.read(data, { type: 'array' });
                const ws = wb.Sheets[wb.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json<any>(ws);

                if (jsonData.length === 0) {
                    alert(t("The file appears to be empty.", "文件似乎为空。"));
                    return;
                }

                const parsedNewItems: Omit<DistributionOutlet, 'id'>[] = [];
                const parsedConflicts: { newData: Omit<DistributionOutlet, 'id'>; existingId: string }[] = [];
                let errorCount = 0;

                jsonData.forEach((row) => {
                    // Mapping columns to data structure
                    const recipient = String(row['Recipient Name'] || row['Recipient'] || row['收件人'] || '').trim();
                    const phone = String(row['Phone Number'] || row['Phone'] || row['电话'] || '').trim();
                    const address = String(row['Street Address'] || row['Address'] || row['地址'] || '').trim();
                    
                    if (recipient && address) {
                        const newOutlet: Omit<DistributionOutlet, 'id'> = {
                            recipient,
                            phone,
                            deliveryMethod: row['Delivery Method'] || row['Delivery Type'] || 'Door-to-door Small Cargo',
                            postCode: String(row['Postal Code'] || row['PostCode'] || row['邮编'] || '').trim(),
                            address,
                            unit: String(row['Unit Number'] || row['Unit'] || row['单元号'] || '').trim(),
                            deliveryTime: row['Preferred Delivery Time'] || row['Delivery Time'] || '',
                            sendPeriod: row['Send Period'] || ''
                        };

                        // Check for duplicates based on Recipient Name only (case-insensitive)
                        const existing = outlets.find(o => 
                            o.recipient.toLowerCase() === recipient.toLowerCase()
                        );

                        if (existing) {
                            parsedConflicts.push({ newData: newOutlet, existingId: existing.id });
                        } else {
                            parsedNewItems.push(newOutlet);
                        }
                    } else {
                        errorCount++;
                    }
                });

                if (parsedConflicts.length > 0) {
                    setImportConflict({
                        isOpen: true,
                        newItems: parsedNewItems,
                        conflicts: parsedConflicts
                    });
                } else if (parsedNewItems.length > 0) {
                    bulkAddOutlets(parsedNewItems).then(() => {
                        alert(t(`Successfully imported ${parsedNewItems.length} new methods.`, `成功导入 ${parsedNewItems.length} 个新方式。`));
                    });
                } else {
                    alert(t("No valid data found to import.", "未找到可导入的有效数据。"));
                }

                if (fileInputRef.current) fileInputRef.current.value = '';

            } catch (err) {
                console.error("Import Error", err);
                alert(t("Failed to parse Excel file.", "解析 Excel 文件失败。"));
            }
        };
        reader.readAsArrayBuffer(file);
    };

    const resolveImport = (strategy: 'REPLACE' | 'SKIP') => {
        const { newItems, conflicts } = importConflict;
        let count = 0;

        // 1. Add all non-conflicting items in bulk
        if (newItems.length > 0) {
            bulkAddOutlets(newItems);
            count += newItems.length;
        }

        // 2. Handle conflicts
        if (strategy === 'REPLACE') {
            conflicts.forEach(({ newData, existingId }) => {
                updateOutlet({ ...newData, id: existingId } as DistributionOutlet);
                count++;
            });
            alert(t(`Imported ${count} items (replaced ${conflicts.length} duplicates).`, `导入了 ${count} 条数据（覆盖了 ${conflicts.length} 条重复数据）。`));
        } else {
            alert(t(`Imported ${newItems.length} items (skipped ${conflicts.length} duplicates).`, `导入了 ${newItems.length} 条数据（跳过了 ${conflicts.length} 条重复数据）。`));
        }

        setImportConflict({ isOpen: false, newItems: [], conflicts: [] });
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 transition-colors p-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                <div>
                    <h1 className="text-2xl font-extrabold text-gray-900 dark:text-white flex items-center gap-2">
                        <Truck className="text-blue-600 dark:text-blue-400" size={28} />
                        {t('Distribution Method', '配送方式')}
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-1 font-medium">{t('Register outlets and customer delivery details.', '注册网点和客户配送详情。')}</p>
                </div>
                <div className="flex gap-2">
                    <button 
                        onClick={handleDownloadTemplate}
                        className="px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 rounded-xl font-bold hover:bg-gray-50 dark:hover:bg-slate-700 transition-all flex items-center gap-2 shadow-sm"
                    >
                        <FileDown size={18} /> {t('Template', '模板')}
                    </button>
                    <div className="relative">
                        <button 
                            onClick={() => fileInputRef.current?.click()}
                            className="px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 rounded-xl font-bold hover:bg-gray-50 dark:hover:bg-slate-700 transition-all flex items-center gap-2 shadow-sm"
                        >
                            <UploadCloud size={18} /> {t('Import', '导入')}
                        </button>
                        <input 
                            ref={fileInputRef} 
                            type="file" 
                            className="hidden" 
                            accept=".xlsx, .xls" 
                            onChange={handleBulkImport} 
                        />
                    </div>
                    <button 
                        onClick={handleAdd}
                        className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-200 dark:shadow-none transition-all flex items-center gap-2 active:scale-95"
                    >
                        <Plus size={18} strokeWidth={3} /> {t('Create Method', '创建方式')}
                    </button>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col flex-1 overflow-hidden transition-colors">
                <div className="p-4 border-b border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-950/50">
                    <div className="relative max-w-md">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                        <input 
                            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-gray-400 dark:text-white"
                            placeholder={t("Search recipient, address...", "搜索收件人, 地址...")}
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-auto p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {filteredOutlets.map(outlet => (
                            <div key={outlet.id} className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-2xl p-5 hover:shadow-md transition-all group relative">
                                <div className="flex justify-between items-start mb-3">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-lg border border-blue-100 dark:border-blue-900/50 uppercase">
                                            {outlet.recipient.charAt(0)}
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-gray-900 dark:text-white line-clamp-1">{outlet.recipient}</h3>
                                            <p className="text-xs text-gray-500 dark:text-gray-400 font-medium flex items-center gap-1">
                                                <Phone size={10} /> {outlet.phone}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); handleEdit(outlet); }} 
                                            className="p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                                            title={t("Edit", "编辑")}
                                        >
                                            <Edit2 size={16} />
                                        </button>
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); confirmDelete(outlet.id); }} 
                                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                            title={t("Delete", "删除")}
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </div>
                                
                                <div className="space-y-2 text-sm">
                                    <div className="flex items-start gap-2 text-gray-600 dark:text-gray-300">
                                        <MapPin size={16} className="text-gray-400 shrink-0 mt-0.5" />
                                        <span>{outlet.address} {outlet.unit && `, ${outlet.unit}`} <br/><span className="text-xs text-gray-400 font-mono">{outlet.postCode}</span></span>
                                    </div>
                                    <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                                        <Truck size={16} className="text-gray-400 shrink-0" />
                                        <span className="bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded text-xs font-bold">{outlet.deliveryMethod}</span>
                                    </div>
                                    {(outlet.deliveryTime || outlet.sendPeriod) && (
                                        <div className="flex items-center gap-3 mt-2 pt-2 border-t border-gray-100 dark:border-slate-700">
                                            {outlet.deliveryTime && (
                                                <span className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400 bg-blue-50 dark:bg-slate-700 px-2 py-1 rounded">
                                                    <Clock size={12} /> {outlet.deliveryTime}
                                                </span>
                                            )}
                                            {outlet.sendPeriod && (
                                                <span className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400 bg-purple-50 dark:bg-slate-700 px-2 py-1 rounded">
                                                    <Calendar size={12} /> {outlet.sendPeriod}
                                                </span>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                    {filteredOutlets.length === 0 && (
                        <div className="flex flex-col items-center justify-center py-20 text-gray-400 dark:text-gray-600">
                            <Building size={48} className="mb-4 opacity-20" />
                            <p className="font-bold">{t("No outlets found", "未找到网点")}</p>
                        </div>
                    )}
                </div>
            </div>

            {/* CONFLICT RESOLUTION MODAL */}
            {importConflict.isOpen && (
                <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-gray-100 dark:border-slate-800">
                        <div className="p-6 border-b border-gray-100 dark:border-slate-800 bg-amber-50 dark:bg-amber-900/10 flex items-center gap-4">
                            <div className="w-12 h-12 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-amber-600 dark:text-amber-400">
                                <AlertTriangle size={24} />
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('Duplicate Data Found', '发现重复数据')}</h3>
                                <p className="text-sm text-gray-600 dark:text-gray-400">The file contains outlets that already exist in the system.</p>
                            </div>
                        </div>
                        
                        <div className="p-6 space-y-4">
                            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-slate-800 rounded-xl border border-gray-100 dark:border-slate-700">
                                <div>
                                    <span className="block text-xs font-bold text-gray-400 uppercase tracking-wider">New Unique Records</span>
                                    <span className="text-2xl font-black text-green-600 dark:text-green-400">{importConflict.newItems.length}</span>
                                </div>
                                <div className="h-8 w-px bg-gray-300 dark:bg-slate-600"></div>
                                <div>
                                    <span className="block text-xs font-bold text-gray-400 uppercase tracking-wider">Conflicting Records</span>
                                    <span className="text-2xl font-black text-amber-600 dark:text-amber-400">{importConflict.conflicts.length}</span>
                                </div>
                            </div>
                            
                            <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
                                {t(
                                    "We found existing records with the same Recipient Name in the import file. Would you like to overwrite existing details with the new information, or skip these and keep the old data?",
                                    "我们在导入文件中发现了相同名称的收件人。您是想用新信息覆盖现有详情，还是跳过这些并保留旧数据？"
                                )}
                            </p>

                            {/* NEW SECTION: List of duplicates */}
                            {importConflict.conflicts.length > 0 && (
                                <div className="bg-amber-50/50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 rounded-xl overflow-hidden">
                                    <div className="px-4 py-2 bg-amber-100/50 dark:bg-amber-900/30 border-b border-amber-200 dark:border-amber-800/50">
                                        <span className="text-xs font-bold text-amber-800 dark:text-amber-300 uppercase tracking-wider">
                                            {t('Conflicting Recipients', '冲突收件人')}
                                        </span>
                                    </div>
                                    <div className="max-h-48 overflow-y-auto p-0">
                                        <table className="w-full text-left">
                                            <tbody className="divide-y divide-amber-100 dark:divide-amber-800/30">
                                                {importConflict.conflicts.map((item, idx) => (
                                                    <tr key={idx} className="hover:bg-amber-100/30 transition-colors">
                                                        <td className="px-4 py-2">
                                                            <div className="font-bold text-sm text-gray-900 dark:text-white">{item.newData.recipient}</div>
                                                            <div className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1">{item.newData.address}</div>
                                                        </td>
                                                        <td className="px-4 py-2 text-right">
                                                            <span className="text-[10px] font-mono text-gray-400">{item.newData.phone}</span>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="p-6 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-950 flex gap-3">
                            <button 
                                onClick={() => setImportConflict({ isOpen: false, newItems: [], conflicts: [] })}
                                className="flex-1 py-3 bg-white dark:bg-slate-800 text-gray-700 dark:text-gray-300 font-bold rounded-xl border border-gray-200 dark:border-slate-700 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                            >
                                {t('Cancel Import', '取消导入')}
                            </button>
                            <button 
                                onClick={() => resolveImport('SKIP')}
                                className="flex-1 py-3 bg-gray-200 dark:bg-slate-700 text-gray-800 dark:text-white font-bold rounded-xl hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
                            >
                                <Copy size={18} /> {t('Skip Duplicates', '跳过重复')}
                            </button>
                            <button 
                                onClick={() => resolveImport('REPLACE')}
                                className="flex-1 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-none transition-all active:scale-95 flex items-center justify-center gap-2"
                            >
                                <RefreshCcw size={18} /> {t('Replace All', '全部覆盖')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {isModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                    <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-2xl flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200">
                        {/* Header */}
                        <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50 dark:bg-slate-950 rounded-t-2xl shrink-0">
                            <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                                <Truck className="text-blue-600 dark:text-blue-400" />
                                {editingId ? t('Edit Distribution Method', '编辑配送方式') : t('New Distribution Method', '新建配送方式')}
                            </h3>
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors">
                                <X size={20} />
                            </button>
                        </div>
                        
                        {/* Scrollable Content */}
                        <div className="flex-1 overflow-y-auto p-8 space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <InputField 
                                    label={t("Recipient", "收件人")} 
                                    value={formData.recipient} 
                                    onChange={(v: string) => setFormData({...formData, recipient: v})} 
                                    required 
                                    icon={User}
                                    placeholder="e.g. Acme Corp"
                                />
                                <InputField 
                                    label={t("Phone", "电话")} 
                                    value={formData.phone} 
                                    onChange={(v: string) => setFormData({...formData, phone: v})} 
                                    required 
                                    icon={Phone}
                                    placeholder="+1 234 567 890"
                                />
                            </div>
                            
                            <SelectField 
                                label={t("Delivery Method", "配送方式")}
                                value={formData.deliveryMethod} 
                                onChange={(v: string) => setFormData({...formData, deliveryMethod: v})}
                                options={['Door-to-door Small Cargo', 'Self Collection', 'Courier Service', 'Internal Transfer']}
                                icon={Truck}
                            />

                            <div className="grid grid-cols-3 gap-4">
                                <div className="col-span-1">
                                    <InputField label={t("PostCode", "邮编")} value={formData.postCode} onChange={(v: string) => setFormData({...formData, postCode: v})} required placeholder="123456" />
                                </div>
                                <div className="col-span-2">
                                    <InputField label={t("Unit No", "单元号")} value={formData.unit} onChange={(v: string) => setFormData({...formData, unit: v})} placeholder="#01-01" />
                                </div>
                            </div>

                            <div className="space-y-1.5">
                                <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                    <span className="text-red-500 mr-1">*</span>{t("Address", "地址")}
                                </label>
                                <div className="relative group">
                                    <div className="absolute left-3 top-3 text-gray-400 group-focus-within:text-blue-500 transition-colors">
                                        <MapPin size={16} />
                                    </div>
                                    <textarea 
                                        className="w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm font-medium text-gray-900 dark:text-white placeholder:text-gray-400 resize-none"
                                        rows={3}
                                        value={formData.address}
                                        onChange={e => setFormData({...formData, address: e.target.value})}
                                        placeholder={t("Full Street Address...", "详细街道地址...")}
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <SelectField 
                                    label={t("Delivery Time", "配送时间")}
                                    value={formData.deliveryTime} 
                                    onChange={(v: string) => setFormData({...formData, deliveryTime: v})}
                                    options={['', '09:00 - 12:00', '12:00 - 15:00', '15:00 - 18:00', '18:00 - 21:00', 'Anytime']}
                                    icon={Clock}
                                />
                                <SelectField 
                                    label={t("Send Period", "发送周期")}
                                    value={formData.sendPeriod} 
                                    onChange={(v: string) => setFormData({...formData, sendPeriod: v})}
                                    options={['', 'Mon-Fri', 'Weekends Only', 'Daily', 'Ad-hoc']}
                                    icon={Calendar}
                                />
                            </div>
                        </div>

                        {/* Fixed Footer */}
                        <div className="p-6 pt-4 flex gap-3 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-950 rounded-b-2xl shrink-0">
                            <button 
                                onClick={() => setIsModalOpen(false)} 
                                className="flex-1 py-3 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 font-bold rounded-xl hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors text-sm"
                            >
                                {t('Cancel', '取消')}
                            </button>
                            <button 
                                onClick={handleSave} 
                                className="flex-1 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-none transition-all active:scale-95 text-sm flex items-center justify-center gap-2"
                            >
                                <Save size={18} /> {t('Save Outlet', '保存网点')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {isDeleteModalOpen && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 max-w-sm w-full text-center shadow-2xl border border-gray-100 dark:border-slate-800 transform transition-all scale-100">
                        <div className="w-14 h-14 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-red-50 dark:border-red-900/30">
                            <AlertTriangle size={28} className="text-red-600 dark:text-red-500" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{t('Delete Distribution Method?', '删除配送方式？')}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                            {t('Are you sure you want to remove this outlet? This action cannot be undone.', '您确定要删除此网点吗？此操作无法撤销。')}
                        </p>
                        <div className="flex gap-3">
                            <button 
                                onClick={() => setIsDeleteModalOpen(false)} 
                                className="flex-1 py-2.5 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 font-bold rounded-xl hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors text-sm"
                            >
                                {t('Cancel', '取消')}
                            </button>
                            <button 
                                onClick={executeDelete} 
                                className="flex-1 py-2.5 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-200 dark:shadow-none transition-all active:scale-95 text-sm"
                            >
                                {t('Delete', '删除')}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DistributionMethodManager;

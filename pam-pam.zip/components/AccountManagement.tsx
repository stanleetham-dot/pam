
import React, { useState, useMemo } from 'react';
import { useInventory } from '../context/InventoryContext';
import { UserProfile, RoleConfig } from '../types';
import { 
    Users, ShieldCheck, UserPlus, Search, Edit2, Trash2, 
    Settings, Shield, Plus, X, Save, Mail, UserCog,
    Truck, LayoutGrid, Store, Briefcase, BadgeCheck
} from 'lucide-react';
import UserFormModal from './UserFormModal';
import UserAccessConfig from './UserAccessConfig';
import RoleDetailConfig from './RoleDetailConfig';

const StatCard: React.FC<{ title: string; value: number; icon: React.ElementType; color: string; subColor: string }> = ({ title, value, icon: Icon, color, subColor }) => (
    <div className={`bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-800 flex items-center gap-4 transition-colors ${subColor}`}>
        <div className={`w-14 h-14 rounded-full flex items-center justify-center ${color} bg-opacity-10 dark:bg-opacity-20`}>
            <Icon size={28} className={color.replace('bg-', 'text-')} />
        </div>
        <div>
            <p className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">{title}</p>
            <h3 className="text-2xl font-black text-gray-900 dark:text-white">{value}</h3>
        </div>
    </div>
);

const CreateRoleModal: React.FC<{ isOpen: boolean; onClose: () => void; onCreate: (name: string, desc: string) => void }> = ({ isOpen, onClose, onCreate }) => {
    const [name, setName] = useState('');
    const [desc, setDesc] = useState('');

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-2xl shadow-xl p-6 border border-gray-100 dark:border-slate-800 animate-in zoom-in-95">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">Create Role</h3>
                    <button onClick={onClose}><X size={20} className="text-gray-400" /></button>
                </div>
                <div className="space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Role Name</label>
                        <input className="w-full px-4 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none text-gray-900 dark:text-white" value={name} onChange={e => setName(e.target.value.toUpperCase())} placeholder="e.g. SUPERVISOR" />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Description</label>
                        <input className="w-full px-4 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none text-gray-900 dark:text-white" value={desc} onChange={e => setDesc(e.target.value)} placeholder="Role purpose..." />
                    </div>
                    <button onClick={() => { onCreate(name, desc); onClose(); }} className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700">Create</button>
                </div>
            </div>
        </div>
    );
};

const AccountManagement: React.FC = () => {
    const { users, addUser, updateUser, deleteUser, roleConfigs, updateRoleConfig, addRole, outlets } = useInventory();
    
    const [activeTab, setActiveTab] = useState<'USERS' | 'ROLES'>('USERS');
    const [searchQuery, setSearchQuery] = useState('');
    const [roleFilter, setRoleFilter] = useState('ALL');
    
    // Modals
    const [isUserModalOpen, setIsUserModalOpen] = useState(false);
    const [isConfigOpen, setIsConfigOpen] = useState(false);
    const [isCreateRoleOpen, setIsCreateRoleOpen] = useState(false);
    
    const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
    const [editingRole, setEditingRole] = useState<string | null>(null);

    const roleList = Object.keys(roleConfigs);
    const activeUserCount = users.filter(u => u.status === 'Active').length;
    const pendingCount = users.filter(u => u.status === 'Pending').length;

    const filteredUsers = useMemo(() => {
        return users.filter(u => {
            const matchesSearch = u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                  u.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                  u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                  (u.phone && u.phone.includes(searchQuery));
            const matchesRole = roleFilter === 'ALL' || u.role === roleFilter;
            return matchesSearch && matchesRole;
        });
    }, [users, searchQuery, roleFilter]);

    const handleAddUser = () => {
        setSelectedUser(null);
        setIsUserModalOpen(true);
    };

    const handleEditUser = (user: UserProfile) => {
        setSelectedUser(user);
        setIsUserModalOpen(true);
    };

    const handleConfigUser = (user: UserProfile) => {
        setSelectedUser(user);
        setIsConfigOpen(true);
    };

    const handleSaveUser = (userData: Partial<UserProfile>, isNew: boolean) => {
        if (isNew) {
            addUser({
                ...userData,
                id: crypto.randomUUID(),
                status: 'Active',
                permissions: []
            } as UserProfile);
        } else if (selectedUser) {
            updateUser({
                ...selectedUser,
                ...userData
            });
        }
        setIsUserModalOpen(false);
        setIsConfigOpen(false);
    };

    const handleDeleteUser = (id: string) => {
        if(confirm('Are you sure you want to delete this user?')) {
            deleteUser(id);
        }
    };

    const handleUpdateRoleConfig = (config: RoleConfig) => {
        if (editingRole) {
            updateRoleConfig(editingRole, config);
            setEditingRole(null);
        }
    };

    const handleCreateRole = (name: string, desc: string) => {
        if (!name) return;
        addRole(name, desc);
    };

    const getRoleIcon = (roleName: string) => {
        if (roleName === 'ADMIN') return ShieldCheck;
        if (roleName === 'BRANCH') return Store;
        if (roleName === 'DRIVER') return Truck;
        if (roleName === 'INSPECTOR') return Search;
        if (roleName === 'TRADER') return LayoutGrid;
        if (roleName === 'MANAGER') return Users;
        return Shield;
    };

    const getRoleColor = (roleName: string) => {
        if (roleName === 'ADMIN') return 'text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-900/30';
        if (roleName === 'BRANCH') return 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30';
        if (roleName === 'DRIVER') return 'text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-900/30';
        if (roleName === 'MANAGER') return 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30';
        if (roleName === 'USER') return 'text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-slate-800';
        return 'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-900/30';
    };

    // Render logic for permissions overlay
    if (isConfigOpen && selectedUser) {
        return (
            <UserAccessConfig 
                user={selectedUser}
                roleConfigs={roleConfigs}
                onSave={handleSaveUser}
                onClose={() => setIsConfigOpen(false)}
                outlets={outlets}
            />
        );
    }

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 font-sans transition-colors duration-300 relative">
            {/* Role Config Overlay */}
            {editingRole && (
                <RoleDetailConfig 
                    role={editingRole}
                    config={roleConfigs[editingRole]}
                    onSave={handleUpdateRoleConfig}
                    onClose={() => setEditingRole(null)}
                />
            )}

            {/* Modals */}
            <UserFormModal 
                isOpen={isUserModalOpen} 
                onClose={() => setIsUserModalOpen(false)} 
                onSubmit={handleSaveUser} 
                user={selectedUser} 
            />

            <CreateRoleModal 
                isOpen={isCreateRoleOpen}
                onClose={() => setIsCreateRoleOpen(false)}
                onCreate={handleCreateRole}
            />

            {/* Header */}
            <div className="px-8 py-8 shrink-0 transition-colors duration-300">
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
                    <div>
                        <h1 className="text-3xl font-black text-gray-900 dark:text-white tracking-tight flex items-center gap-3">
                            <UserCog size={32} className="text-blue-600 dark:text-blue-500" />
                            Team & Access
                        </h1>
                        <p className="text-gray-500 dark:text-gray-400 mt-2 font-medium">Manage user accounts, roles, and granular permission overrides.</p>
                    </div>
                    <div className="flex gap-3">
                        <div className="bg-gray-200 dark:bg-slate-800 p-1 rounded-xl flex">
                            <button 
                                onClick={() => setActiveTab('USERS')}
                                className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'USERS' ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                            >
                                <Users size={16} /> Users
                            </button>
                            <button 
                                onClick={() => setActiveTab('ROLES')}
                                className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'ROLES' ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                            >
                                <ShieldCheck size={16} /> Roles
                            </button>
                        </div>
                        {activeTab === 'USERS' ? (
                            <button 
                                onClick={handleAddUser}
                                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-200 dark:shadow-blue-900/20 transition-all flex items-center gap-2 transform hover:-translate-y-0.5 active:translate-y-0"
                            >
                                <UserPlus size={20} /> Invite Member
                            </button>
                        ) : (
                            <button 
                                onClick={() => setIsCreateRoleOpen(true)}
                                className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-lg shadow-purple-200 dark:shadow-purple-900/20 transition-all flex items-center gap-2 transform hover:-translate-y-0.5 active:translate-y-0"
                            >
                                <Plus size={20} /> Create Role
                            </button>
                        )}
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <StatCard title="Total Active Users" value={activeUserCount} icon={Users} color="bg-blue-600" subColor="shadow-blue-200 dark:shadow-blue-900/30" />
                    <StatCard title="Defined Roles" value={roleList.length} icon={Shield} color="bg-purple-600" subColor="shadow-purple-200 dark:shadow-purple-900/30" />
                    <StatCard title="Pending Invites" value={pendingCount} icon={Mail} color="bg-orange-500" subColor="shadow-orange-200 dark:shadow-orange-900/30" />
                </div>
            </div>

            <div className="flex-1 overflow-y-auto px-8 pb-8">
                <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full">
                    
                    {activeTab === 'USERS' ? (
                        <>
                            {/* Users Toolbar */}
                            <div className="p-5 border-b border-gray-100 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 bg-white dark:bg-slate-900">
                                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full md:w-auto pb-1 md:pb-0">
                                    {['ALL', ...roleList].map(role => (
                                        <button
                                            key={role}
                                            onClick={() => setRoleFilter(role)}
                                            className={`px-4 py-2 rounded-full text-xs font-bold transition-all whitespace-nowrap border ${
                                                roleFilter === role 
                                                ? 'bg-gray-900 dark:bg-white text-white dark:text-slate-900 border-gray-900 dark:border-white shadow-md' 
                                                : 'bg-white dark:bg-slate-900 text-gray-500 dark:text-gray-400 border-gray-200 dark:border-slate-800 hover:border-gray-300 dark:hover:border-slate-600'
                                            }`}
                                        >
                                            {role === 'ALL' ? 'All Users' : role}
                                        </button>
                                    ))}
                                </div>

                                <div className="relative w-full md:w-72">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                                    <input 
                                        className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-gray-400"
                                        placeholder="Search by name, email, phone..."
                                        value={searchQuery}
                                        onChange={e => setSearchQuery(e.target.value)}
                                    />
                                </div>
                            </div>

                            {/* Users Table */}
                            <div className="flex-1 overflow-auto">
                                <table className="w-full text-left border-collapse">
                                    <thead className="bg-gray-50 dark:bg-slate-950 sticky top-0 z-10 border-b border-gray-100 dark:border-slate-800">
                                        <tr>
                                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">User Profile</th>
                                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Role & Access</th>
                                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Contact</th>
                                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100 dark:divide-slate-800 bg-white dark:bg-slate-900">
                                        {filteredUsers.map(user => {
                                            const RoleIcon = getRoleIcon(user.role);
                                            const roleColor = getRoleColor(user.role);
                                            
                                            return (
                                            <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-slate-800/50 transition-colors group">
                                                <td className="px-6 py-4">
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-slate-800 overflow-hidden border border-gray-200 dark:border-slate-700">
                                                            {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-xs font-bold text-gray-400">{user.name.charAt(0)}</div>}
                                                        </div>
                                                        <div>
                                                            <div className="font-bold text-sm text-gray-900 dark:text-white">{user.name}</div>
                                                            <div className="text-xs text-gray-500 dark:text-gray-400">@{user.username}</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className="flex flex-col gap-1.5">
                                                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold w-fit ${roleColor}`}>
                                                            <RoleIcon size={12} /> {user.role}
                                                        </span>
                                                        {user.customConfig && (
                                                            <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold flex items-center gap-1">
                                                                <Settings size={10} /> Custom Permissions
                                                            </span>
                                                        )}
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className="flex flex-col text-sm text-gray-600 dark:text-gray-400">
                                                        <span>{user.email}</span>
                                                        <span className="text-xs text-gray-400 dark:text-gray-500">{user.phone}</span>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                                                        user.status === 'Active' 
                                                        ? 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400' 
                                                        : 'bg-gray-100 text-gray-600 dark:bg-slate-800 dark:text-gray-400'
                                                    }`}>
                                                        {user.status || 'Active'}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4 text-right">
                                                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <button 
                                                            onClick={() => handleConfigUser(user)}
                                                            className="p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                                                            title="Configure Access"
                                                        >
                                                            <Shield size={16} />
                                                        </button>
                                                        <button 
                                                            onClick={() => handleEditUser(user)}
                                                            className="p-2 text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                                                            title="Edit Profile"
                                                        >
                                                            <Edit2 size={16} />
                                                        </button>
                                                        <button 
                                                            onClick={() => handleDeleteUser(user.id)}
                                                            className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                                            title="Delete User"
                                                        >
                                                            <Trash2 size={16} />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        )})}
                                        {filteredUsers.length === 0 && (
                                            <tr>
                                                <td colSpan={5} className="py-20 text-center text-gray-400 dark:text-gray-500">
                                                    No users found.
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </>
                    ) : (
                        <div className="flex-1 overflow-auto p-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {roleList.map(role => {
                                    const roleData = roleConfigs[role];
                                    const userCount = users.filter(u => u.role === role).length;
                                    const RoleIcon = getRoleIcon(role);
                                    const roleColor = getRoleColor(role);
                                    
                                    return (
                                        <div key={role} className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all group">
                                            <div className="flex justify-between items-start mb-4">
                                                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${roleColor}`}>
                                                    <RoleIcon size={24} />
                                                </div>
                                                <button 
                                                    onClick={() => setEditingRole(role)}
                                                    className="p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 bg-gray-50 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                                                >
                                                    <Settings size={18} />
                                                </button>
                                            </div>
                                            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">{role}</h3>
                                            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6 h-10 line-clamp-2">
                                                {roleData.metadata?.description || 'Standard role configuration.'}
                                            </p>
                                            
                                            <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-slate-800">
                                                <div className="flex -space-x-2">
                                                    {users.filter(u => u.role === role).slice(0, 3).map(u => (
                                                        <div key={u.id} className="w-8 h-8 rounded-full border-2 border-white dark:border-slate-900 bg-gray-200 dark:bg-slate-700 flex items-center justify-center text-xs font-bold text-gray-600 dark:text-gray-300" title={u.name}>
                                                            {u.avatar ? <img src={u.avatar} className="w-full h-full rounded-full object-cover"/> : u.name.charAt(0)}
                                                        </div>
                                                    ))}
                                                    {userCount > 3 && (
                                                        <div className="w-8 h-8 rounded-full border-2 border-white dark:border-slate-900 bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-[10px] font-bold text-gray-500 dark:text-gray-400">
                                                            +{userCount - 3}
                                                        </div>
                                                    )}
                                                </div>
                                                <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">{userCount} Users</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AccountManagement;


import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Truck, 
  Settings, 
  LogOut,
  Boxes,
  Menu,
  ChevronLeft,
  Users,
  ChevronDown,
  Tag,
  ShieldCheck,
  Search,
  User,
  ClipboardList,
  Scan,
  CheckSquare,
  Warehouse,
  BrainCircuit,
  Circle,
  Layers,
  Store,
  RefreshCw
} from 'lucide-react';
import { ViewState } from '../types';
import { useInventory } from '../context/InventoryContext';

interface SidebarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
}

interface MenuItem {
  id: string;
  label: string;
  icon?: React.ElementType;
  subItems?: { id: ViewState; label: string }[];
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView }) => {
  const [collapsed, setCollapsed] = useState(false);
  const { currentUser, logout, checkPermission, theme, language, refreshData } = useInventory();
  
  const [expandedGroups, setExpandedGroups] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('nexus_sidebar_expanded');
      return saved ? JSON.parse(saved) : ['PRODUCT_MGMT_GROUP', 'INVENTORY_GROUP', 'WAREHOUSE_MGMT_GROUP', 'ORDER_MGMT_GROUP', 'PURCHASING_GROUP'];
    } catch (e) {
      return ['PRODUCT_MGMT_GROUP', 'INVENTORY_GROUP'];
    }
  });

  useEffect(() => {
    localStorage.setItem('nexus_sidebar_expanded', JSON.stringify(expandedGroups));
  }, [expandedGroups]);

  // Group Mapping for auto-expand
  useEffect(() => {
    if (collapsed) return;
    const groupMap: Record<string, string[]> = {
        'ORDER_MGMT_GROUP': [
            ViewState.OM_TASK_MANAGEMENT, ViewState.OM_DISTRIBUTION_ORDER,
            ViewState.INVENTORY_DISCREPANCY, ViewState.DISTRIBUTION_METHOD
        ],
        'WAREHOUSE_MGMT_GROUP': [ViewState.WAREHOUSE_CONFIG, ViewState.SHELF_ARRANGEMENT],
        'DELIVERY_MGMT_GROUP': [
            ViewState.DM_DISTRIBUTION_CENTER, 
            ViewState.DM_TRANSFER_OUT_ORDER, 
            ViewState.DM_DELIVERY_TRACKING,
            ViewState.DM_PRODUCTS_IN_TRANSIT
        ],
        'INVENTORY_GROUP': [
            ViewState.INVENTORY_QUERY, ViewState.INVENTORY_ADJUSTMENT, 
            ViewState.INVENTORY_TRANSFER
        ],
        'PRODUCT_MGMT_GROUP': [ViewState.INVENTORY_PRODUCT, ViewState.INVENTORY_EXPIRE],
        'PURCHASING_GROUP': [ViewState.PURCHASING, ViewState.RECEIVING_ORDERS, ViewState.INBOUND],
        'SCAN_OPS_GROUP': [ViewState.SCAN_TO_SHELF, ViewState.SKU_LOOKUP, ViewState.SHELF_LOGS]
    };

    const newExpanded = new Set(expandedGroups);
    let changed = false;
    for (const [groupId, items] of Object.entries(groupMap)) {
        if (items.includes(currentView) && !newExpanded.has(groupId)) {
            newExpanded.add(groupId);
            changed = true;
        }
    }
    if (changed) setExpandedGroups(Array.from(newExpanded));
  }, [currentView, collapsed]);

  const toggleGroup = (groupId: string) => {
    if (collapsed) {
      setCollapsed(false);
      setExpandedGroups(prev => [...prev, groupId]);
      return;
    }
    setExpandedGroups(prev => prev.includes(groupId) ? prev.filter(id => id !== groupId) : [...prev, groupId]);
  };

  const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

  const allMenuItems: MenuItem[] = [
    { id: 'DASHBOARD', label: t('Dashboard', '仪表盘'), icon: LayoutDashboard },
    { id: 'AI_ASSISTANT', label: t('AI Assistant', 'AI 助手'), icon: BrainCircuit },
    { id: 'TASK_MANAGER', label: t('My Tasks', '我的任务'), icon: CheckSquare },
    { 
      id: 'ORDER_MGMT_GROUP', label: t('Order Management', '订单管理'), icon: ClipboardList,
      subItems: [
        { id: ViewState.OM_TASK_MANAGEMENT, label: t('Task Management', '任务管理') },
        { id: ViewState.OM_DISTRIBUTION_ORDER, label: t('Distribution Order', '配送订单') },
        { id: ViewState.INVENTORY_DISCREPANCY, label: t('Discrepancy Check', '差异检查') },
        { id: ViewState.DISTRIBUTION_METHOD, label: t('Distribution Method', '配送方式') },
      ]
    },
    { 
      id: 'WAREHOUSE_MGMT_GROUP', label: t('Warehouse Mgmt', '仓库管理'), icon: Warehouse,
      subItems: [
        { id: ViewState.WAREHOUSE_CONFIG, label: t('Configuration', '仓库配置') },
        { id: ViewState.SHELF_ARRANGEMENT, label: t('Shelf Arrangement', '货架整理') },
      ]
    },
    { 
      id: 'DELIVERY_MGMT_GROUP', label: t('Delivery Mgmt', '运输管理'), icon: Truck,
      subItems: [
        { id: ViewState.DM_DISTRIBUTION_CENTER, label: t('Distribution Center', '配送中心') },
        { id: ViewState.DM_TRANSFER_OUT_ORDER, label: t('Transfer Out', '调拨出库') },
        { id: ViewState.DM_DELIVERY_TRACKING, label: t('Delivery Tracking', '物流追踪') },
        { id: ViewState.DM_PRODUCTS_IN_TRANSIT, label: t('Products in Transit', '在途商品') },
      ]
    },
    { 
      id: 'PURCHASING_GROUP', label: t('Purchasing', '采购管理'), icon: ShoppingCart,
      subItems: [
        { id: ViewState.PURCHASING, label: t('Purchase Orders', '采购订单') },
        { id: ViewState.RECEIVING_ORDERS, label: t('Receiving Orders', '收货单') },
        { id: ViewState.INBOUND, label: t('Inbound Ops', '入库操作') },
      ]
    },
    { 
      id: 'PRODUCT_MGMT_GROUP', label: t('Product Mgmt', '商品管理'), icon: Tag,
      subItems: [
        { id: ViewState.INVENTORY_PRODUCT, label: t('Product File', '商品档案') },
        { id: ViewState.INVENTORY_EXPIRE, label: t('Expire Logs', '效期记录') },
      ]
    },
    { 
      id: 'INVENTORY_GROUP', label: t('Inventory', '库存管理'), icon: Boxes,
      subItems: [
        { id: ViewState.INVENTORY_QUERY, label: t('Inventory Query', '库存查询') },
        { id: ViewState.INVENTORY_ADJUSTMENT, label: t('Adjustment', '库存调整') },
        { id: ViewState.INVENTORY_TRANSFER, label: t('Stock Transfer', '移库操作') },
      ]
    },
    { 
      id: 'SCAN_OPS_GROUP', label: t('Scan Ops', '扫描作业'), icon: Scan,
      subItems: [
        { id: ViewState.SCAN_TO_SHELF, label: t('Scan to Shelf', '上架扫描') },
        { id: ViewState.SKU_LOOKUP, label: t('SKU Lookup', 'SKU查询') },
        { id: ViewState.SHELF_LOGS, label: t('Shelf Logs', '货架日志') },
      ]
    }, 
    { id: 'ACCOUNT_MANAGEMENT', label: t('Account Mgmt', '账户管理'), icon: Users },
    { id: 'SETTINGS', label: t('Settings', '系统设置'), icon: Settings }, 
  ];

  const getRoleBadge = (role: string) => {
      switch(role) {
          case 'ADMIN': return { bg: 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-900/30', icon: ShieldCheck };
          case 'MANAGER': return { bg: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-900/30', icon: Users };
          case 'INSPECTOR': return { bg: 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/20 dark:text-orange-400 dark:border-orange-900/30', icon: Search };
          case 'BRANCH': return { bg: 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-900/20 dark:text-indigo-400 dark:border-indigo-900/30', icon: Store };
          case 'USER': return { bg: 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-slate-800 dark:text-gray-400 dark:border-slate-700', icon: User };
          case 'DRIVER': return { bg: 'bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-900/20 dark:text-teal-400 dark:border-teal-900/30', icon: Truck };
          default: return { bg: 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900/20 dark:text-gray-400 dark:border-gray-900/30', icon: Circle };
      }
  };

  const hasAccess = (itemId: string) => {
      const groupItem = allMenuItems.find(i => i.id === itemId);
      if (groupItem && groupItem.subItems) {
          return groupItem.subItems.some(sub => checkPermission(sub.id, 'read'));
      }
      return checkPermission(itemId, 'read');
  };

  if (!currentUser) return null;

  const currentRoleStyle = getRoleBadge(currentUser.role);
  const RoleIcon = currentRoleStyle.icon;

  return (
    <div 
      className={`bg-white dark:bg-slate-900 border-r border-gray-200 dark:border-slate-800 h-screen flex flex-col transition-[width,background-color] duration-300 ease-in-out z-20 print:hidden ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      <div className="h-16 flex items-center justify-between px-4 border-b border-gray-100 dark:border-slate-800 flex-shrink-0">
        {!collapsed && (
          <div className="flex items-center gap-2 animate-in fade-in duration-300">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold shadow-blue-200 shadow-md">
              P
            </div>
            <span className="font-bold text-xl text-gray-800 dark:text-white tracking-tight">Pam Pam</span>
          </div>
        )}
        <button 
          onClick={() => setCollapsed(!collapsed)}
          className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-500 dark:text-gray-400 transition-colors"
        >
          {collapsed ? <Menu size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>

      {!collapsed ? (
        <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex-shrink-0 animate-in fade-in">
          <div className="flex items-center gap-3">
            <img src={currentUser.avatar} alt="Profile" className="w-10 h-10 rounded-full border border-gray-200 dark:border-slate-700 shadow-sm object-cover" />
            <div className="flex flex-col overflow-hidden">
              <span className="font-semibold text-gray-800 dark:text-white text-sm truncate">{currentUser.name}</span>
              <div className={`flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded border w-fit mt-0.5 ${currentRoleStyle.bg}`}>
                <RoleIcon size={10} />
                {currentUser.role}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex justify-center flex-shrink-0">
             <img src={currentUser.avatar} alt="Profile" className="w-8 h-8 rounded-full border border-gray-200 dark:border-slate-700 object-cover" />
        </div>
      )}

      <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto no-scrollbar">
        {allMenuItems.map((item) => {
          if (!hasAccess(item.id)) return null;

          const Icon = item.icon || Circle;
          const isGroup = !!item.subItems;
          const isExpanded = expandedGroups.includes(item.id);
          
          const isChildActive = item.subItems?.some(sub => sub.id === currentView);
          const isActive = currentView === item.id || isChildActive;

          return (
            <div key={item.id} className="mb-1">
              <button
                onClick={() => isGroup ? toggleGroup(item.id) : onChangeView(item.id as ViewState)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all duration-200 group relative ${
                  isActive && !isGroup
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-medium shadow-sm' 
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-800 hover:text-gray-900 dark:hover:text-white'
                } ${isChildActive && collapsed ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' : ''}`}
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <Icon size={20} className={`${(isActive || isChildActive) ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500 dark:text-gray-500 group-hover:text-gray-700 dark:group-hover:text-gray-300'}`} />
                  {!collapsed && <span className="whitespace-nowrap text-sm font-medium">{item.label}</span>}
                </div>
                
                {!collapsed && isGroup && (
                  <div className={`text-gray-400 dark:text-gray-500 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}>
                    <ChevronDown size={14} />
                  </div>
                )}

                {collapsed && (
                  <div className="absolute left-full ml-2 px-2 py-1 bg-gray-800 dark:bg-white text-white dark:text-black text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 shadow-lg transition-opacity">
                    {item.label}
                  </div>
                )}
              </button>

              <div 
                  className={`overflow-hidden transition-all duration-300 ease-in-out ${
                      !collapsed && isGroup && isExpanded ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
                  }`}
              >
                  <div className="mt-1 ml-3 space-y-0.5 pl-3 border-l-2 border-gray-100 dark:border-slate-800">
                    {item.subItems?.map(subItem => {
                        if (!checkPermission(subItem.id, 'read')) return null;

                        const isSubActive = currentView === subItem.id;
                        return (
                        <button
                            key={subItem.id}
                            onClick={() => onChangeView(subItem.id)}
                            className={`w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-colors ${
                            isSubActive
                                ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-medium'
                                : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-slate-800'
                            }`}
                        >
                            <span className={`w-1.5 h-1.5 rounded-full transition-colors ${isSubActive ? 'bg-blue-600 dark:bg-blue-400' : 'bg-gray-300 dark:bg-slate-700'}`}></span>
                            <span className="truncate">{subItem.label}</span>
                        </button>
                        );
                    })}
                  </div>
              </div>
            </div>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-100 dark:border-slate-800 flex-shrink-0 flex flex-col gap-2">
        <button 
          onClick={refreshData}
          className="flex items-center gap-3 text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/10 transition-colors w-full px-3 py-2 rounded-lg group"
          title={t('Refresh Data', '刷新数据')}
        >
          <RefreshCw size={20} className="group-hover:rotate-180 transition-transform duration-500" />
          {!collapsed && <span className="text-sm font-medium">{t('Refresh App', '刷新应用')}</span>}
        </button>
        <button 
          onClick={logout}
          className="flex items-center gap-3 text-gray-500 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors w-full px-3 py-2 rounded-lg group"
        >
          <LogOut size={20} className="group-hover:-translate-x-1 transition-transform" />
          {!collapsed && <span className="text-sm font-medium">Logout</span>}
        </button>
      </div>
    </div>
  );
};

export default Sidebar;


import React, { useState } from 'react';
import { X, History, Search, Copy, Check } from 'lucide-react';
import { Product, Transaction } from '../types';

interface TransactionHistoryModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
}

const TransactionHistoryModal: React.FC<TransactionHistoryModalProps> = ({ product, isOpen, onClose, transactions }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen || !product) return null;

  const productTransactions = transactions.filter(t => t.productId === product.id && (
      (t.fromLocation || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
      (t.toLocation || '').toLowerCase().includes(searchTerm.toLowerCase())
  )).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const handleCopy = (t: Transaction) => {
      const details = `Transaction: ${t.type}\nProduct: ${t.productName}\nQty: ${t.quantity}\nUser: ${t.user}\nTime: ${new Date(t.timestamp).toLocaleString()}`;
      navigator.clipboard.writeText(details);
      setCopiedId(t.id);
      setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-4xl shadow-xl flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 border border-gray-200 dark:border-slate-800 transition-colors">
        <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center">
             <div className="flex items-center gap-2">
                <History className="text-blue-600 dark:text-blue-400" size={20}/>
                <h2 className="text-xl font-bold text-gray-800 dark:text-white">Transaction History</h2>
             </div>
             <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full text-gray-400 transition-colors">
                <X size={24} />
             </button>
        </div>
        <div className="p-4 bg-gray-50 dark:bg-slate-950 border-b border-gray-100 dark:border-slate-800 flex gap-4">
             <div className="relative flex-1">
                 <Search className="absolute left-3 top-2.5 text-gray-400" size={16}/>
                 <input 
                    className="w-full pl-9 pr-4 py-2 border border-gray-300 dark:border-slate-700 rounded-lg text-sm text-gray-900 dark:text-white bg-white dark:bg-slate-800 focus:ring-2 focus:ring-blue-500 outline-none transition-all" 
                    placeholder="Search location..." 
                    value={searchTerm} 
                    onChange={e => setSearchTerm(e.target.value)} 
                 />
             </div>
        </div>
        <div className="flex-1 overflow-y-auto">
            <table className="w-full text-left text-sm">
                <thead className="bg-gray-50 dark:bg-slate-950 text-gray-500 dark:text-gray-400 font-medium sticky top-0 shadow-sm transition-colors">
                    <tr>
                        <th className="px-6 py-4">Time</th>
                        <th className="px-6 py-4">Type</th>
                        <th className="px-6 py-4">Location</th>
                        <th className="px-6 py-4 text-right">Qty</th>
                        <th className="px-6 py-4">User</th>
                        <th className="px-6 py-4"></th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                    {productTransactions.map(t => (
                        <tr key={t.id} className="hover:bg-gray-50 dark:hover:bg-slate-800/50 transition-colors">
                            <td className="px-6 py-4">
                                <div className="text-gray-900 dark:text-gray-100">{new Date(t.timestamp).toLocaleDateString('en-GB')}</div>
                                <div className="text-xs text-gray-400 dark:text-gray-500">{new Date(t.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                            </td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                                    t.type === 'INBOUND' ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400' : 
                                    t.type === 'OUTBOUND' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 
                                    'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                                }`}>{t.type}</span>
                            </td>
                            <td className="px-6 py-4 text-gray-600 dark:text-gray-400 font-mono text-xs">{t.toLocation || t.fromLocation}</td>
                            <td className={`px-6 py-4 text-right font-bold ${t.type === 'OUTBOUND' ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                                {t.type === 'OUTBOUND' ? '-' : '+'}{t.quantity}
                            </td>
                            <td className="px-6 py-4 text-gray-700 dark:text-gray-300">{t.user}</td>
                            <td className="px-6 py-4 text-right">
                                <button onClick={() => handleCopy(t)} className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-lg text-gray-400 dark:text-gray-500 hover:text-blue-600 dark:hover:text-blue-400 transition-colors" title="Copy Details">
                                    {copiedId === t.id ? <Check size={16} className="text-green-600 dark:text-green-400" /> : <Copy size={16} />}
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            {productTransactions.length === 0 && (
                <div className="p-12 text-center text-gray-400 dark:text-gray-600">
                    <History size={48} className="mx-auto mb-3 opacity-20" />
                    <p>No transaction history found.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default TransactionHistoryModal;

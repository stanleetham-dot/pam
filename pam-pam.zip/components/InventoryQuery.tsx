
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useInventory } from '../context/InventoryContext';
import { InventoryItem, Product } from '../types';
import { 
    UploadCloud, X, FileSpreadsheet, Download, Upload, CheckCircle2, 
    AlertCircle, Loader2, Search, Filter, ChevronLeft, ChevronRight,
    ChevronsLeft, ChevronsRight, Box, ChevronDown, Package, LayoutList
} from 'lucide-react';
import * as XLSX from 'xlsx';

// Stock Import Modal Component
const StockImportModal: React.FC<{ isOpen: boolean; onClose: () => void; onImport: (items: InventoryItem[], mode: 'MERGE' | 'REPLACE') => Promise<void>; products: Product[] }> = ({ isOpen, onClose, onImport, products }) => {
    const [file, setFile] = useState<File | null>(null);
    const [previewCount, setPreviewCount] = useState<number>(0);
    const [isProcessing, setIsProcessing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [importMode, setImportMode] = useState<'MERGE' | 'REPLACE'>('MERGE');
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (!isOpen) {
            setFile(null);
            setPreviewCount(0);
            setError(null);
            setImportMode('MERGE');
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const handleDownloadTemplate = () => {
        const headers = [
            'Branch No.', 'Product code', 'Product barcode', 'Product name', 'Inventory quantity', 
            'Warehouse', 'Storage location', 'Specification', 'Basic unit', 'Latest receiving date', 
            'Product category', 'Last modified time', 'Receipt interval', 'Standard price', 'Wholesale price'
        ];
        const sampleData = [
            ['B001', 'SKU-001', '880123456789', 'Wireless Mouse', 150, 'Main Warehouse', 'A1-01B', 'Black', 'PCS', '2023-10-27', 'Electronics', '2023-10-27 10:00:00', '30', 15.99, 10.50]
        ];
        const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleData]);
        ws['!cols'] = headers.map(() => ({ wch: 20 }));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Stock Template");
        XLSX.writeFile(wb, "Inventory_Batch_Import_Template.xlsx");
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (fileInputRef.current) fileInputRef.current.value = '';
        
        if (!selectedFile) return;
        setFile(selectedFile);
        setIsProcessing(true);
        setError(null);

        const reader = new FileReader();
        reader.onload = (evt) => {
            try {
                const data = evt.target?.result;
                const wb = XLSX.read(data, { type: 'array' });
                const wsname = wb.SheetNames[0];
                const ws = wb.Sheets[wsname];
                const jsonData = XLSX.utils.sheet_to_json(ws, { header: 1 });
                if (jsonData.length <= 1) {
                    setError("The file appears to be empty or missing headers.");
                    setPreviewCount(0);
                } else {
                    setPreviewCount(jsonData.length - 1);
                }
            } catch (err) {
                console.error(err);
                setError("Failed to parse file. Ensure it is a valid XLSX.");
            } finally {
                setIsProcessing(false);
            }
        };
        reader.readAsArrayBuffer(selectedFile);
    };

    const processImport = async () => {
        if (!file) return;
        
        setIsProcessing(true);

        const readFile = (f: File): Promise<any[]> => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (evt) => {
                    try {
                        const data = evt.target?.result;
                        const wb = XLSX.read(data, { type: 'array' });
                        const ws = wb.Sheets[wb.SheetNames[0]];
                        const jsonData = XLSX.utils.sheet_to_json<any>(ws);
                        resolve(jsonData);
                    } catch (e) {
                        reject(e);
                    }
                };
                reader.onerror = (e) => reject(new Error("File read error"));
                reader.readAsArrayBuffer(f);
            });
        };

        try {
            const rawData = await readFile(file);
            
            // Normalize keys
            const data = rawData.map((row: any) => {
                const newRow: any = {};
                Object.keys(row).forEach(key => {
                    const cleanKey = key.trim().toLowerCase().replace(/\s+/g, ' ');
                    newRow[cleanKey] = row[key];
                });
                return newRow;
            });

            const inventoryItems: InventoryItem[] = [];
            const batchProductMap = new Map<string, string>();

            data.forEach((row: any) => {
                const getVal = (possibleKeys: string[]) => {
                    for (const k of possibleKeys) {
                        const cleanK = k.toLowerCase();
                        if (row[cleanK] !== undefined) return row[cleanK];
                    }
                    return undefined;
                };

                const barcode = String(getVal(['Product barcode', 'ProductBarcode', 'product_barcode', 'barcode']) || '').trim();
                const sku = String(getVal(['Product code', 'ProductCode', 'product_code', 'sku']) || '').trim();
                
                if (!barcode && !sku) return;

                const qty = parseInt(getVal(['Inventory quantity', 'Quantity', 'qty', 'stock']) || 0);
                const location = String(getVal(['Storage location', 'Location', 'bin', 'loc']) || 'Received').trim();
                const warehouse = String(getVal(['Warehouse', 'Branch No.', 'whse']) || 'Main').trim();
                const category = String(getVal(['Product category', 'Category', 'cat']) || 'General').trim();
                const updatedAt = getVal(['Last modified time', 'UpdatedAt', 'updated']) ? String(getVal(['Last modified time', 'UpdatedAt', 'updated'])) : new Date().toISOString();
                const name = String(getVal(['Product name', 'Name', 'Title']) || `Item ${sku || barcode}`).trim();
                
                let productId: string;
                const existingProduct = products.find(p => (barcode && p.barcode === barcode) || (sku && p.sku === sku));
                
                if (existingProduct) {
                    productId = existingProduct.id;
                } else {
                    const key = sku || barcode;
                    if (batchProductMap.has(key)) {
                        productId = batchProductMap.get(key)!;
                    } else {
                        productId = crypto.randomUUID();
                        batchProductMap.set(key, productId);
                    }
                }

                inventoryItems.push({
                    id: crypto.randomUUID(), 
                    productId: productId,
                    productCode: sku || barcode,
                    productName: name,
                    location: location,
                    quantity: qty,
                    warehouse: warehouse,
                    category: category,
                    updatedAt: updatedAt
                });
            });

            if (inventoryItems.length === 0) {
                setError("No valid data found to import. Please check file headers match the template.");
                setIsProcessing(false);
                return;
            }

            await onImport(inventoryItems, importMode);
            
            alert(`Import Successful! (${importMode} Mode)\n- Inventory Records Processed: ${inventoryItems.length}`);
            onClose();

        } catch (err: any) {
            console.error(err);
            setError(`Error processing data: ${err.message || 'Unknown error'}`);
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl shadow-2xl flex flex-col overflow-hidden transition-colors">
                <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-900/50">
                    <div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                            <UploadCloud className="text-blue-600 dark:text-blue-500" /> Batch Import Inventory
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Add new inventory records from Excel file.</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full text-gray-500 dark:text-gray-400 transition-colors">
                        <X size={20} />
                    </button>
                </div>

                <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex flex-col">
                        <div className="flex items-center gap-2 mb-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-sm">1</div>
                            <h4 className="font-bold text-gray-900 dark:text-white">Download Template</h4>
                        </div>
                        <div className="flex-1 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-xl p-6 flex flex-col items-center justify-center text-center">
                            <FileSpreadsheet size={48} className="text-blue-200 dark:text-blue-900 mb-4" />
                            <p className="text-sm text-blue-900 dark:text-blue-100 font-medium mb-2">Get the formatted Excel file</p>
                            <button onClick={handleDownloadTemplate} className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-bold text-sm rounded-lg shadow-sm border border-blue-200 dark:border-slate-700 hover:bg-blue-50 dark:hover:bg-slate-700 transition-colors">
                                <Download size={16} /> Download .XLSX
                            </button>
                        </div>
                    </div>
                    <div className="flex flex-col">
                        <div className="flex items-center gap-2 mb-4">
                            <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 flex items-center justify-center font-bold text-sm">2</div>
                            <h4 className="font-bold text-gray-900 dark:text-white">Upload Data File</h4>
                        </div>
                        <div onClick={() => fileInputRef.current?.click()} className={`flex-1 border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${file ? 'border-green-500 bg-green-50 dark:bg-green-900/10' : 'border-gray-300 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-700 hover:bg-gray-50 dark:hover:bg-slate-800/50'}`}>
                            {file ? (
                                <>
                                    <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 mb-3"><CheckCircle2 size={24} /></div>
                                    <p className="font-bold text-gray-800 dark:text-gray-200 text-sm truncate max-w-full px-2">{file.name}</p>
                                    <p className="text-xs text-green-700 dark:text-green-400 mt-1 font-medium">{previewCount} rows found</p>
                                </>
                            ) : (
                                <>
                                    <Upload size={32} className="text-gray-300 dark:text-gray-600 mb-3" />
                                    <p className="font-medium text-gray-600 dark:text-gray-400 text-sm">Click to upload</p>
                                </>
                            )}
                            <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls" onChange={handleFileChange} />
                        </div>
                    </div>
                </div>

                <div className="px-8 pb-4">
                    <h4 className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-3">Import Mode</h4>
                    <div className="grid grid-cols-2 gap-4">
                        <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${importMode === 'MERGE' ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-500 dark:border-blue-400' : 'bg-gray-50 dark:bg-slate-800 border-gray-200 dark:border-slate-700'}`}>
                            <input type="radio" name="importMode" value="MERGE" checked={importMode === 'MERGE'} onChange={() => setImportMode('MERGE')} className="w-4 h-4 text-blue-600 focus:ring-blue-500" />
                            <div>
                                <span className="block text-sm font-bold text-gray-900 dark:text-white">Add to Existing</span>
                                <span className="block text-xs text-gray-500 dark:text-gray-400">Sum quantities (Old + New)</span>
                            </div>
                        </label>
                        <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${importMode === 'REPLACE' ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-500 dark:border-amber-400' : 'bg-gray-50 dark:bg-slate-800 border-gray-200 dark:border-slate-700'}`}>
                            <input type="radio" name="importMode" value="REPLACE" checked={importMode === 'REPLACE'} onChange={() => setImportMode('REPLACE')} className="w-4 h-4 text-amber-600 focus:ring-amber-500" />
                            <div>
                                <span className="block text-sm font-bold text-gray-900 dark:text-white">Update / Overwrite</span>
                                <span className="block text-xs text-gray-500 dark:text-gray-400">Replace current quantities</span>
                            </div>
                        </label>
                    </div>
                </div>

                {error && (
                    <div className="px-8 pb-4">
                        <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-lg flex items-center gap-2 text-sm text-red-700 dark:text-red-400">
                            <AlertCircle size={16} /> {error}
                        </div>
                    </div>
                )}
                <div className="p-6 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-900 flex justify-end gap-3 transition-colors">
                    <button onClick={onClose} className="px-5 py-2.5 text-gray-700 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-xl font-bold transition-colors text-sm">Cancel</button>
                    <button onClick={processImport} disabled={!file || isProcessing} className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-none flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 text-sm">
                        {isProcessing ? <Loader2 size={18} className="animate-spin" /> : <Upload size={18} />} Start Import
                    </button>
                </div>
            </div>
        </div>
    );
};

const InventoryQuery: React.FC = () => {
    const { inventory, products, bulkImportInventory, language } = useInventory();
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    const [isImportOpen, setIsImportOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [warehouseFilter, setWarehouseFilter] = useState('ALL');
    
    // Pagination State
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(50);
    const tableContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        setCurrentPage(1);
        if(tableContainerRef.current) tableContainerRef.current.scrollTop = 0;
    }, [searchTerm, warehouseFilter]);

    // Filter Logic
    const filteredInventory = useMemo(() => {
        return inventory.filter(item => {
            const matchesSearch = 
                item.productName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                item.productCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                (item.location && item.location.toLowerCase().includes(searchTerm.toLowerCase()));
            
            const matchesWarehouse = warehouseFilter === 'ALL' || item.warehouse === warehouseFilter;
            
            return matchesSearch && matchesWarehouse;
        });
    }, [inventory, searchTerm, warehouseFilter]);

    const totalItems = filteredInventory.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = useMemo(() => {
        return filteredInventory.slice(indexOfFirstItem, indexOfLastItem);
    }, [filteredInventory, indexOfFirstItem, indexOfLastItem]);

    const handlePageChange = (page: number) => {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
            if(tableContainerRef.current) tableContainerRef.current.scrollTop = 0;
        }
    };

    const warehouseOptions = Array.from(new Set(inventory.map(i => i.warehouse))).sort();

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 transition-colors duration-300">
            {/* Header */}
            <div className="shrink-0 p-6 pb-2">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
                            <Search className="text-blue-600 dark:text-blue-400" />
                            {t('Inventory Query', '库存查询')}
                        </h1>
                        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">{t('View detailed inventory records by location.', '查看各库位的详细库存记录。')}</p>
                    </div>
                    <button 
                        onClick={() => setIsImportOpen(true)}
                        className="px-4 py-2 bg-blue-600 text-white rounded-xl font-bold shadow-lg hover:bg-blue-700 transition-all flex items-center gap-2 active:scale-95"
                    >
                        <UploadCloud size={18} /> {t('Import Stock', '导入库存')}
                    </button>
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-hidden px-6 pb-6">
                <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col h-full transition-colors">
                    
                    {/* Controls - Fixed within Card */}
                    <div className="shrink-0 p-4 border-b border-gray-100 dark:border-slate-800 flex flex-col md:flex-row gap-4 bg-gray-50/30 dark:bg-slate-900/30">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                            <input 
                                className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500 transition-all dark:text-white"
                                placeholder={t("Search product name, SKU, Location...", "搜索商品名称、SKU、库位...")}
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="relative">
                            <select 
                                className="appearance-none pl-4 pr-10 py-2.5 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-xl text-sm font-bold text-gray-700 dark:text-gray-300 outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer min-w-[160px]"
                                value={warehouseFilter}
                                onChange={e => setWarehouseFilter(e.target.value)}
                            >
                                <option value="ALL">{t('All Warehouses', '所有仓库')}</option>
                                {warehouseOptions.map(w => <option key={String(w)} value={String(w)}>{w}</option>)}
                            </select>
                            <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                        </div>
                    </div>

                    {/* Table - Scrollable */}
                    <div className="flex-1 overflow-auto" ref={tableContainerRef}>
                        <table className="w-full text-left text-sm border-collapse min-w-[800px]">
                            <thead className="bg-gray-100 dark:bg-slate-950 text-gray-600 dark:text-gray-400 font-bold uppercase text-xs border-b border-gray-200 dark:border-slate-800 sticky top-0 z-10 shadow-sm">
                                <tr>
                                    <th className="px-6 py-4 bg-gray-100 dark:bg-slate-950">{t('Product Name', '商品名称')}</th>
                                    <th className="px-6 py-4 bg-gray-100 dark:bg-slate-950">{t('Code / SKU', '代码 / SKU')}</th>
                                    <th className="px-6 py-4 bg-gray-100 dark:bg-slate-950">{t('Location', '库位')}</th>
                                    <th className="px-6 py-4 text-center bg-gray-100 dark:bg-slate-950">{t('Qty', '数量')}</th>
                                    <th className="px-6 py-4 bg-gray-100 dark:bg-slate-950">{t('Warehouse', '仓库')}</th>
                                    <th className="px-6 py-4 text-right bg-gray-100 dark:bg-slate-950">{t('Last Updated', '最后更新')}</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-slate-800 transition-colors">
                                {currentItems.map((item, index) => (
                                    <tr key={`${item.id}-${index}`} className="hover:bg-blue-50/30 dark:hover:bg-blue-900/10 transition-colors group">
                                        <td className="px-6 py-4 font-bold text-gray-900 dark:text-white">{item.productName}</td>
                                        <td className="px-6 py-4 font-mono text-xs text-gray-500 dark:text-gray-400">{item.productCode}</td>
                                        <td className="px-6 py-4">
                                            <span className="bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 px-2 py-1 rounded text-xs font-mono font-bold border border-gray-200 dark:border-slate-700">
                                                {item.location}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-center font-bold text-gray-900 dark:text-white">{item.quantity}</td>
                                        <td className="px-6 py-4 text-gray-600 dark:text-gray-400">{item.warehouse}</td>
                                        <td className="px-6 py-4 text-right text-xs text-gray-400 font-mono">
                                            {new Date(item.updatedAt).toLocaleDateString()}
                                        </td>
                                    </tr>
                                ))}
                                {currentItems.length === 0 && (
                                    <tr>
                                        <td colSpan={6} className="py-20 text-center text-gray-400 dark:text-gray-600">
                                            <Package size={48} className="mx-auto mb-3 opacity-20" />
                                            <p className="font-bold">{t('No inventory records found.', '未找到库存记录。')}</p>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Pagination Footer - Fixed inside card */}
                    {totalItems > 0 && (
                        <div className="shrink-0 p-4 border-t border-gray-200 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 bg-gray-50/50 dark:bg-slate-950/50 transition-colors">
                             <div className="flex items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
                                 <span className="text-xs font-bold uppercase tracking-wider">{t('Rows per page', '每页行数')}</span>
                                 <select 
                                     className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-2 py-1 outline-none text-xs font-bold cursor-pointer transition-colors text-gray-700 dark:text-gray-300"
                                     value={itemsPerPage}
                                     onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                                 >
                                     <option value={20}>20</option>
                                     <option value={50}>50</option>
                                     <option value={100}>100</option>
                                     <option value={200}>200</option>
                                 </select>
                                 <div className="h-4 w-px bg-gray-300 dark:bg-slate-700 mx-2"></div>
                                 <span className="text-xs font-medium">
                                     {t('Showing', '显示')} {indexOfFirstItem + 1}-{Math.min(indexOfLastItem, totalItems)} {t('of', '/')} {totalItems}
                                 </span>
                             </div>
                             
                             <div className="flex items-center gap-2">
                                 <button onClick={() => handlePageChange(1)} disabled={currentPage === 1} className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors text-gray-600 dark:text-gray-400"><ChevronsLeft size={16} /></button>
                                 <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors text-gray-600 dark:text-gray-400"><ChevronLeft size={16} /></button>
                                 
                                 <span className="px-4 text-xs font-bold text-gray-700 dark:text-gray-300">
                                     {t('Page', '页')} {currentPage} {t('of', '/')} {totalPages || 1}
                                 </span>

                                 <button onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages || totalPages === 0} className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors text-gray-600 dark:text-gray-400"><ChevronRight size={16} /></button>
                                 <button onClick={() => handlePageChange(totalPages)} disabled={currentPage === totalPages || totalPages === 0} className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors text-gray-600 dark:text-gray-400"><ChevronsRight size={16} /></button>
                             </div>
                         </div>
                    )}
                </div>
            </div>

            <StockImportModal 
                isOpen={isImportOpen} 
                onClose={() => setIsImportOpen(false)} 
                onImport={bulkImportInventory}
                products={products}
            />
        </div>
    );
};

export default InventoryQuery;

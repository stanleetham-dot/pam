
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useInventory } from '../context/InventoryContext';
import { DiscrepancyReport, DiscrepancyItem, Product, DistributionOrder } from '../types';
import { 
    Search, Plus, Save, Camera, X, Check, ArrowLeft, 
    AlertTriangle, Package, Calendar, User, FileText, 
    ChevronRight, Scan, Minus, Image as ImageIcon, Trash2,
    CheckCircle2, ChevronDown, MapPin, Box, History, Edit, Eye,
    ShieldCheck, Lock, FileDown, MoreVertical, LayoutList, Grip
} from 'lucide-react';
import Scanner from './Scanner';
import * as XLSX from 'xlsx';

const DiscrepancyCheck: React.FC = () => {
    const { products, distributionOrders, outlets, addDiscrepancyReport, updateDiscrepancyReport, currentUser, language, addNotification, discrepancyReports } = useInventory();
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    // View State
    const [view, setView] = useState<'FORM' | 'HISTORY'>('FORM');
    const [editingId, setEditingId] = useState<string | null>(null);

    // Approval State
    const [approvalModal, setApprovalModal] = useState<{ isOpen: boolean; reportId: string | null }>({ isOpen: false, reportId: null });
    const [approvalRemark, setApprovalRemark] = useState('');

    // History Search State
    const [historySearch, setHistorySearch] = useState('');

    // Header State
    const [branchName, setBranchName] = useState(currentUser?.role === 'BRANCH' ? currentUser.name : ''); 
    const [orderNumber, setOrderNumber] = useState('');
    const [receivedPerson, setReceivedPerson] = useState(currentUser?.name || '');
    const [reportDate, setReportDate] = useState(new Date().toISOString().split('T')[0]);
    const [status, setStatus] = useState('Pending');
    const [lockedInfo, setLockedInfo] = useState<{ by: string, at: string, remark?: string } | null>(null);

    // Item State
    const [items, setItems] = useState<DiscrepancyItem[]>([]);
    
    // Product Search/Add State
    const [productSearch, setProductSearch] = useState('');
    const [showProductDropdown, setShowProductDropdown] = useState(false);
    
    // UI State
    const [isScannerOpen, setIsScannerOpen] = useState(false);
    const [relatedOrder, setRelatedOrder] = useState<DistributionOrder | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [activePhotoItemIndex, setActivePhotoItemIndex] = useState<number | null>(null);

    // Role Checks
    const canApprove = useMemo(() => ['ADMIN', 'MANAGER', 'INSPECTOR'].includes(currentUser?.role || ''), [currentUser]);
    const canExport = useMemo(() => currentUser?.role !== 'BRANCH', [currentUser]);
    const isFormLocked = status === 'Approved';

    // 1. Filter Orders based on selected Branch
    const availableOrders = useMemo(() => {
        if (!branchName) return [];
        const normalizedBranch = branchName.trim().toLowerCase();
        
        return distributionOrders.filter(o => {
            const matchBranch = (o.receivingBranch || '').trim().toLowerCase() === normalizedBranch;
            const validStatuses = [
                'pending', 'picking', 'pick complete', 'discrepancy', 'approved', 
                'ready to ship', 'shipped', 'in transit', 'delivered', 'received'
            ];
            const matchStatus = validStatuses.includes((o.status || '').toLowerCase());
            return matchBranch && matchStatus;
        }).sort((a, b) => new Date(b.createTime).getTime() - new Date(a.createTime).getTime());
    }, [distributionOrders, branchName]);

    // 2. Filter Reports History based on Role & Search
    const filteredReports = useMemo(() => {
        let reports = discrepancyReports;
        if (currentUser?.role === 'BRANCH') {
            reports = reports.filter(r => r.branchName === currentUser.name);
        }
        
        if (historySearch) {
            const lowerSearch = historySearch.toLowerCase();
            reports = reports.filter(r => 
                r.orderNumber?.toLowerCase().includes(lowerSearch) ||
                r.branchName.toLowerCase().includes(lowerSearch) ||
                r.packageNo.toLowerCase().includes(lowerSearch)
            );
        }
        
        return reports.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }, [discrepancyReports, currentUser, historySearch]);

    // 3. Handle Order Selection
    const handleOrderSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
        if (isFormLocked) return;
        const val = e.target.value;
        setOrderNumber(val);
        const found = distributionOrders.find(o => o.orderNumber === val);
        setRelatedOrder(found || null);
    };

    // 4. Filter Products for Manual Input
    const filteredProducts = useMemo(() => {
        if (!productSearch) return [];
        const lower = productSearch.toLowerCase();
        return products.filter(p => 
            p.name.toLowerCase().includes(lower) || 
            p.sku.toLowerCase().includes(lower) || 
            p.barcode.includes(lower)
        ).slice(0, 5); 
    }, [products, productSearch]);

    const handleScan = (code: string) => {
        if (isFormLocked) return;
        setIsScannerOpen(false);
        const product = products.find(p => p.barcode === code || p.sku === code);
        
        if (product) {
            addItem(product);
            setProductSearch(''); 
        } else {
            const newItem: DiscrepancyItem = {
                productId: 'UNKNOWN',
                productCode: code,
                productName: 'Unknown Product',
                receivedQty: 1,
                variance: 1,
                remark: t('Scanned item not in database', '扫描商品不在数据库中')
            };
            setItems(prev => [newItem, ...prev]);
            addNotification('warning', t('Unknown Item', '未知商品'), t('Item not found in product list.', '商品未在产品列表中找到。'));
        }
    };

    const addItem = (product: Product) => {
        if (isFormLocked) return;
        let expectedQty = 0;
        if (relatedOrder) {
            const orderItem = relatedOrder.items.find(i => i.productId === product.id || i.productCode === product.barcode);
            if (orderItem) expectedQty = orderItem.orderedQty;
        }

        const existingIdx = items.findIndex(i => i.productId === product.id);
        if (existingIdx >= 0) {
            const newItems = [...items];
            newItems[existingIdx].receivedQty += 1;
            newItems[existingIdx].variance = newItems[existingIdx].receivedQty - expectedQty;
            
            if (newItems[existingIdx].variance > 0) newItems[existingIdx].remark = t('Excess received', '多收');
            else if (newItems[existingIdx].variance < 0) newItems[existingIdx].remark = t('Shortage', '少收');
            else newItems[existingIdx].remark = '';

            setItems(newItems);
        } else {
            const receivedQty = 1;
            const variance = receivedQty - expectedQty;
            let remark = '';
            if (variance > 0) remark = t('Excess received', '多收');
            else if (variance < 0) remark = t('Shortage', '少收');

            const newItem: DiscrepancyItem = {
                productId: product.id,
                productCode: product.barcode,
                productName: product.name,
                receivedQty: receivedQty,
                variance: variance,
                remark: remark
            };
            setItems(prev => [newItem, ...prev]);
        }
        setShowProductDropdown(false);
        setProductSearch('');
    };

    const updateItem = (index: number, updates: Partial<DiscrepancyItem>) => {
        if (isFormLocked) return;
        const newItems = [...items];
        const item = { ...newItems[index], ...updates };
        
        if (updates.receivedQty !== undefined) {
            let expectedQty = 0;
            if (relatedOrder) {
                const orderItem = relatedOrder.items.find(i => i.productId === item.productId || i.productCode === item.productCode);
                if (orderItem) expectedQty = orderItem.orderedQty;
            }
            item.variance = item.receivedQty - expectedQty;

            if (item.variance > 0) {
                item.remark = t('Excess received', '多收');
            } else if (item.variance < 0) {
                item.remark = t('Shortage', '少收');
            } else {
                item.remark = '';
            }
        }
        
        newItems[index] = item;
        setItems(newItems);
    };

    const removeItem = (index: number) => {
        if (isFormLocked) return;
        setItems(prev => prev.filter((_, i) => i !== index));
    };

    const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (isFormLocked) return;
        const file = e.target.files?.[0];
        if (!file || activePhotoItemIndex === null) return;

        const reader = new FileReader();
        reader.onload = (evt) => {
            if (evt.target?.result) {
                updateItem(activePhotoItemIndex, { photo: evt.target.result as string });
            }
        };
        reader.readAsDataURL(file);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const handleSave = async () => {
        if (isFormLocked) return;
        if (!branchName) {
            addNotification('error', t('Missing Info', '信息缺失'), t('Branch Name is required.', '必须选择分店。'));
            return;
        }
        if (!orderNumber) {
            addNotification('error', t('Missing Info', '信息缺失'), t('Related Order is required.', '必须关联订单。'));
            return;
        }
        if (items.length === 0) {
            addNotification('warning', t('No Items', '无商品'), t('Please scan or add items.', '请扫描或添加商品。'));
            return;
        }

        const report: DiscrepancyReport = {
            id: editingId || crypto.randomUUID(),
            packageNo: editingId ? (discrepancyReports.find(r => r.id === editingId)?.packageNo || `PKG-${Date.now()}`) : `PKG-${Date.now().toString().slice(-6)}`,
            orderNumber: orderNumber,
            branchName: branchName,
            receivedPerson,
            reportDate,
            status,
            items,
            createdAt: editingId ? (discrepancyReports.find(r => r.id === editingId)?.createdAt || new Date().toISOString()) : new Date().toISOString()
        };

        if (editingId) {
            await updateDiscrepancyReport(report);
            addNotification('success', t('Report Updated', '报告已更新'), t('Discrepancy report updated successfully.', '差异报告更新成功。'));
        } else {
            await addDiscrepancyReport(report);
            addNotification('success', t('Report Saved', '报告已保存'), t('Discrepancy report created successfully.', '差异报告创建成功。'));
        }
        
        // Reset form
        setEditingId(null);
        setOrderNumber('');
        setItems([]);
        setRelatedOrder(null);
        setView('HISTORY'); 
    };

    const handleEditReport = (report: DiscrepancyReport) => {
        setEditingId(report.id);
        setBranchName(report.branchName);
        setOrderNumber(report.orderNumber || '');
        setReceivedPerson(report.receivedPerson);
        setReportDate(report.reportDate);
        setStatus(report.status);
        setItems(report.items);
        
        // Lock check
        if (report.status === 'Approved') {
            setLockedInfo({
                by: report.approvedBy || 'Admin',
                at: report.approvedAt || '',
                remark: report.approvalRemark
            });
        } else {
            setLockedInfo(null);
        }
        
        const found = distributionOrders.find(o => o.orderNumber === report.orderNumber);
        setRelatedOrder(found || null);

        setView('FORM');
    };

    const handleNewCheck = () => {
        setEditingId(null);
        setOrderNumber('');
        setItems([]);
        setRelatedOrder(null);
        setReceivedPerson(currentUser?.name || '');
        setReportDate(new Date().toISOString().split('T')[0]);
        setStatus('Pending');
        setLockedInfo(null);
        setView('FORM');
    };

    const handleApproveClick = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        setApprovalModal({ isOpen: true, reportId: id });
        setApprovalRemark('');
    };

    const confirmApprove = async () => {
        if (!approvalModal.reportId) return;
        const report = discrepancyReports.find(r => r.id === approvalModal.reportId);
        if (report) {
            const updatedReport: DiscrepancyReport = {
                ...report,
                status: 'Approved',
                approvalRemark: approvalRemark,
                approvedBy: currentUser?.name || 'Unknown',
                approvedAt: new Date().toISOString()
            };
            await updateDiscrepancyReport(updatedReport);
            addNotification('success', t('Report Approved', '报告已批准'), t('Report has been locked.', '报告已锁定。'));
        }
        setApprovalModal({ isOpen: false, reportId: null });
    };

    const handleExport = (e: React.MouseEvent, report: DiscrepancyReport) => {
        e.stopPropagation();
        const data = report.items.map(item => {
            const product = products.find(p => p.id === item.productId || p.barcode === item.productCode);
            // Unit Qty (Ordered) = Received - Variance
            const unitQty = item.receivedQty - item.variance;

            return {
                'Branch': report.branchName,
                'Order No': report.orderNumber,
                'Code': item.productCode,
                'Product': item.productName,
                'Spec': product?.specification || '',
                'Location': product?.location || '',
                'Unit Qty': unitQty,
                'Received Qty': item.receivedQty,
                'Variance': item.variance,
                'Remark': item.remark || '',
                'Date': report.reportDate,
                'Receiver': report.receivedPerson,
                'Status': report.status,
                'Approval Remark': report.approvalRemark || '',
                'Approved By': report.approvedBy || ''
            };
        });
        
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Discrepancy Report");
        XLSX.writeFile(wb, `Discrepancy_${report.packageNo}.xlsx`);
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 font-sans transition-colors relative">
            {isScannerOpen && <Scanner onScan={handleScan} onClose={() => setIsScannerOpen(false)} title={t("Scan Item", "扫描商品")} />}
            
            {/* Navigation Header */}
            <div className="bg-white dark:bg-slate-900 border-b border-gray-100 dark:border-slate-800 flex items-center justify-between px-4 py-3 shrink-0 sticky top-0 z-20">
                <div className="flex gap-1 bg-gray-100 dark:bg-slate-800 p-1 rounded-xl">
                    <button 
                        onClick={handleNewCheck}
                        className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${view === 'FORM' && !editingId ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}`}
                    >
                        <Plus size={16} /> <span className="hidden sm:inline">{t('New Check', '新建检查')}</span>
                    </button>
                    <button 
                        onClick={() => setView('HISTORY')}
                        className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${view === 'HISTORY' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}`}
                    >
                        <History size={16} /> {t('Report History', '报告记录')}
                    </button>
                </div>
                {view === 'FORM' && editingId && (
                    <span className={`text-xs font-bold px-3 py-1 rounded-full border ${isFormLocked ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400' : 'bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-900/20'}`}>
                        {isFormLocked ? t('Approved', '已批准') : t('Editing', '编辑中')}
                    </span>
                )}
            </div>

            {view === 'FORM' ? (
                <div className="flex-1 overflow-hidden flex flex-col">
                    {/* Header Info */}
                    <div className="bg-white dark:bg-slate-900 px-6 py-4 border-b border-gray-100 dark:border-slate-800 shrink-0">
                        {isFormLocked && lockedInfo && (
                            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-xl p-3 flex items-start gap-3 mb-4">
                                <ShieldCheck size={20} className="text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                                <div>
                                    <p className="text-sm font-bold text-blue-800 dark:text-blue-200">Approved by {lockedInfo.by}</p>
                                    <p className="text-xs text-blue-600 dark:text-blue-400 mt-0.5">{new Date(lockedInfo.at).toLocaleString()}</p>
                                    {lockedInfo.remark && (
                                        <p className="text-xs text-blue-700 dark:text-blue-300 mt-2 bg-white dark:bg-slate-800 p-2 rounded border border-blue-100 dark:border-blue-800">
                                            "{lockedInfo.remark}"
                                        </p>
                                    )}
                                </div>
                            </div>
                        )}

                        <div className="flex items-center gap-3 mb-4">
                            <div className={`p-3 rounded-xl ${currentUser?.role === 'BRANCH' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'}`}>
                                <MapPin size={24} />
                            </div>
                            <div>
                                <h2 className="text-lg font-bold text-gray-900 dark:text-white">{branchName || 'Select Branch'}</h2>
                                <p className="text-xs text-gray-500 dark:text-gray-400">{orderNumber || 'No Order Selected'}</p>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {!isFormLocked && (
                                <>
                                    {currentUser?.role !== 'BRANCH' && (
                                        <div>
                                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">{t('Branch', '分店')}</label>
                                            <div className="relative">
                                                <select 
                                                    className="w-full pl-3 pr-8 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg text-sm font-bold text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
                                                    value={branchName}
                                                    onChange={e => { setBranchName(e.target.value); setOrderNumber(''); setRelatedOrder(null); }}
                                                >
                                                    <option value="">{t('Select Branch', '选择分店')}</option>
                                                    {outlets.map(o => <option key={o.id} value={o.recipient}>{o.recipient}</option>)}
                                                </select>
                                                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
                                            </div>
                                        </div>
                                    )}
                                    <div>
                                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">{t('Order', '订单')}</label>
                                        <div className="relative">
                                            <select 
                                                className={`w-full pl-3 pr-8 py-2 border rounded-lg text-sm font-bold outline-none appearance-none transition-colors ${!orderNumber ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-900 dark:text-blue-100' : 'bg-gray-50 dark:bg-slate-800 border-gray-200 dark:border-slate-700 text-gray-900 dark:text-white'}`}
                                                value={orderNumber}
                                                onChange={handleOrderSelect}
                                                disabled={!branchName}
                                            >
                                                <option value="">{t('Select Order', '选择订单')}</option>
                                                {availableOrders.map(o => (
                                                    <option key={o.id} value={o.orderNumber}>{o.orderNumber} - {o.status}</option>
                                                ))}
                                            </select>
                                            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
                                        </div>
                                    </div>
                                </>
                            )}
                            <div className="flex gap-4">
                                <div className="flex-1">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">{t('Date', '日期')}</label>
                                    <input 
                                        type="date"
                                        className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm font-bold text-gray-800 dark:text-white outline-none disabled:opacity-70"
                                        value={reportDate}
                                        onChange={e => setReportDate(e.target.value)}
                                        disabled={isFormLocked}
                                    />
                                </div>
                                <div className="flex-1">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">{t('Receiver', '接收人')}</label>
                                    <input 
                                        className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm font-bold text-gray-800 dark:text-white outline-none disabled:opacity-70 disabled:bg-gray-100 dark:disabled:bg-slate-800/50"
                                        value={receivedPerson}
                                        readOnly
                                        disabled
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Table / List Header */}
                    <div className="bg-gray-50 dark:bg-slate-950 px-6 py-2 border-b border-gray-200 dark:border-slate-800 flex justify-between items-center shrink-0">
                        <div className="flex items-center gap-2">
                            <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">{items.length}</span>
                            <span className="text-xs font-bold text-gray-500 uppercase">{t('Items', '商品')}</span>
                        </div>
                        {!isFormLocked && (
                            <div className="flex gap-2">
                                <div className="relative">
                                    <input 
                                        className="pl-8 pr-3 py-1.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg text-xs outline-none w-40"
                                        placeholder={t("Scan/Search...", "扫描/搜索...")}
                                        value={productSearch}
                                        onChange={(e) => { setProductSearch(e.target.value); setShowProductDropdown(true); }}
                                        onFocus={() => setShowProductDropdown(true)}
                                    />
                                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" size={12} />
                                    {showProductDropdown && productSearch && (
                                        <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg shadow-xl z-50 max-h-48 overflow-y-auto">
                                            {filteredProducts.map(p => (
                                                <button 
                                                    key={p.id}
                                                    onClick={() => addItem(p)}
                                                    className="w-full text-left p-2 border-b border-gray-100 dark:border-slate-800 last:border-0 hover:bg-gray-50 dark:hover:bg-slate-800"
                                                >
                                                    <p className="text-xs font-bold text-gray-900 dark:text-white">{p.name}</p>
                                                    <p className="text-[10px] text-gray-500">{p.sku}</p>
                                                </button>
                                            ))}
                                        </div>
                                    )}
                                </div>
                                <button onClick={() => setIsScannerOpen(true)} className="p-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm">
                                    <Scan size={14} />
                                </button>
                            </div>
                        )}
                    </div>

                    {/* Content Body */}
                    <div className="flex-1 overflow-y-auto bg-gray-50/50 dark:bg-slate-950/30" onClick={() => setShowProductDropdown(false)}>
                        {items.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-20 text-gray-400 dark:text-gray-600">
                                <Package size={48} className="mb-3 opacity-20" />
                                <p className="text-sm font-medium">{t('No items added yet.', '暂无添加商品。')}</p>
                            </div>
                        ) : (
                            <div className="divide-y divide-gray-100 dark:divide-slate-800 border-b border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900">
                                {/* Desktop Table Header */}
                                <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 bg-gray-50 dark:bg-slate-950 text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                                    <div className="col-span-4">Product Details</div>
                                    <div className="col-span-1 text-center">Unit Qty</div>
                                    <div className="col-span-2 text-center">Received</div>
                                    <div className="col-span-1 text-center">Variance</div>
                                    <div className="col-span-3">Remark</div>
                                    <div className="col-span-1 text-right">Action</div>
                                </div>

                                {items.map((item, idx) => (
                                    <div key={idx} className="group hover:bg-blue-50/50 dark:hover:bg-blue-900/10 transition-colors">
                                        {/* Mobile Card Layout */}
                                        <div className="md:hidden p-4 relative">
                                            {!isFormLocked && <button onClick={() => removeItem(idx)} className="absolute top-4 right-4 text-gray-300 hover:text-red-500"><X size={16} /></button>}
                                            <div className="pr-8 mb-3">
                                                <h3 className="font-bold text-gray-900 dark:text-white text-sm">{item.productName}</h3>
                                                <p className="text-xs font-mono text-gray-500 dark:text-gray-400 mt-0.5">{item.productCode}</p>
                                            </div>
                                            <div className="grid grid-cols-3 gap-4 items-center mb-3">
                                                <div>
                                                    <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Unit Qty</label>
                                                    <span className="text-sm font-bold text-gray-900 dark:text-white">{item.receivedQty - item.variance}</span>
                                                </div>
                                                <div>
                                                    <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Received</label>
                                                    <div className={`flex items-center gap-1 bg-gray-50 dark:bg-slate-800 rounded-lg p-1 w-fit border border-gray-200 dark:border-slate-700 ${isFormLocked ? 'opacity-70 pointer-events-none' : ''}`}>
                                                        <button disabled={isFormLocked} onClick={() => updateItem(idx, { receivedQty: Math.max(0, item.receivedQty - 1) })} className="p-1 hover:bg-white dark:hover:bg-slate-700 rounded text-gray-500"><Minus size={12}/></button>
                                                        <span className="text-sm font-bold w-8 text-center tabular-nums text-gray-900 dark:text-white">{item.receivedQty}</span>
                                                        <button disabled={isFormLocked} onClick={() => updateItem(idx, { receivedQty: item.receivedQty + 1 })} className="p-1 hover:bg-white dark:hover:bg-slate-700 rounded text-gray-500"><Plus size={12}/></button>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Variance</label>
                                                    <span className={`text-sm font-black ${item.variance > 0 ? 'text-green-600' : item.variance < 0 ? 'text-red-500' : 'text-gray-400'}`}>
                                                        {item.variance > 0 ? '+' : ''}{item.variance}
                                                    </span>
                                                </div>
                                            </div>
                                            <input 
                                                className="w-full text-xs p-2 bg-gray-50 dark:bg-slate-800 rounded-lg border border-transparent focus:border-blue-500 outline-none text-gray-800 dark:text-white transition-colors disabled:opacity-70"
                                                placeholder="Remark..."
                                                value={item.remark || ''}
                                                onChange={e => updateItem(idx, { remark: e.target.value })}
                                                disabled={isFormLocked}
                                            />
                                        </div>

                                        {/* Desktop Table Layout */}
                                        <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 items-center text-sm">
                                            <div className="col-span-4">
                                                <div className="font-bold text-gray-900 dark:text-white text-sm">{item.productName}</div>
                                                <div className="text-xs font-mono text-gray-500 dark:text-gray-400">{item.productCode}</div>
                                            </div>
                                            <div className="col-span-1 text-center text-gray-500 font-medium">
                                                {item.receivedQty - item.variance}
                                            </div>
                                            <div className="col-span-2 flex justify-center">
                                                <div className={`flex items-center gap-1 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 p-0.5 shadow-sm ${isFormLocked ? 'opacity-70 pointer-events-none' : ''}`}>
                                                    <button disabled={isFormLocked} onClick={() => updateItem(idx, { receivedQty: Math.max(0, item.receivedQty - 1) })} className="p-1 hover:bg-gray-100 dark:hover:bg-slate-700 rounded text-gray-500"><Minus size={12}/></button>
                                                    <span className="text-sm font-bold w-8 text-center tabular-nums text-gray-900 dark:text-white">{item.receivedQty}</span>
                                                    <button disabled={isFormLocked} onClick={() => updateItem(idx, { receivedQty: item.receivedQty + 1 })} className="p-1 hover:bg-gray-100 dark:hover:bg-slate-700 rounded text-gray-500"><Plus size={12}/></button>
                                                </div>
                                            </div>
                                            <div className="col-span-1 text-center font-bold">
                                                <span className={`${item.variance > 0 ? 'text-green-600' : item.variance < 0 ? 'text-red-500' : 'text-gray-300'}`}>
                                                    {item.variance > 0 ? '+' : ''}{item.variance}
                                                </span>
                                            </div>
                                            <div className="col-span-3">
                                                <input 
                                                    className="w-full text-xs p-1.5 bg-gray-50 dark:bg-slate-800 rounded border border-transparent focus:border-blue-500 outline-none text-gray-800 dark:text-white transition-colors disabled:opacity-70"
                                                    placeholder="Remark..."
                                                    value={item.remark || ''}
                                                    onChange={e => updateItem(idx, { remark: e.target.value })}
                                                    disabled={isFormLocked}
                                                />
                                            </div>
                                            <div className="col-span-1 text-right flex justify-end gap-2">
                                                <button 
                                                    disabled={isFormLocked}
                                                    onClick={() => { setActivePhotoItemIndex(idx); fileInputRef.current?.click(); }}
                                                    className={`p-1.5 rounded-lg transition-colors ${item.photo ? 'text-blue-500 bg-blue-50' : 'text-gray-400 hover:text-blue-500 hover:bg-blue-50'} disabled:opacity-50`}
                                                >
                                                    <Camera size={16} />
                                                </button>
                                                {!isFormLocked && (
                                                    <button onClick={() => removeItem(idx)} className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                                                        <Trash2 size={16} />
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload} />

                    {/* Footer Actions */}
                    {!isFormLocked && (
                        <div className="p-4 bg-white dark:bg-slate-900 border-t border-gray-100 dark:border-slate-800 safe-area-pb shrink-0">
                            <button 
                                onClick={handleSave}
                                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition-all shadow-lg shadow-blue-200 dark:shadow-none text-base"
                            >
                                <Save size={20} /> {editingId ? t('Update Report', '更新报告') : t('Save Report', '保存报告')}
                            </button>
                        </div>
                    )}
                </div>
            ) : (
                // HISTORY VIEW
                <div className="flex-1 flex flex-col overflow-hidden bg-gray-50/50 dark:bg-slate-950/30">
                    <div className="p-4 border-b border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 sticky top-0 z-10">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                            <input 
                                className="w-full pl-9 pr-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-gray-400"
                                placeholder={t("Search Order #, Branch...", "搜索单号, 分店...")}
                                value={historySearch}
                                onChange={e => setHistorySearch(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        {filteredReports.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-20 text-gray-400 dark:text-gray-600">
                                <History size={48} className="mb-3 opacity-20" />
                                <p className="text-sm font-medium">{t('No history found.', '暂无历史记录。')}</p>
                            </div>
                        ) : (
                            filteredReports.map(report => {
                                const isApproved = report.status === 'Approved';
                                return (
                                <div key={report.id} className={`bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-100 dark:border-slate-800 overflow-hidden hover:shadow-md transition-shadow cursor-pointer border-l-4 ${isApproved ? 'border-l-green-500' : 'border-l-amber-500'}`} onClick={() => handleEditReport(report)}>
                                    <div className="p-4">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex flex-col">
                                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{t('Order #', '单号')}</span>
                                                <span className="text-xs font-mono font-bold text-gray-600 dark:text-gray-400">{report.orderNumber || '-'}</span>
                                            </div>
                                            <div className="flex flex-col items-end">
                                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{t('Date', '日期')}</span>
                                                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">{new Date(report.createdAt).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                        
                                        <div className="mb-3">
                                            <h3 className="font-bold text-gray-900 dark:text-white text-base line-clamp-1">{report.branchName}</h3>
                                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{report.packageNo}</p>
                                        </div>

                                        <div className="flex justify-between items-center pt-3 border-t border-gray-50 dark:border-slate-800">
                                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide border ${isApproved ? 'bg-green-50 text-green-700 border-green-100 dark:bg-green-900/20 dark:text-green-400 dark:border-green-900/50' : 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-900/50'}`}>
                                                {report.status}
                                            </span>
                                            <span className="text-xs font-bold text-gray-600 dark:text-gray-400 flex items-center gap-1">
                                                <Package size={12} /> {report.items.length} {t('Items', '商品')}
                                            </span>
                                        </div>
                                    </div>
                                    
                                    {/* Action Bar */}
                                    <div className="bg-gray-50 dark:bg-slate-950/50 px-4 py-2 flex justify-end gap-2 border-t border-gray-100 dark:border-slate-800">
                                        {canExport && (
                                            <button 
                                                onClick={(e) => handleExport(e, report)}
                                                className="p-1.5 text-gray-500 hover:text-blue-600 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg shadow-sm"
                                            >
                                                <FileDown size={14} />
                                            </button>
                                        )}
                                        {canApprove && !isApproved && (
                                            <button 
                                                onClick={(e) => handleApproveClick(e, report.id)}
                                                className="p-1.5 text-green-600 bg-white dark:bg-slate-800 border border-green-200 dark:border-green-900/50 rounded-lg shadow-sm hover:bg-green-50"
                                            >
                                                <ShieldCheck size={14} />
                                            </button>
                                        )}
                                    </div>
                                </div>
                            )})
                        )}
                    </div>
                </div>
            )}

            {/* Approval Modal */}
            {approvalModal.isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-sm p-6 shadow-2xl border border-gray-100 dark:border-slate-800">
                        <div className="flex items-center gap-3 mb-4 text-blue-600 dark:text-blue-400">
                            <ShieldCheck size={32} />
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('Approve Report', '批准报告')}</h3>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                            {t('This will lock the report and prevent further edits. Add an optional remark below.', '这将锁定报告并防止进一步编辑。请在下方添加可选备注。')}
                        </p>
                        <textarea 
                            className="w-full p-3 border border-gray-200 dark:border-slate-700 rounded-xl bg-gray-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-blue-500 outline-none text-gray-900 dark:text-white mb-6 resize-none"
                            rows={3}
                            placeholder={t('Approval remark...', '批准备注...')}
                            value={approvalRemark}
                            onChange={(e) => setApprovalRemark(e.target.value)}
                        />
                        <div className="flex gap-3">
                            <button onClick={() => setApprovalModal({isOpen: false, reportId: null})} className="flex-1 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 font-bold text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors text-sm">
                                {t('Cancel', '取消')}
                            </button>
                            <button onClick={confirmApprove} className="flex-1 py-2.5 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-colors shadow-lg active:scale-95 text-sm">
                                {t('Confirm Approval', '确认批准')}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DiscrepancyCheck;

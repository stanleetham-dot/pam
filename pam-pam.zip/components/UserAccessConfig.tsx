
import React, { useState, useEffect } from 'react';
import { 
    ArrowLeft, Save, Shield, CheckSquare, Square, CornerDownRight, RotateCcw, 
    User, Eye, EyeOff, Check, X, RefreshCcw, Briefcase, Store,
    LayoutDashboard, BrainCircuit, ClipboardList, Truck, ArrowDownToLine, Package, History, 
    ClipboardCheck, Warehouse, Settings, Layers, ArrowRightLeft, MapPin, Boxes, 
    ShoppingCart, FileText, Tag, Clock, Search, Edit2, ShieldAlert, Scan, Users, Circle,
    Phone, Mail, KeyRound, BadgeCheck
} from 'lucide-react';
import { UserProfile, RoleConfig, PermissionObject, DistributionOutlet } from '../types';
import { APP_MODULES } from '../constants';

interface UserAccessConfigProps {
    user: UserProfile | null;
    roleConfigs: Record<string, RoleConfig>;
    onSave: (user: Partial<UserProfile>, isNew: boolean) => void;
    onClose: () => void;
    outlets?: DistributionOutlet[];
}

const getModuleIcon = (key: string) => {
    switch (key) {
        case 'DASHBOARD': return LayoutDashboard;
        case 'AI_ASSISTANT': return BrainCircuit;
        case 'TASK_MANAGER': return CheckSquare;
        case 'ORDER_MGMT_GROUP': return ClipboardList;
        case 'OM_TASK_MANAGEMENT': return CheckSquare;
        case 'OM_DISTRIBUTION_ORDER': return Truck;
        case 'PICKING_PLAN': return ClipboardCheck;
        case 'DISTRIBUTION_METHOD': return ArrowDownToLine;
        case 'WAREHOUSE_MGMT_GROUP': return Warehouse;
        case 'WAREHOUSE_CONFIG': return Settings;
        case 'SHELF_ARRANGEMENT': return Layers;
        case 'DELIVERY_MGMT_GROUP': return Truck;
        case 'DM_DISTRIBUTION_CENTER': return Warehouse;
        case 'DM_TRANSFER_OUT_ORDER': return ArrowRightLeft;
        case 'DM_DELIVERY_TRACKING': return MapPin;
        case 'PURCHASING_GROUP': return ShoppingCart;
        case 'PURCHASING': return FileText;
        case 'RECEIVING_ORDERS': return ArrowDownToLine;
        case 'INBOUND': return ArrowDownToLine;
        case 'PRODUCT_MGMT_GROUP': return Tag;
        case 'INVENTORY_PRODUCT': return Package;
        case 'INVENTORY_EXPIRE': return Clock;
        case 'INVENTORY_GROUP': return Boxes;
        case 'INVENTORY_QUERY': return Search;
        case 'INVENTORY_ADJUSTMENT': return Edit2;
        case 'INVENTORY_TRANSFER': return ArrowRightLeft;
        case 'INVENTORY_DISCREPANCY': return ShieldAlert;
        case 'SCAN_OPS_GROUP': return Scan;
        case 'SCAN_TO_SHELF': return Scan;
        case 'SKU_LOOKUP': return Search;
        case 'SHELF_LOGS': return History;
        case 'ACCOUNT_MANAGEMENT': return Users;
        case 'SETTINGS': return Settings;
        default: return Circle;
    }
};

const ToggleSwitch: React.FC<{ checked: boolean; onChange: () => void; disabled?: boolean }> = ({ checked, onChange, disabled }) => (
    <button
        type="button"
        disabled={disabled}
        onClick={onChange}
        className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${checked ? 'bg-blue-600' : 'bg-gray-200 dark:bg-slate-700'} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
        <span className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${checked ? 'translate-x-5' : 'translate-x-0'}`} />
    </button>
);

const PermissionRow: React.FC<{ 
    itemKey: string, 
    label: string, 
    isChild?: boolean, 
    localConfig: RoleConfig,
    togglePerm: (key: string, type: keyof PermissionObject) => void,
    toggleAllRow: (key: string, val: boolean) => void,
    handleSharingChange: (key: string, val: string) => void
}> = React.memo(({ itemKey, label, isChild, localConfig, togglePerm, toggleAllRow, handleSharingChange }) => {
    const perms = localConfig.objects[itemKey] || { create: false, read: false, edit: false, delete: false, approve: false, reject: false, undo: false, sharing: 'Own Only' };
    const isAll = perms.read && perms.create && perms.edit && perms.delete && perms.approve && perms.reject && perms.undo;
    const Icon = getModuleIcon(itemKey);

    return (
        <tr className={`border-b border-gray-50 dark:border-slate-800 hover:bg-gray-50 dark:hover:bg-slate-800/50 transition-colors ${isChild ? 'bg-white dark:bg-slate-900' : 'bg-gray-50/30 dark:bg-slate-900/30'}`}>
            <td className="px-6 py-4">
                <div className={`flex items-center gap-3 ${isChild ? 'pl-8' : ''}`}>
                    {isChild && <CornerDownRight size={14} className="text-gray-300 dark:text-gray-600 shrink-0" />}
                    <div className="flex items-center gap-3 overflow-hidden">
                        <Icon size={18} className={`${isChild ? 'text-gray-400 dark:text-gray-500' : 'text-blue-600 dark:text-blue-400'} shrink-0`} />
                        <span className={`text-sm font-medium ${isChild ? 'text-gray-600 dark:text-gray-400' : 'text-gray-900 dark:text-white'}`}>{label}</span>
                    </div>
                </div>
            </td>
            <td className="px-2 py-4 text-center">
                <button 
                    onClick={() => toggleAllRow(itemKey, !isAll)} 
                    className={`p-1 rounded transition-colors ${isAll ? 'text-blue-600 dark:text-blue-400' : 'text-gray-300 dark:text-gray-600 hover:text-gray-500'}`}
                >
                    {isAll ? <CheckSquare size={20} /> : <Square size={20} />}
                </button>
            </td>
            <td className="px-2 py-4 text-center"><ToggleSwitch checked={perms.read} onChange={() => togglePerm(itemKey, 'read')} /></td>
            <td className="px-2 py-4 text-center"><ToggleSwitch checked={perms.create} onChange={() => togglePerm(itemKey, 'create')} /></td>
            <td className="px-2 py-4 text-center"><ToggleSwitch checked={perms.edit} onChange={() => togglePerm(itemKey, 'edit')} /></td>
            <td className="px-2 py-4 text-center"><ToggleSwitch checked={perms.delete} onChange={() => togglePerm(itemKey, 'delete')} /></td>
            <td className="px-2 py-4 text-center border-l border-gray-100 dark:border-slate-800 pl-4"><ToggleSwitch checked={perms.approve} onChange={() => togglePerm(itemKey, 'approve')} /></td>
            <td className="px-2 py-4 text-center"><ToggleSwitch checked={perms.reject} onChange={() => togglePerm(itemKey, 'reject')} /></td>
            <td className="px-2 py-4 text-center border-l border-gray-100 dark:border-slate-800 pl-4"><ToggleSwitch checked={perms.undo} onChange={() => togglePerm(itemKey, 'undo')} /></td>
            <td className="px-4 py-4 text-right">
                <select 
                    className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg text-xs px-2 py-1.5 outline-none focus:ring-2 focus:ring-blue-500 text-gray-700 dark:text-gray-300 font-medium cursor-pointer transition-colors w-28"
                    value={perms.sharing || 'Own Only'}
                    onChange={(e) => handleSharingChange(itemKey, e.target.value)}
                >
                    <option>Everyone</option>
                    <option>Business Unit</option>
                    <option>Own Only</option>
                </select>
            </td>
        </tr>
    );
});

// Moved InputField outside to prevent re-creation
const InputField = ({ label, value, onChange, icon: Icon, error, placeholder, type = "text" }: any) => (
    <div className="group">
        <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1.5 ml-1">{label}</label>
        <div className="relative">
            {Icon && <Icon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />}
            <input 
                type={type}
                className={`w-full ${Icon ? 'pl-10' : 'px-4'} pr-4 py-2.5 bg-white dark:bg-slate-800 border rounded-xl text-sm font-medium text-gray-900 dark:text-white placeholder:text-gray-400 focus:ring-2 focus:ring-blue-500 outline-none transition-colors ${error ? 'border-red-500 focus:ring-red-200' : 'border-gray-200 dark:border-slate-700'}`}
                value={value}
                onChange={e => onChange(e.target.value)}
                placeholder={placeholder}
            />
        </div>
        {error && <span className="text-[10px] text-red-500 mt-1 ml-1">Required field</span>}
    </div>
);

export const UserAccessConfig: React.FC<UserAccessConfigProps> = ({ user, roleConfigs, onSave, onClose, outlets = [] }) => {
    const isNew = !user;
    
    // Identity State
    const [formData, setFormData] = useState<Partial<UserProfile>>({
        name: '', username: '', email: '', phone: '', employmentType: 'Fulltime', role: 'USER', password: '', avatar: '', status: 'Active'
    });
    const [showPassword, setShowPassword] = useState(false);
    const [errors, setErrors] = useState<Record<string, boolean>>({});
    
    // Permission State
    const [localConfig, setLocalConfig] = useState<RoleConfig | null>(null);
    const [isCustomized, setIsCustomized] = useState(false);

    useEffect(() => {
        if (user) {
            setFormData({ ...user, password: user.password || '' });
            if (user.customConfig) {
                setLocalConfig(user.customConfig);
                setIsCustomized(true);
            } else {
                loadRoleDefaults(user.role);
                setIsCustomized(false);
            }
        } else {
            // New User Default
            setFormData({
                name: '', username: '', email: '', phone: '', employmentType: 'Fulltime', role: 'USER', password: '', avatar: '', status: 'Active'
            });
            loadRoleDefaults('USER');
            setIsCustomized(false);
        }
        setErrors({});
    }, [user]);

    const loadRoleDefaults = (roleName: string) => {
        const baseConfig = roleConfigs[roleName];
        if (baseConfig) {
            setLocalConfig(JSON.parse(JSON.stringify(baseConfig)));
        }
    };

    const handleRoleChange = (newRole: string) => {
        setFormData(prev => ({ ...prev, role: newRole }));
        if (!isCustomized) {
            loadRoleDefaults(newRole);
        } else {
            if (confirm('Switching base role to ' + newRole + ' will reset all custom permissions. Continue?')) {
                loadRoleDefaults(newRole);
                setIsCustomized(false);
            }
        }
    };

    const handlePermissionChange = () => {
        if (!isCustomized) setIsCustomized(true);
    };

    const generatePassword = () => {
        const chars = "1";
        let pass = "";
        for (let i = 0; i < 5; i++) {
            pass += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        setFormData(prev => ({ ...prev, password: pass }));
        setShowPassword(true);
    };

    const togglePerm = (objKey: string, type: keyof PermissionObject) => {
        handlePermissionChange();
        setLocalConfig(prev => {
            if (!prev) return null;
            return {
                ...prev,
                objects: {
                    ...prev.objects,
                    [objKey]: { ...prev.objects[objKey], [type]: !prev.objects[objKey][type] }
                }
            };
        });
    };

    const toggleAllRow = (objKey: string, val: boolean) => {
        handlePermissionChange();
        setLocalConfig(prev => {
            if (!prev) return null;
            return {
                ...prev,
                objects: {
                    ...prev.objects,
                    [objKey]: { ...prev.objects[objKey], create: val, read: val, edit: val, delete: val, approve: val, reject: val, undo: val }
                }
            };
        });
    };

    const handleSharingChange = (objKey: string, value: string) => {
        handlePermissionChange();
        setLocalConfig(prev => {
            if (!prev) return null;
            return {
                ...prev,
                objects: {
                    ...prev.objects,
                    [objKey]: {
                        ...prev.objects[objKey],
                        sharing: value
                    }
                }
            };
        });
    };

    const handleSave = () => {
        const newErrors: Record<string, boolean> = {};
        if (!formData.name?.trim()) newErrors.name = true;
        if (!formData.username?.trim()) newErrors.username = true;
        if (!formData.email?.trim()) newErrors.email = true;
        if (!formData.phone?.trim()) newErrors.phone = true;
        
        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
            return;
        }
        
        const finalData = {
            ...formData,
            customConfig: isCustomized ? localConfig : undefined
        };
        
        onSave(finalData as UserProfile, isNew);
    };

    if (!localConfig) return null;

    return (
        <div className="fixed inset-0 z-50 bg-white dark:bg-slate-950 flex flex-col animate-in slide-in-from-right duration-300">
            {/* Top Bar */}
            <div className="h-16 px-6 border-b border-gray-100 dark:border-slate-800 flex items-center justify-between bg-white dark:bg-slate-900 shrink-0 z-20">
                <div className="flex items-center gap-4">
                    <button onClick={onClose} className="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full transition-colors text-gray-500 dark:text-gray-400">
                        <ArrowLeft size={20} />
                    </button>
                    <h1 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">
                        {isNew ? 'New Team Member' : `Edit: ${user?.name}`}
                    </h1>
                </div>
                <div className="flex items-center gap-3">
                    <button onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white transition-colors">
                        Cancel
                    </button>
                    <button 
                        onClick={handleSave} 
                        className="px-6 py-2.5 bg-blue-600 text-white text-sm font-bold rounded-lg shadow-sm hover:bg-blue-700 flex items-center gap-2 transition-all transform active:scale-95"
                    >
                        <Save size={16} /> Save Changes
                    </button>
                </div>
            </div>

            <div className="flex flex-1 overflow-hidden">
                {/* Left Sidebar: Profile & Credentials */}
                <div className="w-[400px] border-r border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-y-auto p-8 space-y-8 shrink-0">
                    
                    {/* Identity Section */}
                    <div>
                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
                                <User size={14} /> Identity
                            </h3>
                        </div>
                        
                        <div className="flex justify-center mb-8">
                            <div className="w-24 h-24 rounded-full bg-gray-100 dark:bg-slate-800 border-4 border-white dark:border-slate-700 shadow-lg flex items-center justify-center relative overflow-hidden group cursor-pointer">
                                {formData.avatar ? (
                                    <img src={formData.avatar} alt="" className="w-full h-full object-cover" />
                                ) : (
                                    <span className="text-3xl font-black text-gray-300 dark:text-gray-600">{formData.name?.charAt(0) || 'U'}</span>
                                )}
                                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <span className="text-white text-xs font-bold bg-black/50 px-2 py-1 rounded-full">Change</span>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <InputField label="Full Name" value={formData.name} onChange={(v: string) => setFormData({...formData, name: v})} error={errors.name} placeholder="e.g. John Doe" />
                            
                            <InputField label="Username" value={formData.username} onChange={(v: string) => setFormData({...formData, username: v})} error={errors.username} placeholder="johndoe" icon={(props: any) => <span {...props} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">@</span>} />
                            
                            <InputField label="Email Address" value={formData.email} onChange={(v: string) => setFormData({...formData, email: v})} error={errors.email} placeholder="john@company.com" icon={Mail} />
                            
                            <InputField label="Phone Number" value={formData.phone} onChange={(v: string) => setFormData({...formData, phone: v})} error={errors.phone} placeholder="+1 234 567 890" icon={Phone} />

                            <div className="group">
                                <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1.5 ml-1">Employment Type</label>
                                <div className="relative">
                                    <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                                    <select
                                        className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer"
                                        value={formData.employmentType || 'Fulltime'}
                                        onChange={e => setFormData({...formData, employmentType: e.target.value as any})}
                                    >
                                        <option value="Fulltime">Fulltime</option>
                                        <option value="Part-time">Part-time</option>
                                        <option value="Contract">Contract</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr className="border-gray-100 dark:border-slate-800" />

                    {/* Role Section */}
                    <div>
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
                                <BadgeCheck size={14} /> Base Role
                            </h3>
                        </div>
                        <p className="text-xs text-gray-400 dark:text-gray-500 mb-4 leading-relaxed">
                            Select a base role to apply default permissions. You can customize specific modules on the right.
                        </p>
                        <div className="space-y-3">
                            {Object.entries(roleConfigs).map(([role, config]) => {
                                const isSelected = formData.role === role;
                                const roleConfig = config as RoleConfig;
                                return (
                                <button
                                    key={role}
                                    onClick={() => handleRoleChange(role)}
                                    className={`w-full p-4 rounded-xl border-2 text-left transition-all relative overflow-hidden group ${
                                        isSelected 
                                            ? 'bg-blue-600 border-blue-600 shadow-lg shadow-blue-200 dark:shadow-none' 
                                            : 'bg-white dark:bg-slate-800 border-gray-100 dark:border-slate-700 hover:border-gray-200 dark:hover:border-slate-600'
                                    }`}
                                >
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h4 className={`text-sm font-bold ${isSelected ? 'text-white' : 'text-gray-800 dark:text-gray-200'}`}>
                                                {role}
                                            </h4>
                                            <p className={`text-[10px] mt-1 line-clamp-1 ${isSelected ? 'text-blue-100' : 'text-gray-400'}`}>
                                                {roleConfig.metadata?.description || 'Standard access role.'}
                                            </p>
                                        </div>
                                        {isSelected && (
                                            <div className="bg-white/20 p-1 rounded-full">
                                                <Check size={14} className="text-white" />
                                            </div>
                                        )}
                                    </div>
                                </button>
                            )})}
                        </div>
                    </div>

                    <hr className="border-gray-100 dark:border-slate-800" />

                    {/* Security Section */}
                    <div>
                        <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                            <KeyRound size={14} /> Credentials
                        </h3>
                        <div className="group">
                            <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1.5 ml-1">Password</label>
                            <div className="flex gap-2">
                                <div className="relative flex-1">
                                    <input 
                                        type={showPassword ? "text" : "password"}
                                        className="w-full pl-4 pr-10 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium text-gray-900 dark:text-white placeholder:text-gray-400 focus:ring-2 focus:ring-blue-500 outline-none transition-colors"
                                        value={formData.password}
                                        onChange={e => setFormData({...formData, password: e.target.value})}
                                        placeholder="Default: 11111"
                                    />
                                    <button 
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                                    >
                                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                    </button>
                                </div>
                                <button 
                                    onClick={generatePassword} 
                                    className="p-2.5 bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 rounded-xl text-gray-500 dark:text-gray-400 transition-colors"
                                    title="Generate Password"
                                >
                                    <RefreshCcw size={18} />
                                </button>
                            </div>
                        </div>
                    </div>

                </div>

                {/* Right Panel: Permissions Matrix */}
                <div className="flex-1 bg-white dark:bg-slate-900 flex flex-col min-w-0 h-full">
                    {/* Toolbar */}
                    <div className="px-8 py-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-end bg-white dark:bg-slate-900 shrink-0">
                        <div>
                            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
                                <Shield size={24} className="text-blue-600" />
                                Access Control Matrix
                            </h2>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Fine-tune module access for this user.</p>
                        </div>
                        {isCustomized && (
                            <button 
                                onClick={() => { loadRoleDefaults(formData.role || 'USER'); setIsCustomized(false); }} 
                                className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-amber-700 bg-amber-50 rounded-lg border border-amber-200 hover:bg-amber-100 transition-colors"
                            >
                                <RotateCcw size={14} /> Reset to {formData.role} Defaults
                            </button>
                        )}
                    </div>

                    {/* Scrollable Matrix */}
                    <div className="flex-1 overflow-hidden p-8 bg-gray-50 dark:bg-slate-950/30 flex flex-col">
                        <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden min-w-[1000px] flex flex-col flex-1 h-full">
                            {/* Table Header */}
                            <div className="sticky top-0 z-10 grid grid-cols-12 gap-4 px-6 py-4 bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800 text-xs font-extrabold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                <div className="col-span-3">Module</div>
                                <div className="col-span-1 text-center">Full</div>
                                <div className="col-span-6 grid grid-cols-7 gap-2 text-center">
                                    <div title="Read Access">Read</div>
                                    <div title="Create Access">Create</div>
                                    <div title="Edit Access">Edit</div>
                                    <div title="Delete Access" className="text-red-500">Delete</div>
                                    <div title="Approve Access" className="text-emerald-600">Approve</div>
                                    <div title="Reject Access" className="text-rose-500">Reject</div>
                                    <div title="Undo Access" className="text-amber-600">Undo</div>
                                </div>
                                <div className="col-span-2 text-right px-1">Data Scope</div>
                            </div>

                            {/* Table Body */}
                            <div className="divide-y divide-gray-100 dark:divide-slate-800 flex-1 overflow-auto">
                                <table className="w-full">
                                    <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                                        {APP_MODULES.map(mod => (
                                            <React.Fragment key={mod.key}>
                                                <PermissionRow 
                                                    itemKey={mod.key} 
                                                    label={mod.label} 
                                                    localConfig={localConfig}
                                                    togglePerm={togglePerm}
                                                    toggleAllRow={toggleAllRow}
                                                    handleSharingChange={handleSharingChange}
                                                />
                                                {mod.children?.map(child => (
                                                    <PermissionRow 
                                                        key={child.key} 
                                                        itemKey={child.key}
                                                        label={child.label}
                                                        isChild={true}
                                                        localConfig={localConfig}
                                                        togglePerm={togglePerm}
                                                        toggleAllRow={toggleAllRow}
                                                        handleSharingChange={handleSharingChange}
                                                    />
                                                ))}
                                            </React.Fragment>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UserAccessConfig;

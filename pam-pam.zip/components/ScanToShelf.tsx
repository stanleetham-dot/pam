import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useInventory } from '../context/InventoryContext';
import { Scan, ArrowRight, CheckCircle2, X, Box, Keyboard, Layers, Trash2, User, MapPin, Package, AlertOctagon, Volume2, VolumeX, AlertTriangle, Volume1, Activity } from 'lucide-react';
import { Product } from '../types';
import Scanner from './Scanner';

interface ScanToShelfProps {
  onClose?: () => void;
}

interface BatchSummary {
  count: number;
  location: string;
  timestamp: string;
  operator: string;
}

const ScanToShelf: React.FC<ScanToShelfProps> = ({ onClose }) => {
  const { searchProduct, moveProduct, currentUser, language } = useInventory();
  
  const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

  // Steps: 0 = Scan Product, 1 = Scan Location
  const [step, setStep] = useState<0 | 1>(0);
  
  // Modes & Settings
  const [isBatchMode, setIsBatchMode] = useState(false);
  const [volume, setVolume] = useState(0.5); // 0 to 1
  const [isMuted, setIsMuted] = useState(false);
  
  // Data State
  const [batchProducts, setBatchProducts] = useState<Product[]>([]);
  const [batchSummary, setBatchSummary] = useState<BatchSummary | null>(null);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  
  // UI State
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'warning' | 'batch', msg: string, detail?: string, imageUrl?: string } | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false); // Location Camera
  const [isScanningProduct, setIsScanningProduct] = useState(false); // Product Camera
  
  // Input References for Hardware Scanners
  const hiddenInputRef = useRef<HTMLInputElement>(null);
  const manualInputRef = useRef<HTMLInputElement>(null); // Visible input
  const [manualInputValue, setManualInputValue] = useState('');

  // Audio Context
  const audioContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // ... (Audio Init logic same)
  useEffect(() => {
      const initAudio = () => {
          if (!audioContextRef.current) {
              const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
              if (AudioContext) {
                  const ctx = new AudioContext();
                  const gainNode = ctx.createGain();
                  gainNode.connect(ctx.destination);
                  audioContextRef.current = ctx;
                  gainNodeRef.current = gainNode;
              }
          }
          if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
              audioContextRef.current.resume().catch(e => console.warn("Audio resume failed", e));
          }
      };
      window.addEventListener('click', initAudio);
      window.addEventListener('keydown', initAudio);
      window.addEventListener('touchstart', initAudio);
      return () => {
          window.removeEventListener('click', initAudio);
          window.removeEventListener('keydown', initAudio);
          window.removeEventListener('touchstart', initAudio);
          if (audioContextRef.current) {
              audioContextRef.current.close();
          }
      };
  }, []);

  const playSound = (type: 'success' | 'error' | 'warning' | 'batch') => {
    if (isMuted) return;
    try {
        if (!audioContextRef.current || !gainNodeRef.current) return;
        const ctx = audioContextRef.current;
        const mainGain = gainNodeRef.current;
        if (ctx.state === 'suspended') ctx.resume();
        mainGain.gain.setValueAtTime(volume, ctx.currentTime);
        const now = ctx.currentTime;

        if (type === 'success' || type === 'batch') {
            const frequencies = type === 'batch' ? [880, 1108.73, 1318.51] : [1046.50, 1318.51, 1567.98, 2093.00];
            frequencies.forEach((freq, i) => {
                const osc = ctx.createOscillator();
                const noteGain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.value = freq;
                osc.connect(noteGain);
                noteGain.connect(mainGain);
                const startTime = now + (i * 0.06); 
                const duration = 0.5; 
                noteGain.gain.setValueAtTime(0.5, startTime);
                noteGain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
                osc.start(startTime);
                osc.stop(startTime + duration);
            });
        } else {
            const osc1 = ctx.createOscillator();
            const noteGain1 = ctx.createGain();
            osc1.type = 'triangle'; 
            osc1.frequency.setValueAtTime(800, now);
            osc1.frequency.exponentialRampToValueAtTime(750, now + 0.1); 
            osc1.connect(noteGain1);
            noteGain1.connect(mainGain);
            noteGain1.gain.setValueAtTime(0.5, now);
            noteGain1.gain.linearRampToValueAtTime(0, now + 0.15);
            osc1.start(now);
            osc1.stop(now + 0.15);

            const osc2 = ctx.createOscillator();
            const noteGain2 = ctx.createGain();
            osc2.type = 'triangle';
            osc2.frequency.setValueAtTime(600, now + 0.25); 
            osc2.frequency.exponentialRampToValueAtTime(300, now + 0.55); 
            osc2.connect(noteGain2);
            noteGain2.connect(mainGain);
            noteGain2.gain.setValueAtTime(0, now + 0.25);
            noteGain2.gain.linearRampToValueAtTime(0.5, now + 0.26); 
            noteGain2.gain.linearRampToValueAtTime(0, now + 0.6); 
            osc2.start(now + 0.25);
            osc2.stop(now + 0.6);
        }
    } catch (e) {
        console.error("Audio play failed", e);
    }
  };

  const triggerFeedback = (type: 'success' | 'error' | 'warning' | 'batch', title: string, subtitle?: string) => {
      setFeedback({ type, msg: title, detail: subtitle });
      playSound(type);
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
          switch(type) {
              case 'success': navigator.vibrate(70); break;
              case 'batch': navigator.vibrate([40, 40, 40]); break;
              case 'warning': navigator.vibrate([100, 50, 100]); break;
              case 'error': navigator.vibrate([200, 100, 100, 50, 100]); break;
          }
      }
      setTimeout(() => setFeedback(null), 2000);
  };

  // ... (Focus logic same)
  useEffect(() => {
    const ensureScannerFocus = () => {
        if (document.activeElement === manualInputRef.current) return;
        const active = document.activeElement;
        const isInteractive = active && (active.tagName === 'BUTTON' || active.tagName === 'A' || active.tagName === 'SELECT' || active.tagName === 'TEXTAREA' || (active.tagName === 'INPUT' && active !== hiddenInputRef.current));
        if (!isInteractive && hiddenInputRef.current) {
            if (document.activeElement !== hiddenInputRef.current) {
                hiddenInputRef.current.focus({ preventScroll: true });
            }
        }
    };
    ensureScannerFocus();
    const handleWindowFocus = () => ensureScannerFocus();
    const handleDocumentClick = (e: MouseEvent) => {
        const target = e.target as HTMLElement;
        const isInteractive = target.closest('button, a, input, select, textarea, [role="button"]');
        if (!isInteractive) {
            setTimeout(ensureScannerFocus, 50);
        }
    };
    window.addEventListener('focus', handleWindowFocus);
    document.addEventListener('click', handleDocumentClick);
    const intervalId = setInterval(ensureScannerFocus, 1500);
    return () => {
        window.removeEventListener('focus', handleWindowFocus);
        document.removeEventListener('click', handleDocumentClick);
        clearInterval(intervalId);
    };
  }, []);

  const validateLocation = (loc: string): boolean => {
      const regex = /^[A-Za-z][A-Za-z0-9\-]*B$/;
      return regex.test(loc.trim());
  };

  const processScan = (scannedValue: string) => {
    if (!scannedValue) return;
    const cleanValue = scannedValue.trim();

    if (batchSummary) setBatchSummary(null);

    if (step === 0) {
      let product = searchProduct(cleanValue);
      
      if (product) {
        if (isBatchMode) {
            if (batchProducts.some(p => p.id === product?.id)) {
                 triggerFeedback('warning', t('Duplicate', '重复'), t('Item already in batch', '商品已在批次中'));
            } else {
                 setBatchProducts(prev => [...prev, product!]);
                 triggerFeedback('batch', t('Added to Batch', '已加入批次'), product.name);
            }
        } else {
            setActiveProduct(product);
            setStep(1); 
            triggerFeedback('success', t('Product Found', '找到商品'), product.name);
        }
      } else {
        if (validateLocation(cleanValue)) {
            triggerFeedback('error', t('Wrong Step', '步骤错误'), t('You scanned a location. Please scan a product first.', '您扫描了库位，请先扫描商品。'));
        } else {
            triggerFeedback('error', t('Product Not Found', '未找到商品'), `${t('Barcode', '条码')} "${cleanValue}" ${t('is not in the system.', '不在系统中。')}`);
        }
      }
    } 
    else if (step === 1) {
      const locationCode = cleanValue.toUpperCase();
      
      if (!validateLocation(locationCode)) {
          const product = searchProduct(cleanValue);
          if (product) {
              if (isBatchMode) {
                   triggerFeedback('error', t('Invalid Location', '无效库位'), t('Scan a shelf label to finish batch.', '请扫描货架标签以完成批次。'));
              } else {
                   setActiveProduct(product);
                   triggerFeedback('warning', t('Product Switched', '商品已切换'), `${t('Switched to', '切换至')} ${product.name}`);
              }
              return;
          }
          triggerFeedback('error', t('Invalid Format', '格式无效'), t("Location must start with letter and end with 'B'", "库位必须以字母开头并以 'B' 结尾"));
          return;
      }

      if (isBatchMode) {
          let movedCount = 0;
          batchProducts.forEach(prod => {
             const res = moveProduct(prod.barcode, locationCode);
             if (res.success) movedCount++;
          });

          if (movedCount > 0) {
              setBatchSummary({
                  count: movedCount,
                  location: locationCode,
                  timestamp: new Date().toLocaleString('en-GB'),
                  operator: currentUser?.name || 'Unknown'
              });
              setBatchProducts([]);
              setStep(0);
              triggerFeedback('success', t('Batch Complete', '批次完成'), `${movedCount} ${t('items moved', '件商品已移动')}`);
          } else {
               triggerFeedback('error', t('Batch Failed', '批次失败'), t('Could not move items', '无法移动商品'));
          }
      } else if (activeProduct) {
        const result = moveProduct(activeProduct.barcode, locationCode);
        if (result.success) {
          triggerFeedback('success', t('Transferred', '已移库'), `${activeProduct.sku} → ${locationCode}`);
          setStep(0);
          setActiveProduct(null);
        } else {
          triggerFeedback('error', t('Transfer Failed', '移库失败'), result.message);
        }
      }
    }
  };

  const handleHiddenInputSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (hiddenInputRef.current && hiddenInputRef.current.value) {
          processScan(hiddenInputRef.current.value);
          hiddenInputRef.current.value = '';
      }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (manualInputValue.trim()) {
          processScan(manualInputValue);
          setManualInputValue('');
      }
      if (hiddenInputRef.current) {
          hiddenInputRef.current.focus({ preventScroll: true });
      }
  };

  const toggleBatchMode = () => {
      if (batchProducts.length > 0 && !confirm(t("Switching modes will clear your current batch. Continue?", "切换模式将清空当前批次。继续吗？"))) return;
      setIsBatchMode(!isBatchMode);
      setBatchProducts([]);
      setStep(0);
      setActiveProduct(null);
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 relative transition-colors duration-300">
      
      <form onSubmit={handleHiddenInputSubmit} className="absolute opacity-0 top-0 left-0 w-0 h-0 overflow-hidden">
          <input 
             ref={hiddenInputRef}
             autoComplete="off"
             autoFocus
             onBlur={(e) => {
                 setTimeout(() => {
                     if (document.activeElement === document.body) {
                         e.target.focus({ preventScroll: true });
                     }
                 }, 10);
             }}
          />
      </form>

      <div className={`fixed inset-0 z-50 flex items-center justify-center pointer-events-none transition-opacity duration-300 ${feedback ? 'opacity-100' : 'opacity-0'}`}>
          {feedback && (
              <div className={`bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-4 p-8 rounded-3xl shadow-2xl flex flex-col items-center transform transition-all duration-300 max-w-sm w-full mx-4 text-center scale-100 transition-colors
                ${feedback.type === 'success' || feedback.type === 'batch' ? 'border-green-500 text-green-800 dark:text-green-300' : 
                  feedback.type === 'warning' ? 'border-yellow-500 text-yellow-800 dark:text-yellow-300' :
                  'border-red-500 text-red-800 dark:text-red-300'}`}>
                  {feedback.type === 'success' || feedback.type === 'batch' ? <CheckCircle2 size={80} className="text-green-500 mb-4 animate-bounce" /> : 
                   feedback.type === 'warning' ? <AlertTriangle size={80} className="text-yellow-500 mb-4 animate-pulse" /> :
                   <AlertOctagon size={80} className="text-red-500 mb-4 animate-pulse" />}
                  <h2 className="text-3xl font-black">{feedback.msg}</h2>
                  {feedback.detail && <p className="text-lg font-medium mt-2 opacity-80">{feedback.detail}</p>}
              </div>
          )}
      </div>

      {(isScanningProduct || isCameraOpen) && (
        <Scanner 
            onScan={(code) => { processScan(code); setIsScanningProduct(false); setIsCameraOpen(false); }} 
            onClose={() => { setIsScanningProduct(false); setIsCameraOpen(false); }} 
            title={isScanningProduct ? t("Scan Barcode / QR", "扫描条码 / 二维码") : t("Scan Location / QR", "扫描库位 / 二维码")}
            type={isScanningProduct ? "product" : "location"}
        />
      )}

      <div className="bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-slate-800 px-6 py-4 flex flex-col md:flex-row justify-between items-center shrink-0 gap-4 transition-colors">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
            <Scan className="text-blue-600 dark:text-blue-400" />
            {t('Fast Scan', '快速扫描')}
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-xs font-bold mt-0.5 uppercase tracking-wide">
            {isBatchMode ? t("Batch Mode Active", "批量模式已激活") : t("Single Item Mode", "单件模式")}
          </p>
        </div>
        <div className="flex items-center gap-4">
             <div className="flex items-center gap-2 bg-gray-100 dark:bg-slate-800 rounded-lg p-1.5 px-3 transition-colors">
                 <button onClick={() => setIsMuted(!isMuted)} className="text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200">
                     {isMuted ? <VolumeX size={18} /> : volume > 0.5 ? <Volume2 size={18} /> : <Volume1 size={18} />}
                 </button>
                 <input 
                    type="range" 
                    min="0" max="1" step="0.1" 
                    value={volume}
                    onChange={e => { setVolume(parseFloat(e.target.value)); setIsMuted(false); }}
                    className="w-20 h-1 bg-gray-300 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer"
                 />
             </div>

             <div className="h-6 w-px bg-gray-300 dark:bg-slate-700"></div>

             <button 
                 onClick={toggleBatchMode}
                 className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-bold transition-all ${
                     isBatchMode 
                     ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 border border-orange-200 dark:border-orange-900/50' 
                     : 'bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-slate-700 border border-transparent'
                 }`}
             >
                 <Layers size={16} />
                 {isBatchMode ? t("Batch On", "批量开") : t("Batch Off", "批量关")}
             </button>

             {onClose && (
                <button onClick={onClose} className="p-2 bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 rounded-lg text-gray-500 dark:text-gray-400 transition-colors">
                    <X size={20} />
                </button>
            )}
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 flex flex-col p-6 md:p-8 overflow-y-auto items-center justify-center">
            
            <div className="w-full max-w-md">
                 
                 {!isBatchMode && activeProduct && step === 1 && (
                     <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-lg border border-gray-100 dark:border-slate-800 mb-8 w-full animate-in slide-in-from-top-4 flex items-center gap-4 relative overflow-hidden transition-colors">
                         <div className="w-20 h-20 bg-gray-50 dark:bg-slate-800 rounded-xl flex items-center justify-center shrink-0 overflow-hidden border border-gray-100 dark:border-slate-700">
                             {activeProduct.imageUrl ? <img src={activeProduct.imageUrl} className="w-full h-full object-cover"/> : <Package size={32} className="text-gray-300 dark:text-slate-600"/>}
                         </div>
                         <div className="flex-1 min-w-0 pr-8">
                             <div className="flex items-center gap-2 mb-1">
                                <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wide">{t('Moving', '移动中')}</span>
                             </div>
                             <h3 className="font-bold text-lg text-gray-900 dark:text-white truncate leading-tight">{activeProduct.name}</h3>
                             <p className="text-sm text-gray-500 dark:text-gray-400 font-mono mt-0.5">{activeProduct.sku}</p>
                             <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 mt-2 bg-gray-100 dark:bg-slate-800 w-fit px-2 py-1 rounded-md">
                                <MapPin size={12} /> <span className="font-semibold">{t('From:', '从:')}</span> {activeProduct.location}
                             </div>
                         </div>
                         <button 
                            onClick={() => { setActiveProduct(null); setStep(0); }}
                            className="absolute top-2 right-2 p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                            title={t("Cancel Move", "取消移动")}
                         >
                             <X size={18} />
                         </button>
                     </div>
                 )}

                 <div className="relative mb-8 group mx-auto w-fit">
                     <button 
                        onClick={() => {
                            if (step === 0) setIsScanningProduct(true);
                            else setIsCameraOpen(true);
                        }}
                        className={`w-48 h-48 rounded-[2rem] flex flex-col items-center justify-center border-4 shadow-2xl transition-all duration-300 hover:scale-105 active:scale-95 ${
                             step === 1 
                             ? 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-900/50 text-purple-600 dark:text-purple-400 shadow-purple-100 dark:shadow-none' 
                             : 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-900/50 text-blue-600 dark:text-blue-400 shadow-blue-100 dark:shadow-none'
                        }`}
                     >
                         {step === 0 ? <Package size={64} className="mb-4" /> : <MapPin size={64} className="mb-4" />}
                         <span className="text-lg font-black uppercase tracking-wider">{step === 0 ? t("Scan Item", "扫描商品") : t("Scan Shelf", "扫描货架")}</span>
                     </button>
                     
                     <div className="absolute -bottom-4 -right-4 bg-gray-900 dark:bg-slate-800 text-white p-3 rounded-full shadow-lg border-4 border-white dark:border-slate-900 pointer-events-none transition-colors">
                         <Scan size={24} />
                     </div>
                 </div>

                 <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-3 text-center">
                     {step === 0 ? t("Scan Product", "扫描商品") : t("Scan Location", "扫描库位")}
                 </h2>
                 <p className="text-gray-400 dark:text-gray-500 text-lg mb-8 text-center mx-auto max-w-xs leading-relaxed">
                     {step === 0 
                        ? (isBatchMode ? t("Scan items/QR codes to build a batch", "扫描商品/二维码建立批次") : t("Scan item or QR code to move", "扫描商品/二维码以移动")) 
                        : (isBatchMode ? `${t('Move', '移动')} ${batchProducts.length} ${t('items to location', '件商品至库位')}` : (activeProduct ? t("Scan destination shelf label", "扫描目标货架标签") : t("Scan shelf label", "扫描货架标签")))
                     }
                 </p>

                 <form onSubmit={handleManualSubmit} className="w-full mb-4">
                     <div className="flex gap-2">
                         <input 
                            ref={manualInputRef}
                            value={manualInputValue}
                            onChange={e => setManualInputValue(e.target.value)}
                            className="flex-1 px-4 py-4 border-2 border-gray-300 dark:border-slate-700 rounded-xl focus:outline-none focus:border-blue-500 dark:focus:border-blue-400 text-lg font-mono shadow-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-600 transition-colors"
                            placeholder={step === 0 ? t("Enter Barcode...", "输入条码...") : t("Loc (e.g., A1-02B)...", "库位 (如 A1-02B)...")}
                         />
                         <button type="submit" className="bg-blue-600 text-white px-6 rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-none transition-all active:scale-95">OK</button>
                     </div>
                 </form>
            </div>
        </div>

        {isBatchMode && (
            <div className="w-96 bg-gray-50 dark:bg-slate-900 border-l border-gray-200 dark:border-slate-800 flex flex-col overflow-hidden transition-colors">
                <div className="flex-1 flex flex-col overflow-hidden bg-white dark:bg-slate-900 transition-colors">
                        <div className="p-4 border-b border-orange-100 dark:border-orange-900/30 bg-orange-50/50 dark:bg-orange-900/10 flex justify-between items-center shrink-0 transition-colors">
                            <h4 className="font-bold text-orange-900 dark:text-orange-400 flex items-center gap-2">
                                <Layers size={18} /> {t('Batch Items', '批次商品')}
                            </h4>
                            <span className="bg-white dark:bg-slate-800 text-orange-700 dark:text-orange-400 text-xs px-2 py-1 rounded-full border border-orange-200 dark:border-orange-900/50 font-mono font-bold shadow-sm">
                                {batchProducts.length}
                            </span>
                        </div>
                        <div className="flex-1 overflow-y-auto p-2 space-y-2 no-scrollbar">
                            {batchProducts.length > 0 ? (
                                batchProducts.map((p, idx) => (
                                    <div key={`${p.id}-${idx}`} className="flex items-center gap-3 p-3 bg-white dark:bg-slate-800 border border-gray-100 dark:border-slate-700 rounded-xl shadow-sm animate-in slide-in-from-right-2 transition-colors">
                                        <div className="min-w-0 flex-1">
                                            <p className="text-sm font-bold text-gray-800 dark:text-gray-200 truncate">{p.name}</p>
                                            <p className="text-xs text-gray-500 dark:text-gray-500 font-mono">{p.sku}</p>
                                        </div>
                                        <button onClick={() => setBatchProducts(batchProducts.filter(bp => bp.id !== p.id))} className="text-gray-300 dark:text-slate-600 hover:text-red-500 dark:hover:text-red-400 p-2 transition-colors"><Trash2 size={14}/></button>
                                    </div>
                                ))
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-gray-300 dark:text-slate-700 p-6 text-center">
                                    <Layers size={48} className="mb-2 opacity-20" />
                                    <p className="text-sm font-medium">{t('Scan items to build a batch list', '扫描商品建立批次列表')}</p>
                                </div>
                            )}
                        </div>
                        {batchProducts.length > 0 && step === 0 && (
                            <div className="p-4 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-950 transition-colors">
                                <button onClick={() => setStep(1)} className="w-full py-3 bg-orange-600 text-white font-bold rounded-xl hover:bg-orange-700 shadow-md shadow-orange-200 dark:shadow-none flex items-center justify-center gap-2 active:scale-95 transition-all">
                                    {t('Move All Items', '移动所有商品')} <ArrowRight size={18} />
                                </button>
                            </div>
                        )}
                    </div>
            </div>
        )}
      </div>

      <div className="bg-white dark:bg-slate-900 border-t border-gray-100 dark:border-slate-800 py-2.5 px-6 flex justify-between items-center shrink-0 shadow-[0_-4px_10px_rgba(0,0,0,0.02)] transition-colors">
          <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                  </span>
                  <span className="text-[10px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-[0.2em]">{t('Ready for Hardware Scanner', '硬件扫描枪就绪')}</span>
              </div>
              <div className="h-3 w-px bg-gray-200 dark:bg-slate-800"></div>
              <div className="flex items-center gap-2 text-gray-400 dark:text-gray-600">
                  <Activity size={10} className="animate-pulse" />
                  <span className="text-[10px] font-bold uppercase tracking-widest italic">{t('HID Mode', 'HID 模式')}</span>
              </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-gray-300 dark:text-slate-700">
              <Keyboard size={12} />
              <span className="text-[9px] font-bold uppercase tracking-widest">{t('Global Focus Active', '全局焦点激活')}</span>
          </div>
      </div>
    </div>
  );
};

export default ScanToShelf;

import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { USER_ROLES } from '../constants';
import { X, Save, Eye, EyeOff, RefreshCcw, User, Mail, Phone, Lock, Edit2, Shield, Check, Truck } from 'lucide-react';

interface UserFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (user: Partial<UserProfile>, isNew: boolean) => void;
  user: UserProfile | null;
}

const UserFormModal: React.FC<UserFormModalProps> = ({ isOpen, onClose, onSubmit, user }) => {
  const isNew = !user;
  const [formData, setFormData] = useState<Partial<UserProfile>>({
    name: '',
    username: '',
    email: '',
    phone: '',
    plateNumber: '',
    role: 'USER',
    password: '',
    avatar: ''
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
      if (user) {
        setFormData({ ...user, password: user.password || '' });
      } else {
        setFormData({
          name: '',
          username: '',
          email: '',
          phone: '',
          plateNumber: '',
          role: 'USER',
          password: '',
          avatar: ''
        });
      }
      setErrors({});
      setShowPassword(false);
    }
  }, [isOpen, user]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name?.trim()) newErrors.name = 'Full Name is required';
    if (!formData.username?.trim()) newErrors.username = 'Username is required';
    else if (/\s/.test(formData.username)) newErrors.username = 'Username cannot contain spaces';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(formData, isNew);
    }
  };

  const generatePassword = () => {
    const chars = "1";
    let pass = "";
    for (let i = 0; i < 5; i++) {
        pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setFormData({ ...formData, password: pass });
    setShowPassword(true);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-lg shadow-2xl flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200 transition-colors">
        
        {/* Header */}
        <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950 rounded-t-2xl transition-colors">
          <div>
            <h3 className="text-xl font-bold text-gray-800 dark:text-white">{isNew ? 'Invite New User' : 'Edit Profile'}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{isNew ? 'Create a new account for your team.' : 'Update user details and permissions.'}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full text-gray-500 transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8 no-scrollbar">
          
          {/* Section: Identity */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3">Identity</h4>
            
            <div className="flex gap-6 items-start">
                <div className="group relative w-20 h-20 rounded-2xl bg-gray-100 dark:bg-slate-800 border-2 border-dashed border-gray-300 dark:border-slate-700 flex items-center justify-center overflow-hidden shrink-0 hover:border-blue-400 dark:hover:border-blue-500 transition-colors cursor-pointer">
                    {formData.avatar ? (
                        <img src={formData.avatar} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                        <User size={32} className="text-gray-300 dark:text-gray-600 group-hover:text-blue-400 transition-colors" />
                    )}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Edit2 size={20} className="text-white" />
                    </div>
                </div>
                
                <div className="flex-1 space-y-4">
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Full Name <span className="text-red-500">*</span></label>
                        <input 
                            className={`w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all ${errors.name ? 'border-red-300 bg-red-50 dark:bg-red-900/10' : 'border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 text-gray-900 dark:text-white focus:bg-white dark:focus:bg-slate-700'}`}
                            value={formData.name}
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            placeholder="e.g. Alex Johnson"
                        />
                        {errors.name && <p className="text-xs text-red-500 dark:text-red-400 mt-1 ml-1">{errors.name}</p>}
                    </div>
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Username <span className="text-red-500">*</span></label>
                        <input 
                            className={`w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono text-sm ${errors.username ? 'border-red-300 bg-red-50 dark:bg-red-900/10' : 'border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 text-gray-900 dark:text-white focus:bg-white dark:focus:bg-slate-700'}`}
                            value={formData.username}
                            onChange={e => setFormData({...formData, username: e.target.value.toLowerCase().replace(/\s/g, '')})}
                            placeholder="alexj"
                        />
                        {errors.username && <p className="text-xs text-red-500 dark:text-red-400 mt-1 ml-1">{errors.username}</p>}
                    </div>
                </div>
            </div>
          </div>

          {/* Section: Contact */}
          <div className="space-y-4">
             <h4 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3">Contact Info</h4>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Email Address</label>
                    <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={16} />
                        <input 
                            type="email"
                            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-700 text-gray-900 dark:text-white rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                            value={formData.email}
                            onChange={e => setFormData({...formData, email: e.target.value})}
                            placeholder="name@nexus.com"
                        />
                    </div>
                </div>
                <div>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Phone Number</label>
                    <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={16} />
                        <input 
                            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-700 text-gray-900 dark:text-white rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                            value={formData.phone}
                            onChange={e => setFormData({...formData, phone: e.target.value})}
                            placeholder="+1 234 567 890"
                        />
                    </div>
                </div>
                {/* Vehicle Plate Input - Only for Drivers */}
                {formData.role === 'DRIVER' && (
                    <div className="md:col-span-2">
                        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Vehicle Plate Number</label>
                        <div className="relative">
                            <Truck className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={16} />
                            <input 
                                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-700 text-gray-900 dark:text-white rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all uppercase font-mono"
                                value={formData.plateNumber}
                                onChange={e => setFormData({...formData, plateNumber: e.target.value.toUpperCase()})}
                                placeholder="SMA 1234 X"
                            />
                        </div>
                    </div>
                )}
             </div>
          </div>

          {/* Section: Access & Security */}
          <div className="space-y-4">
             <h4 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3">Access Control</h4>
             
             <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Role Assignment</label>
                <div className="grid grid-cols-3 gap-3">
                    {USER_ROLES.map(role => (
                        <div 
                            key={role}
                            onClick={() => setFormData({...formData, role: role})}
                            className={`cursor-pointer rounded-xl border-2 p-3 flex flex-col items-center justify-center gap-2 transition-all ${
                                formData.role === role 
                                    ? (role === 'ADMIN' ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400' : role === 'INSPECTOR' ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-400' : 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400')
                                    : 'border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-gray-300 dark:hover:border-slate-600 text-gray-500 dark:text-gray-400'
                            }`}
                        >
                            <Shield size={18} className={formData.role === role ? 'fill-current' : ''} />
                            <span className="text-xs font-bold">{role}</span>
                        </div>
                    ))}
                </div>
             </div>

             <div className="pt-2">
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Password</label>
                <div className="flex gap-2">
                    <div className="relative flex-1">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={16} />
                        <input 
                            type={showPassword ? "text" : "password"}
                            className="w-full pl-10 pr-10 py-2.5 border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-700 text-gray-900 dark:text-white rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono text-sm"
                            value={formData.password}
                            onChange={e => setFormData({...formData, password: e.target.value})}
                            placeholder={isNew ? "Default: 11111" : "Enter password"}
                        />
                        <button 
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
                        >
                            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                    </div>
                    <button 
                        type="button"
                        onClick={generatePassword}
                        className="px-3 py-2.5 bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400 rounded-xl hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors"
                        title="Reset Password"
                    >
                        <RefreshCcw size={18} />
                    </button>
                </div>
                {isNew && !formData.password && (
                    <p className="text-xs text-amber-600 dark:text-amber-400 mt-2 flex items-center gap-1">
                       <Check size={12} /> Default password <strong>11111</strong> will be used if left blank.
                    </p>
                )}
             </div>
          </div>

        </form>

        {/* Footer */}
        <div className="p-6 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-950 rounded-b-2xl flex justify-end gap-3 transition-colors">
            <button 
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 text-gray-700 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-xl font-bold transition-colors"
            >
                Cancel
            </button>
            <button 
                onClick={handleSubmit}
                className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-none flex items-center gap-2 transition-transform active:scale-95"
            >
                <Save size={18} /> Save Changes
            </button>
        </div>

      </div>
    </div>
  );
};

export default UserFormModal;

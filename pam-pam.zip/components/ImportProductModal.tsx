
import React, { useState, useRef, useEffect } from 'react';
import { 
    X, FileSpreadsheet, Download, Upload, CheckCircle2, 
    AlertCircle, Loader2, Cloud 
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Product } from '../types';

interface ImportProductModalProps { 
    isOpen: boolean; 
    onClose: () => void; 
    onImport: (products: Product[], mode: 'MERGE' | 'REPLACE') => Promise<void> | void;
}

const ImportProductModal: React.FC<ImportProductModalProps> = ({ isOpen, onClose, onImport }) => {
    const [file, setFile] = useState<File | null>(null);
    const [previewCount, setPreviewCount] = useState<number>(0);
    const [isProcessing, setIsProcessing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [importMode, setImportMode] = useState<'MERGE' | 'REPLACE'>('MERGE');
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (!isOpen) {
            setFile(null);
            setPreviewCount(0);
            setError(null);
            setImportMode('MERGE');
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const handleDownloadTemplate = () => {
        const headers = [
            'Product barcode', 'Product code', 'Product name', 'Storage Location', 
            'Product category', 'Spec', 'Basic unit', 'Standard price', 
            'Wholesale price', 'Purchase price', 'Origin', 'Product brand'
        ];
        
        const sampleData = [
            ['880123456789', 'SKU-SAMPLE-01', 'Sample Product', 'A1-01B', 'Electronics', 'Black/Wireless', 'PCS', 19.99, 15.00, 10.00, 'China', 'Generic']
        ];

        const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleData]);
        ws['!cols'] = headers.map(() => ({ wch: 20 }));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Product Template");
        XLSX.writeFile(wb, "Inventory_Import_Template.xlsx");
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (!selectedFile) return;

        setFile(selectedFile);
        setIsProcessing(true);
        setError(null);

        const reader = new FileReader();
        reader.onload = (evt) => {
            try {
                const bstr = evt.target?.result;
                const wb = XLSX.read(bstr, { type: 'binary' });
                const wsname = wb.SheetNames[0];
                const ws = wb.Sheets[wsname];
                const data = XLSX.utils.sheet_to_json(ws, { header: 1 });
                if (data.length <= 1) {
                    setError("The file appears to be empty.");
                    setPreviewCount(0);
                } else {
                    setPreviewCount(data.length - 1);
                }
            } catch (err) {
                console.error(err);
                setError("Failed to parse file. Please ensure it is a valid XLSX.");
            } finally {
                setIsProcessing(false);
            }
        };
        reader.readAsBinaryString(selectedFile);
    };

    const processImport = () => {
        if (!file) return;
        setIsProcessing(true);

        const reader = new FileReader();
        reader.onload = async (evt) => {
            try {
                const bstr = evt.target?.result;
                const wb = XLSX.read(bstr, { type: 'binary' });
                const wsname = wb.SheetNames[0];
                const ws = wb.Sheets[wsname];
                const data = XLSX.utils.sheet_to_json<any>(ws);

                const mappedProducts: Product[] = data.map((row: any): Partial<Product> => ({
                    barcode: String(row['Product barcode'] || ''),
                    sku: String(row['Product code'] || ''),
                    name: String(row['Product name'] || ''),
                    location: String(row['Storage Location'] || ''),
                    category: String(row['Product category'] || 'General'),
                    specification: String(row['Spec'] || ''),
                    unit: String(row['Basic unit'] || 'PCS'),
                    standardPrice: Number(row['Standard price']) || 0,
                    wholesalePrice: Number(row['Wholesale price']) || 0,
                    purchasePrice: Number(row['Purchase price']) || 0,
                    wholesalePrice2: 0,
                    origin: String(row['Origin'] || ''),
                    brand: String(row['Product brand'] || ''),
                    warehouse: String(row['Warehouse'] || ''),
                    stock: Number(row['Quantity']) || 0,
                    status: Number(row['Quantity']) > 0 ? 'In Stock' : 'Out of Stock',
                    expiryDate: 'N/A',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                })).filter(p => p.barcode && p.name) as Product[]; 

                if (mappedProducts.length === 0) {
                    setError("No valid products found. Check column headers.");
                    setIsProcessing(false);
                    return;
                }

                await onImport(mappedProducts, importMode);
                
            } catch (err) {
                console.error(err);
                setError("Error processing data.");
            } finally {
                setIsProcessing(false);
            }
        };
        reader.readAsBinaryString(file);
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl shadow-2xl flex flex-col overflow-hidden transition-colors">
                <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-900/50">
                    <div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                            <Cloud className="text-blue-600 dark:text-blue-500" /> Batch Import Inventory
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Add new inventory records from Excel file.</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full text-gray-500 dark:text-gray-400 transition-colors">
                        <X size={20} />
                    </button>
                </div>

                <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex flex-col">
                        <div className="flex items-center gap-2 mb-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-sm">1</div>
                            <h4 className="font-bold text-gray-900 dark:text-white">Download Template</h4>
                        </div>
                        <div className="flex-1 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-xl p-6 flex flex-col items-center justify-center text-center">
                            <FileSpreadsheet size={48} className="text-blue-200 dark:text-blue-900 mb-4" />
                            <p className="text-sm text-blue-900 dark:text-blue-100 font-medium mb-2">Get the formatted Excel file</p>
                            <button onClick={handleDownloadTemplate} className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-bold text-sm rounded-lg shadow-sm border border-blue-200 dark:border-slate-700 hover:bg-blue-50 dark:hover:bg-slate-700 transition-colors">
                                <Download size={16} /> Download .XLSX
                            </button>
                        </div>
                    </div>
                    <div className="flex flex-col">
                        <div className="flex items-center gap-2 mb-4">
                            <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 flex items-center justify-center font-bold text-sm">2</div>
                            <h4 className="font-bold text-gray-900 dark:text-white">Upload Data File</h4>
                        </div>
                        <div onClick={() => fileInputRef.current?.click()} className={`flex-1 border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${file ? 'border-green-500 bg-green-50 dark:bg-green-900/10' : 'border-gray-300 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-700 hover:bg-gray-50 dark:hover:bg-slate-800/50'}`}>
                            {file ? (
                                <>
                                    <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 mb-3"><CheckCircle2 size={24} /></div>
                                    <p className="font-bold text-gray-800 dark:text-gray-200 text-sm truncate max-w-full px-2">{file.name}</p>
                                    <p className="text-xs text-green-700 dark:text-green-400 mt-1 font-medium">{previewCount} rows found</p>
                                    <span className="mt-4 text-xs text-gray-400 dark:text-gray-500 hover:text-red-500 underline">Click to change</span>
                                </>
                            ) : (
                                <>
                                    <Upload size={32} className="text-gray-300 dark:text-gray-600 mb-3" />
                                    <p className="font-medium text-gray-600 dark:text-gray-400 text-sm">Click to upload</p>
                                </>
                            )}
                            <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls" onChange={handleFileChange} />
                        </div>
                    </div>
                </div>

                <div className="px-8 pb-4">
                    <h4 className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-3">Import Mode</h4>
                    <div className="grid grid-cols-2 gap-4">
                        <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${importMode === 'MERGE' ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-500 dark:border-blue-400' : 'bg-gray-50 dark:bg-slate-800 border-gray-200 dark:border-slate-700'}`}>
                            <input type="radio" name="importMode" value="MERGE" checked={importMode === 'MERGE'} onChange={() => setImportMode('MERGE')} className="w-4 h-4 text-blue-600 focus:ring-blue-500" />
                            <div>
                                <span className="block text-sm font-bold text-gray-900 dark:text-white">Add to Existing</span>
                                <span className="block text-xs text-gray-500 dark:text-gray-400">Sum quantities (Old + New)</span>
                            </div>
                        </label>
                        <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${importMode === 'REPLACE' ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-500 dark:border-amber-400' : 'bg-gray-50 dark:bg-slate-800 border-gray-200 dark:border-slate-700'}`}>
                            <input type="radio" name="importMode" value="REPLACE" checked={importMode === 'REPLACE'} onChange={() => setImportMode('REPLACE')} className="w-4 h-4 text-amber-600 focus:ring-amber-500" />
                            <div>
                                <span className="block text-sm font-bold text-gray-900 dark:text-white">Update / Overwrite</span>
                                <span className="block text-xs text-gray-500 dark:text-gray-400">Replace current quantities</span>
                            </div>
                        </label>
                    </div>
                </div>

                {error && (
                    <div className="px-8 pb-4">
                        <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-lg flex items-center gap-2 text-sm text-red-700 dark:text-red-400">
                            <AlertCircle size={16} /> {error}
                        </div>
                    </div>
                )}
                <div className="p-6 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-900 flex justify-end gap-3 transition-colors">
                    <button onClick={onClose} disabled={isProcessing} className="px-5 py-2.5 text-gray-700 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-xl font-bold transition-colors text-sm disabled:opacity-50">Cancel</button>
                    <button onClick={processImport} disabled={!file || isProcessing} className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-none flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 text-sm">
                        {isProcessing ? <Loader2 size={18} className="animate-spin" /> : <Upload size={18} />} Start Import
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ImportProductModal;

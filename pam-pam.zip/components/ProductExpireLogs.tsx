
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    Search, Calendar, Plus, Save, 
    X, Trash2, Edit2, FileDown, 
    Database, AlertCircle, CheckCircle2,
    ClipboardX, Clock, ArrowRight,
    TrendingUp, AlertTriangle, History,
    Filter, ChevronDown, Package, Layers,
    Archive, Info, Scan, Tag, MapPin, User as UserIcon
} from 'lucide-react';
import { Product, ExpiryLog } from '../types';
import Scanner from './Scanner';
import * as XLSX from 'xlsx';

type FilterStatus = 'ALL' | 'ACTIVE' | 'URGENT' | 'EXPIRED' | 'REMOVED';

const StatCard: React.FC<{ title: string; value: number; sub: string; color: string; icon: React.ElementType }> = ({ title, value, sub, color, icon: Icon }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    return (
        <div 
            onClick={() => setIsExpanded(!isExpanded)}
            className={`
                min-w-[300px] flex-1
                bg-white dark:bg-slate-900 
                p-4 rounded-xl 
                border border-gray-200 dark:border-slate-800 
                shadow-sm 
                transition-all duration-300 ease-in-out cursor-pointer
                ${isExpanded ? 'ring-2 ring-blue-500 dark:ring-blue-400 shadow-lg scale-105 z-10' : 'hover:shadow-md'}
            `}
        >
            <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${color}`}>
                    <Icon size={22} />
                </div>
                <div>
                    <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest">{title}</p>
                    <div className="flex items-baseline gap-2">
                        <h3 className="text-xl font-black text-gray-900 dark:text-white">{value}</h3>
                        <span className="text-[10px] text-gray-500 dark:text-gray-500 font-medium">{sub}</span>
                    </div>
                </div>
            </div>
            <div className={`grid transition-all duration-300 ease-in-out overflow-hidden ${isExpanded ? 'grid-rows-[1fr] opacity-100 mt-4 pt-4 border-t border-gray-100 dark:border-slate-800' : 'grid-rows-[0fr] opacity-0'}`}>
                <div className="min-h-0 text-xs text-gray-500 dark:text-gray-400 space-y-1">
                    <p className="font-semibold text-gray-700 dark:text-gray-300">Analysis Details:</p>
                    <p>• Real-time metric tracking active.</p>
                    <p>• Data updated automatically based on inventory movements.</p>
                    <p>• Click card again to collapse details.</p>
                </div>
            </div>
        </div>
    );
};

const ProductExpireLogs: React.FC = () => {
    const { products, updateProduct, currentUser, searchProduct } = useInventory();
    
    // UI State
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState<FilterStatus>('ALL');
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isScanningProduct, setIsScanningProduct] = useState(false);
    const [editingLogId, setEditingLogId] = useState<string | null>(null);
    const [offShelfModal, setOffShelfModal] = useState<{ isOpen: boolean; product: Product | null; log: ExpiryLog | null; qty: number }>({
        isOpen: false,
        product: null,
        log: null,
        qty: 0
    });

    // Scanner/Search State for Create Modal
    const [productSearchTerm, setProductSearchTerm] = useState('');
    const [showDropdown, setShowDropdown] = useState(false);
    const productInputRef = useRef<HTMLInputElement>(null);

    // Auto-focus input when opening modal
    useEffect(() => {
        if (isModalOpen && !selectedProduct && !editingLogId) {
            setTimeout(() => {
                productInputRef.current?.focus();
            }, 100);
        }
    }, [isModalOpen, selectedProduct, editingLogId]);

    // Form State
    const [logForm, setLogForm] = useState({
        batchNumber: '',
        quantity: 0,
        mode: 'EXP' as 'EXP' | 'MFG',
        dateValue: '',
        shelfLife: 12,
        note: ''
    });

    const getDaysRemaining = (dateStr: string) => {
        if (!dateStr || dateStr === 'N/A') return null;
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return null;
        const today = new Date();
        today.setHours(0,0,0,0);
        const diffTime = date.getTime() - today.getTime();
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    };

    const getStatusType = (log: ExpiryLog): FilterStatus => {
        if (log.status === 'REMOVED') return 'REMOVED';
        const days = getDaysRemaining(log.expiryDate);
        if (days === null) return 'ACTIVE';
        if (days < 0) return 'EXPIRED';
        if (days <= 14) return 'URGENT';
        return 'ACTIVE';
    };

    const getStatusDisplay = (type: FilterStatus) => {
        switch(type) {
            case 'REMOVED': return { label: 'Removed', color: 'bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400 border-gray-200 dark:border-slate-700' };
            case 'EXPIRED': return { label: 'Expired', color: 'bg-rose-50 dark:bg-rose-900/20 text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-900/30' };
            case 'URGENT': return { label: 'Urgent', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-900/30' };
            default: return { label: 'Active', color: 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30' };
        }
    };

    // Grouping & Filtering Logic
    const groupedData = useMemo(() => {
        const groups: { product: Product; logs: ExpiryLog[] }[] = [];
        
        products.forEach(p => {
            if (!p.expiryLogs || p.expiryLogs.length === 0) return;

            // Sort logs by expiry date ascending
            const filteredLogs = p.expiryLogs.filter(log => {
                const type = getStatusType(log);
                const matchesStatus = statusFilter === 'ALL' || statusFilter === type;
                const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                      p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                      log.batchNumber?.toLowerCase().includes(searchTerm.toLowerCase());
                return matchesStatus && matchesSearch;
            }).sort((a, b) => {
                const dateA = new Date(a.expiryDate).getTime() || 0;
                const dateB = new Date(b.expiryDate).getTime() || 0;
                return dateA - dateB;
            });

            if (filteredLogs.length > 0) {
                groups.push({ product: p, logs: filteredLogs });
            }
        });

        return groups;
    }, [products, statusFilter, searchTerm]);

    // Global Stats
    const globalStats = useMemo(() => {
        let total = 0, urgent = 0, expired = 0, removed = 0;
        products.forEach(p => {
            p.expiryLogs?.forEach(l => {
                const type = getStatusType(l);
                if (type === 'ACTIVE' || type === 'URGENT' || type === 'EXPIRED') total++;
                if (type === 'URGENT') urgent++;
                if (type === 'EXPIRED') expired++;
                if (type === 'REMOVED') removed++;
            });
        });
        return { total, urgent, expired, removed };
    }, [products]);

    const calculateExpiryFromMfg = (mfgDate: string, months: number) => {
        if (!mfgDate) return '';
        try {
            const date = new Date(mfgDate);
            date.setMonth(date.getMonth() + months);
            return date.toISOString().split('T')[0];
        } catch { return ''; }
    };

    const formatDateReadable = (dateStr?: string) => {
        if (!dateStr || dateStr === 'N/A' || dateStr === '-' || !dateStr.trim()) return '-';
        try {
            const date = new Date(dateStr);
            // Force dd/mm/yyyy format
            return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
        } catch { return dateStr; }
    };

    const handleSaveLog = () => {
        const targetProduct = selectedProduct;
        if (!targetProduct) return;
        if (!logForm.dateValue) return alert("Please select a date.");

        const finalExpiryDate = logForm.mode === 'EXP' 
            ? logForm.dateValue 
            : calculateExpiryFromMfg(logForm.dateValue, logForm.shelfLife);
        
        const finalMfgDate = logForm.mode === 'MFG' ? logForm.dateValue : '-';
        const now = new Date().toISOString();

        let updatedLogs = [...(targetProduct.expiryLogs || [])];

        if (editingLogId) {
            updatedLogs = updatedLogs.map(l => l.id === editingLogId ? {
                ...l,
                batchNumber: logForm.batchNumber,
                quantity: logForm.quantity, 
                expiryDate: finalExpiryDate,
                mfgDate: finalMfgDate,
                shelfLife: logForm.mode === 'MFG' ? logForm.shelfLife : undefined,
                type: logForm.mode,
                note: logForm.note,
                updatedAt: now
            } : l);
        } else {
            const newLog: ExpiryLog = {
                id: Date.now().toString(),
                batchNumber: logForm.batchNumber || `B-${Date.now().toString().slice(-4)}`,
                quantity: logForm.quantity,
                expiryDate: finalExpiryDate,
                mfgDate: finalMfgDate,
                shelfLife: logForm.mode === 'MFG' ? logForm.shelfLife : undefined,
                type: logForm.mode,
                note: logForm.note,
                createdAt: now,
                createdBy: currentUser?.name || 'System',
                status: 'ACTIVE'
            };
            updatedLogs.push(newLog);
        }

        updateProduct({ ...targetProduct, expiryLogs: updatedLogs });
        setIsModalOpen(false);
        setEditingLogId(null);
    };

    const handleOffShelfClick = (p: Product, l: ExpiryLog) => {
        setOffShelfModal({ isOpen: true, product: p, log: l, qty: l.quantity || 0 });
    };

    const executeOffShelf = () => {
        if (!offShelfModal.product || !offShelfModal.log) return;
        const now = new Date().toISOString();
        const updatedLogs = (offShelfModal.product.expiryLogs || []).map(l => {
            if (l.id === offShelfModal.log!.id) {
                return {
                    ...l,
                    status: 'REMOVED' as const,
                    removedQuantity: offShelfModal.qty,
                    removedAt: now,
                    removedBy: currentUser?.name || 'System'
                };
            }
            return l;
        });
        updateProduct({ ...offShelfModal.product, expiryLogs: updatedLogs });
        setOffShelfModal({ isOpen: false, product: null, log: null, qty: 0 });
    };

    const handleEditLog = (p: Product, l: ExpiryLog) => {
        setSelectedProduct(p);
        setEditingLogId(l.id);
        const mode = l.type || (l.mfgDate && l.mfgDate !== '-' ? 'MFG' : 'EXP');
        setLogForm({
            batchNumber: l.batchNumber || '',
            quantity: l.quantity || 0,
            mode: mode as 'EXP' | 'MFG',
            dateValue: mode === 'MFG' ? l.mfgDate! : l.expiryDate,
            shelfLife: l.shelfLife || 12,
            note: l.note || ''
        });
        setIsModalOpen(true);
    };

    const handleProductScan = (code: string) => {
        const found = searchProduct(code);
        if (found) {
            setSelectedProduct(found);
            setIsScanningProduct(false);
        } else {
            alert(`Product not found: ${code}`);
        }
    };

    const handleProductSearchKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const exact = products.find(p => p.barcode === productSearchTerm || p.sku === productSearchTerm);
            if (exact) {
                setSelectedProduct(exact);
                setProductSearchTerm('');
                setShowDropdown(false);
            } else {
                const filtered = products.filter(p => 
                    p.name.toLowerCase().includes(productSearchTerm.toLowerCase()) || 
                    p.sku.toLowerCase().includes(productSearchTerm.toLowerCase()) || 
                    p.barcode.includes(productSearchTerm)
                );
                if (filtered.length === 1) {
                    setSelectedProduct(filtered[0]);
                    setProductSearchTerm('');
                    setShowDropdown(false);
                }
            }
        }
    };

    const handleExport = () => {
        const exportData: any[] = [];
        groupedData.forEach(({ product, logs }) => {
            logs.forEach(log => {
                const status = getStatusType(log);
                exportData.push({
                    'Product Name': product.name,
                    'Barcode': product.barcode,
                    'SKU': product.sku,
                    'Batch': log.batchNumber,
                    'Status': status,
                    'Expiry Date': log.expiryDate,
                    'Mfg Date': log.mfgDate,
                    'Date Created': new Date(log.createdAt).toLocaleDateString(),
                    'Total Qty': log.quantity,
                    'Off-shelf Qty': log.removedQuantity || 0
                });
            });
        });
        const ws = XLSX.utils.json_to_sheet(exportData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Expiry Logs");
        XLSX.writeFile(wb, `Expiry_Grouped_${new Date().toISOString().slice(0,10)}.xlsx`);
    };

    const FilterChip: React.FC<{ status: FilterStatus; label: string }> = ({ status, label }) => (
        <button
            onClick={() => setStatusFilter(status)}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all border ${
                statusFilter === status 
                ? 'bg-gray-900 dark:bg-white text-white dark:text-slate-900 border-gray-900 dark:border-white shadow-md' 
                : 'bg-white dark:bg-slate-900 text-gray-500 dark:text-gray-400 border-gray-200 dark:border-slate-800 hover:border-gray-400 dark:hover:border-slate-600'
            }`}
        >
            {label}
        </button>
    );

    const filteredProducts = useMemo(() => {
        if (!productSearchTerm) return [];
        return products.filter(p => 
            p.name.toLowerCase().includes(productSearchTerm.toLowerCase()) || 
            p.sku.toLowerCase().includes(productSearchTerm.toLowerCase()) || 
            p.barcode.includes(productSearchTerm)
        ).slice(0, 10);
    }, [products, productSearchTerm]);

    return (
        <div className="flex flex-col h-full bg-white dark:bg-slate-950 font-sans transition-colors duration-300">
            {isScanningProduct && <Scanner onScan={handleProductScan} onClose={() => setIsScanningProduct(false)} title="Scan Product Barcode" type="product" />}

            {/* Professional Header & Stats */}
            <div className="bg-gray-50 dark:bg-slate-900/50 border-b border-gray-200 dark:border-slate-800 px-8 py-6 shrink-0 space-y-6 transition-colors">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                        <h1 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight flex items-center gap-3">
                            <Clock size={28} className="text-blue-600 dark:text-blue-400" />
                            Shelf-Life Management
                        </h1>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 font-medium italic">Grouped Inventory Expiry Verification System</p>
                    </div>

                    <div className="flex items-center gap-3 w-full md:w-auto">
                        <div className="relative flex-1 md:w-80">
                            <input 
                                className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-xl text-sm focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500"
                                placeholder="Filter by product, SKU, or batch..."
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={18} />
                        </div>
                        <button 
                            onClick={handleExport}
                            className="p-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 text-gray-600 dark:text-gray-300 rounded-xl hover:bg-gray-100 dark:hover:bg-slate-700 transition-all shadow-sm"
                        >
                            <FileDown size={20} />
                        </button>
                        <button 
                            onClick={() => { 
                                setSelectedProduct(null); 
                                setEditingLogId(null); 
                                setLogForm({batchNumber: '', quantity: 0, mode: 'EXP', dateValue: '', shelfLife: 12, note: ''}); 
                                setProductSearchTerm('');
                                setShowDropdown(false);
                                setIsModalOpen(true); 
                            }}
                            className="px-6 py-2.5 bg-blue-600 text-white font-bold rounded-xl shadow-lg hover:bg-blue-700 transition-all text-sm flex items-center gap-2 transform active:scale-95"
                        >
                            <Plus size={18} /> Add Record
                        </button>
                    </div>
                </div>

                <div className="flex flex-col lg:flex-row gap-6">
                    <div className="flex flex-wrap gap-4 flex-1">
                        <StatCard title="Total Batches" value={globalStats.total} sub="Active" color="bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400" icon={Layers} />
                        <StatCard title="Expiring Soon" value={globalStats.urgent} sub="14 Days" color="bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400" icon={Clock} />
                        <StatCard title="Expired" value={globalStats.expired} sub="Critical" color="bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400" icon={AlertTriangle} />
                        <StatCard title="Removed" value={globalStats.removed} sub="History" color="bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400" icon={Archive} />
                    </div>
                    
                    <div className="flex items-center gap-2 p-1.5 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl shadow-sm self-center lg:self-end transition-colors overflow-x-auto no-scrollbar max-w-full">
                        <Filter size={14} className="text-gray-400 dark:text-gray-500 ml-3 mr-1 shrink-0" />
                        <FilterChip status="ALL" label="All" />
                        <FilterChip status="ACTIVE" label="Active" />
                        <FilterChip status="URGENT" label="Urgent" />
                        <FilterChip status="EXPIRED" label="Expired" />
                        <FilterChip status="REMOVED" label="Removed" />
                    </div>
                </div>
            </div>

            {/* Hierarchical Grouped Table */}
            <div className="flex-1 overflow-auto p-8 bg-gray-50/50 dark:bg-slate-950/50 transition-colors">
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-gray-200 dark:border-slate-800 shadow-sm overflow-hidden min-w-[1200px] transition-colors">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-gray-900 dark:bg-slate-950 text-white">
                                <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest border-r border-white/10 dark:border-slate-800">Status</th>
                                <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest border-r border-white/10 dark:border-slate-800">Product / Batch Details</th>
                                <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest border-r border-white/10 dark:border-slate-800 text-center">Expiry Date</th>
                                <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest border-r border-white/10 dark:border-slate-800 text-center">Days Remaining</th>
                                <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest border-r border-white/10 dark:border-slate-800">Created / Mfg</th>
                                <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest text-right">Volume (In/Out)</th>
                                <th className="px-6 py-4 w-40 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-slate-800 transition-colors">
                            {groupedData.map(({ product, logs }) => (
                                <React.Fragment key={product.id}>
                                    {/* Product Header Row */}
                                    <tr className="bg-blue-50/40 dark:bg-blue-900/10 border-l-4 border-blue-600 dark:border-blue-500">
                                        <td className="px-6 py-3">
                                            <span className="flex items-center gap-2 text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase">
                                                <Package size={14} /> Product Item
                                            </span>
                                        </td>
                                        <td className="px-6 py-3" colSpan={2}>
                                            <div className="flex items-center gap-4">
                                                <span className="font-black text-gray-900 dark:text-white text-sm truncate max-w-md">{product.name}</span>
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 font-mono bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 px-2 py-0.5 rounded shadow-sm">SKU: {product.sku}</span>
                                                    <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 font-mono bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 px-2 py-0.5 rounded shadow-sm">B: {product.barcode}</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-3 text-center" colSpan={2}>
                                            <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 bg-white dark:bg-slate-800 px-2 py-1 rounded-full border border-gray-200 dark:border-slate-700 uppercase tracking-tighter shadow-sm">
                                                {logs.length} Batch Record{logs.length > 1 ? 's' : ''}
                                            </span>
                                        </td>
                                        <td className="px-6 py-3 text-right">
                                            <span className="text-xs font-black text-blue-900 dark:text-blue-300 tabular-nums">
                                                Group Sum: {logs.reduce((acc, curr) => acc + (curr.quantity || 0), 0)}
                                            </span>
                                        </td>
                                        <td className="px-6 py-3"></td>
                                    </tr>

                                    {/* Batch Log Rows */}
                                    {logs.map(log => {
                                        const type = getStatusType(log);
                                        const status = getStatusDisplay(type);
                                        const daysRemaining = getDaysRemaining(log.expiryDate);

                                        return (
                                            <tr key={log.id} className={`${type === 'REMOVED' ? 'bg-gray-50/50 dark:bg-slate-900/30' : 'bg-white dark:bg-slate-900'} hover:bg-gray-50/80 dark:hover:bg-blue-900/10 transition-colors`}>
                                                <td className="px-6 py-4">
                                                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter border transition-colors ${status.color}`}>
                                                        {status.label}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-slate-700"></div>
                                                        <div className="flex flex-col">
                                                            <span className="text-xs font-black text-gray-700 dark:text-gray-200 font-mono">{log.batchNumber}</span>
                                                            <span className="text-[9px] text-gray-400 dark:text-gray-500 font-bold uppercase mt-0.5">Reference Batch</span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 text-center">
                                                    <span className={`text-sm font-black font-mono transition-colors ${type === 'EXPIRED' ? 'text-rose-600 dark:text-rose-400' : type === 'URGENT' ? 'text-amber-600 dark:text-amber-400' : 'text-gray-900 dark:text-white'}`}>
                                                        {formatDateReadable(log.expiryDate)}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4 text-center">
                                                    {type !== 'REMOVED' ? (
                                                        <span className={`text-xs font-bold uppercase tracking-tighter ${
                                                            daysRemaining !== null && daysRemaining < 0 ? 'text-rose-600 dark:text-rose-400' : 
                                                            daysRemaining !== null && daysRemaining <= 14 ? 'text-amber-600 dark:text-amber-400' : 
                                                            'text-gray-500 dark:text-gray-400'
                                                        }`}>
                                                            {daysRemaining !== null ? (daysRemaining < 0 ? `${Math.abs(daysRemaining)} Days Ago` : `${daysRemaining} Days Left`) : '-'}
                                                        </span>
                                                    ) : (
                                                        <span className="text-gray-300 dark:text-gray-600">-</span>
                                                    )}
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className="flex flex-col gap-1">
                                                        <div className="flex items-center justify-between text-[10px] w-48">
                                                            <span className="text-gray-400 dark:text-gray-500 font-bold uppercase">Created:</span>
                                                            <span className="font-mono font-bold text-gray-600 dark:text-gray-400">
                                                                {log.createdAt ? formatDateReadable(log.createdAt) : '-'}
                                                            </span>
                                                        </div>
                                                        <div className="text-[9px] text-gray-400 dark:text-gray-500 text-right w-48 font-medium">
                                                            By {log.createdBy || 'System'}
                                                        </div>
                                                        <div className="flex items-center justify-between text-[10px] w-48 mt-1">
                                                            <span className="text-gray-400 dark:text-gray-500 font-bold uppercase">Mfg:</span>
                                                            <span className="font-mono font-bold text-gray-600 dark:text-gray-400">{log.mfgDate && log.mfgDate !== '-' ? formatDateReadable(log.mfgDate) : '-'}</span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 text-right">
                                                    <div className="flex flex-col items-end">
                                                        <div className="text-sm font-black text-gray-900 dark:text-white tabular-nums">
                                                            {log.quantity} <span className="text-[10px] text-gray-400 dark:text-gray-500 font-normal ml-0.5">{product.unit}</span>
                                                        </div>
                                                        {log.removedQuantity ? (
                                                            <div className="flex items-center gap-1.5 text-[10px] text-amber-600 dark:text-amber-400 font-bold mt-1">
                                                                <Archive size={10} /> {log.removedQuantity} Removed
                                                            </div>
                                                        ) : <span className="text-[10px] text-gray-200 dark:text-slate-800 font-bold uppercase mt-1">No Archive</span>}
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className="flex items-center justify-center gap-2">
                                                        {log.status === 'ACTIVE' && (
                                                            <button 
                                                                onClick={() => handleOffShelfClick(product, log)}
                                                                className="p-2 text-gray-500 dark:text-gray-400 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-900/30 rounded-lg transition-all border border-transparent hover:border-amber-100 dark:hover:border-amber-900/50"
                                                                title="Record Removal"
                                                            >
                                                                <ClipboardX size={16} />
                                                            </button>
                                                        )}
                                                        <button 
                                                            onClick={() => handleEditLog(product, log)} 
                                                            className="p-2 text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-all border border-transparent hover:border-blue-100 dark:hover:border-blue-900/50" 
                                                            title="Edit Batch"
                                                        >
                                                            <Edit2 size={16}/>
                                                        </button>
                                                        <button 
                                                            onClick={() => confirm('Permanently delete batch?') && updateProduct({...product, expiryLogs: product.expiryLogs?.filter(l => l.id !== log.id)})} 
                                                            className="p-2 text-gray-500 dark:text-gray-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-all border border-transparent hover:border-rose-100 dark:hover:border-rose-900/50" 
                                                            title="Delete"
                                                        >
                                                            <Trash2 size={16}/>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </React.Fragment>
                            ))}
                            {groupedData.length === 0 && (
                                <tr>
                                    <td colSpan={7} className="py-40 text-center">
                                        <Database className="mx-auto mb-4 opacity-10 dark:opacity-5 text-gray-900 dark:text-white" size={80} />
                                        <p className="text-xl font-black text-gray-300 dark:text-slate-800 uppercase tracking-widest">No matching batches</p>
                                        <p className="text-sm text-gray-400 dark:text-slate-600 mt-2">Adjust your filters or search terms.</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Standard Batch Form Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 dark:bg-black/80 backdrop-blur-md p-4 animate-in fade-in transition-all">
                    <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden border border-gray-100 dark:border-slate-800 transition-colors">
                        <div className="px-10 py-8 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50">
                            <div>
                                <h3 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">{editingLogId ? 'Modify Batch Detail' : 'Create Batch Entry'}</h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 uppercase font-bold tracking-widest">WMS Inventory Lifecycle Tracking</p>
                            </div>
                            <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full text-gray-500 dark:text-gray-400 transition-colors">
                                <X size={24}/>
                            </button>
                        </div>
                        
                        <div className="p-10 space-y-8">
                            {!editingLogId && (
                                <div className="space-y-4">
                                    <label className="block text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest ml-1">Target Product Item</label>
                                    
                                    {!selectedProduct ? (
                                        <div className="flex gap-2">
                                            <div className="relative flex-1">
                                                <input 
                                                    ref={productInputRef}
                                                    className="w-full pl-5 pr-10 py-4 border border-gray-200 dark:border-slate-700 rounded-2xl text-sm bg-gray-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-700 focus:ring-4 focus:ring-blue-500/10 dark:focus:ring-blue-900/20 outline-none font-bold text-gray-900 dark:text-white transition-all appearance-none"
                                                    placeholder="Scan barcode or search item..."
                                                    value={productSearchTerm}
                                                    onChange={e => {
                                                        setProductSearchTerm(e.target.value);
                                                        setShowDropdown(true);
                                                    }}
                                                    onKeyDown={handleProductSearchKeyDown}
                                                />
                                                {showDropdown && productSearchTerm && (
                                                    <div className="absolute top-full left-0 right-0 max-h-48 overflow-y-auto bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 z-50 shadow-lg rounded-xl mt-1">
                                                        {filteredProducts.map(p => (
                                                            <div 
                                                                key={p.id} 
                                                                className="p-3 hover:bg-gray-100 dark:hover:bg-slate-700 cursor-pointer border-b last:border-0 border-gray-100 dark:border-slate-700"
                                                                onClick={() => {
                                                                    setSelectedProduct(p);
                                                                    setProductSearchTerm('');
                                                                    setShowDropdown(false);
                                                                }}
                                                            >
                                                                <p className="text-sm font-bold text-gray-800 dark:text-white">{p.name}</p>
                                                                <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">{p.sku} • {p.barcode}</p>
                                                            </div>
                                                        ))}
                                                        {filteredProducts.length === 0 && (
                                                            <div className="p-3 text-xs text-gray-400 text-center">No matches found</div>
                                                        )}
                                                    </div>
                                                )}
                                                <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={16} />
                                            </div>
                                            <button 
                                                onClick={() => setIsScanningProduct(true)}
                                                className="px-5 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl border border-blue-100 dark:border-blue-900/50 hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-all flex items-center justify-center group"
                                                title="Scan Barcode"
                                            >
                                                <Scan size={20} className="group-active:scale-90 transition-transform" />
                                            </button>
                                        </div>
                                    ) : (
                                        <div className="bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-2xl p-4 flex items-center gap-4 animate-in zoom-in-95 duration-200 relative group transition-colors">
                                            <div className="w-14 h-14 bg-white dark:bg-slate-800 rounded-xl border border-blue-100 dark:border-blue-900/50 flex items-center justify-center overflow-hidden shrink-0 shadow-sm">
                                                {selectedProduct.imageUrl ? <img src={selectedProduct.imageUrl} className="w-full h-full object-cover" /> : <Package size={24} className="text-blue-200 dark:text-blue-800" />}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h4 className="text-sm font-black text-blue-900 dark:text-blue-100 truncate">{selectedProduct.name}</h4>
                                                <div className="flex items-center gap-3 mt-0.5">
                                                    <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1"><Tag size={10} /> {selectedProduct.sku}</span>
                                                    <span className="text-[10px] font-bold text-blue-400 dark:text-blue-500 flex items-center gap-1"><MapPin size={10} /> {selectedProduct.location}</span>
                                                </div>
                                            </div>
                                            <button 
                                                onClick={() => setSelectedProduct(null)}
                                                className="p-1.5 text-blue-300 dark:text-blue-700 hover:text-rose-500 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-all"
                                            >
                                                <X size={16} />
                                            </button>
                                        </div>
                                    )}
                                </div>
                            )}

                            <div className="flex bg-gray-100 dark:bg-slate-800 p-1.5 rounded-2xl transition-colors">
                                <button 
                                    onClick={() => setLogForm({...logForm, mode: 'EXP'})}
                                    className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${logForm.mode === 'EXP' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
                                >
                                    Fixed Expiry Date
                                </button>
                                <button 
                                    onClick={() => setLogForm({...logForm, mode: 'MFG'})}
                                    className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${logForm.mode === 'MFG' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
                                >
                                    Mfg Date Rule
                                </button>
                            </div>

                            <div className="grid grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="block text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest ml-1">Batch # Ref</label>
                                    <input 
                                        className="w-full px-5 py-4 border border-gray-200 dark:border-slate-700 rounded-2xl text-sm bg-gray-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-700 focus:ring-4 focus:ring-blue-500/10 dark:focus:ring-blue-900/20 outline-none font-mono font-bold text-gray-900 dark:text-white transition-colors placeholder:text-gray-300 dark:placeholder:text-gray-600"
                                        placeholder="B-2024-001"
                                        value={logForm.batchNumber}
                                        onChange={e => setLogForm({...logForm, batchNumber: e.target.value})}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="block text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest ml-1">Quantity</label>
                                    <input 
                                        type="number"
                                        className="w-full px-5 py-4 border border-gray-200 dark:border-slate-700 rounded-2xl text-sm bg-gray-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-700 focus:ring-4 focus:ring-blue-500/10 dark:focus:ring-blue-900/20 outline-none font-black text-gray-900 dark:text-white transition-colors"
                                        value={logForm.quantity}
                                        onChange={e => setLogForm({...logForm, quantity: parseInt(e.target.value) || 0})}
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <label className="block text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest ml-1">
                                    {logForm.mode === 'EXP' ? 'Expiration Date (Final)' : 'Verified Manufacturing Date'}
                                </label>
                                <div className="relative group">
                                    <input 
                                        type="date"
                                        className="w-full px-5 py-4 border border-gray-200 dark:border-slate-700 rounded-2xl text-sm bg-gray-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-700 focus:ring-4 focus:ring-blue-500/10 dark:focus:ring-blue-900/20 outline-none font-black text-gray-900 dark:text-white transition-all cursor-pointer"
                                        value={logForm.dateValue}
                                        onChange={e => setLogForm({...logForm, dateValue: e.target.value})}
                                    />
                                    <Calendar className="absolute right-5 top-1/2 -translate-y-1/2 text-gray-300 dark:text-gray-600 pointer-events-none group-focus-within:text-blue-500 transition-colors" size={20} />
                                </div>
                            </div>

                            {logForm.mode === 'MFG' && (
                                <div className="bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 p-6 rounded-3xl animate-in zoom-in-95 duration-200 transition-colors">
                                    <div className="flex items-center gap-8">
                                        <div className="flex-1 space-y-2">
                                            <label className="block text-[11px] font-black text-blue-400 dark:text-blue-500 uppercase tracking-widest">Rule (Months)</label>
                                            <input 
                                                type="number"
                                                className="w-full px-4 py-2.5 bg-white dark:bg-slate-800 border border-blue-200 dark:border-blue-800 rounded-xl text-xl font-black text-blue-700 dark:text-blue-300 outline-none focus:ring-2 focus:ring-blue-400 dark:focus:ring-blue-600 transition-colors"
                                                value={logForm.shelfLife}
                                                onChange={e => setLogForm({...logForm, shelfLife: parseInt(e.target.value) || 0})}
                                            />
                                        </div>
                                        <div className="shrink-0 flex flex-col items-center justify-center bg-white dark:bg-slate-800 px-8 py-4 rounded-2xl border border-blue-100 dark:border-blue-900/50 shadow-sm text-center transition-colors">
                                            <p className="text-[10px] font-black text-gray-300 dark:text-slate-600 uppercase mb-1">Target Expiry</p>
                                            <p className="text-base font-black text-blue-800 dark:text-blue-200 font-mono">
                                                {formatDateReadable(calculateExpiryFromMfg(logForm.dateValue, logForm.shelfLife)) || '---'}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div className="pt-4">
                                <button 
                                    onClick={handleSaveLog}
                                    disabled={!selectedProduct || !logForm.dateValue}
                                    className="w-full py-5 bg-gray-900 dark:bg-white text-white dark:text-slate-900 font-black uppercase tracking-[0.25em] rounded-2xl shadow-2xl hover:bg-black dark:hover:bg-gray-100 transition-all transform active:scale-[0.98] disabled:opacity-20 dark:disabled:opacity-5 disabled:cursor-not-allowed flex items-center justify-center gap-3 text-sm"
                                >
                                    {editingLogId ? <Save size={20} /> : <Plus size={20} />}
                                    {editingLogId ? 'Update Record' : 'Finalize Record'}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Removal Confirmation Modal */}
            {offShelfModal.isOpen && (
                <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 dark:bg-black/90 backdrop-blur-lg p-4 animate-in fade-in transition-all">
                    <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[3rem] shadow-2xl p-10 border border-gray-100 dark:border-slate-800 overflow-hidden relative transition-colors">
                        <div className="absolute top-0 left-0 w-full h-2 bg-amber-500"></div>
                        <div className="flex flex-col items-center text-center">
                            <div className="w-24 h-24 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 rounded-[2rem] flex items-center justify-center mb-8 shadow-inner border border-amber-100 dark:border-amber-900/30">
                                <ClipboardX size={48} />
                            </div>
                            <h3 className="text-2xl font-black text-gray-900 dark:text-white leading-tight">Off-Shelf Move</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2 font-medium">Archiving batch <strong>{offShelfModal.log?.batchNumber}</strong></p>
                        </div>
                        
                        <div className="mt-10 space-y-8">
                            <div className="space-y-3">
                                <label className="block text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest text-center">Qty to Archive</label>
                                <input 
                                    type="number"
                                    className="w-full px-4 py-5 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-[2rem] text-4xl font-black text-center text-amber-700 dark:text-amber-400 focus:ring-4 focus:ring-amber-500/10 outline-none transition-all"
                                    value={offShelfModal.qty}
                                    onChange={e => setOffShelfModal({...offShelfModal, qty: parseInt(e.target.value) || 0})}
                                />
                                <div className="bg-amber-50/50 dark:bg-amber-900/10 p-5 rounded-2xl border border-amber-100 dark:border-amber-900/30 flex items-start gap-4 mt-6">
                                    <Info size={20} className="text-amber-600 dark:text-amber-500 shrink-0 mt-0.5" />
                                    <p className="text-[10px] text-amber-800 dark:text-amber-300 font-bold leading-relaxed uppercase tracking-tight">
                                        This move will archive the batch record without affecting the core inventory total.
                                    </p>
                                </div>
                            </div>

                            <div className="flex gap-4">
                                <button 
                                    onClick={() => setOffShelfModal({isOpen: false, product: null, log: null, qty: 0})}
                                    className="flex-1 py-5 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 font-black uppercase tracking-widest rounded-2xl hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors text-xs"
                                >
                                    Cancel
                                </button>
                                <button 
                                    onClick={executeOffShelf}
                                    className="flex-1 py-5 bg-amber-600 text-white font-black uppercase tracking-widest rounded-2xl shadow-xl shadow-amber-200 dark:shadow-none hover:bg-amber-700 transition-all transform active:scale-95 text-xs"
                                >
                                    Archive
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ProductExpireLogs;


import React, { useState } from 'react';
import { useInventory } from '../context/InventoryContext';
import { Warehouse, WarehouseType } from '../types';
import { Warehouse as WarehouseIcon, Plus, Trash2, Edit2, Save, X, AlertCircle, CheckCircle2, XCircle, Star, ArrowRightLeft, GitBranch } from 'lucide-react';

const WarehouseConfig: React.FC = () => {
    const { warehouses, addWarehouse, updateWarehouse, deleteWarehouse, currentUser } = useInventory();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingWarehouse, setEditingWarehouse] = useState<Partial<Warehouse> | null>(null);
    const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleEdit = (wh: Warehouse) => {
        setEditingWarehouse({
            ...wh,
            type: wh.type || (wh.isMain ? 'MAIN' : 'BRANCH')
        });
        setIsModalOpen(true);
        setError(null);
    };

    const handleAdd = () => {
        setEditingWarehouse({ name: '', code: '', status: 'ACTIVE', type: 'BRANCH' });
        setIsModalOpen(true);
        setError(null);
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (!editingWarehouse?.name || !editingWarehouse?.code) {
            setError("Name and Code are required");
            return;
        }

        // Duplicate Code Check
        const duplicate = warehouses.find(w => w.code === editingWarehouse.code && w.id !== editingWarehouse.id);
        if (duplicate) {
            setError(`Warehouse code "${editingWarehouse.code}" already exists.`);
            return;
        }

        // Type Logic Check: Only 1 Main
        if (editingWarehouse.type === 'MAIN') {
            const existingMain = warehouses.find(w => w.isMain && w.id !== editingWarehouse.id);
            if (existingMain) {
                setError(`Only one Main Warehouse is allowed. Current: ${existingMain.name}`);
                return;
            }
        }

        const finalData = {
            ...editingWarehouse,
            isMain: editingWarehouse.type === 'MAIN'
        };

        if (editingWarehouse.id) {
            updateWarehouse(editingWarehouse.id, finalData);
        } else {
            addWarehouse(finalData as Warehouse);
        }
        setIsModalOpen(false);
        setEditingWarehouse(null);
    };

    const confirmDelete = () => {
        if (deleteConfirmId) {
            deleteWarehouse(deleteConfirmId);
            setDeleteConfirmId(null);
        }
    };

    // Strict Admin check as per requirements
    if (currentUser?.role !== 'ADMIN') {
        return (
            <div className="flex flex-col items-center justify-center h-full text-gray-400 dark:bg-slate-950">
                <AlertCircle size={48} className="mb-4 text-red-400" />
                <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Access Denied</h2>
                <p className="dark:text-gray-400">Only Administrators can configure warehouses.</p>
            </div>
        );
    }

    const getTypeBadge = (type: string = 'BRANCH', isMain: boolean) => {
        if (isMain || type === 'MAIN') {
            return (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-900/50">
                    <Star size={12} fill="currentColor" /> MAIN DC
                </span>
            );
        }
        if (type === 'TRANSFER') {
            return (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-900/50">
                    <ArrowRightLeft size={12} /> TRANSFER
                </span>
            );
        }
        return (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-slate-700">
                <GitBranch size={12} /> BRANCH
            </span>
        );
    };

    return (
        <div className="p-6 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors duration-300">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
                        <WarehouseIcon className="text-blue-600 dark:text-blue-400" />
                        Warehouse Configuration
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Manage distribution centers, branches, and transfer points.</p>
                </div>
                <button 
                    onClick={handleAdd}
                    className="px-4 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 shadow-sm flex items-center gap-2 transition-all active:scale-95"
                >
                    <Plus size={18} /> Add Warehouse
                </button>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden transition-colors">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800">
                        <tr>
                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Warehouse Name</th>
                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Code</th>
                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Type</th>
                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                            <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                        {warehouses.map(wh => (
                            <tr key={wh.id} className={`hover:bg-gray-50 dark:hover:bg-blue-900/10 transition-colors group ${wh.isMain ? 'bg-amber-50/30 dark:bg-amber-900/5' : ''}`}>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-2">
                                        <span className={`font-semibold ${wh.isMain ? 'text-amber-900 dark:text-amber-400' : 'text-gray-800 dark:text-gray-200'}`}>{wh.name}</span>
                                        {wh.isMain && <Star size={14} className="text-amber-500 fill-current" />}
                                    </div>
                                </td>
                                <td className="px-6 py-4 font-mono text-sm text-gray-600 dark:text-gray-400 font-bold">{wh.code}</td>
                                <td className="px-6 py-4 text-sm">
                                    {getTypeBadge(wh.type, wh.isMain)}
                                </td>
                                <td className="px-6 py-4">
                                    {wh.status === 'ACTIVE' ? (
                                        <span className="inline-flex items-center gap-1 text-xs font-bold text-green-600 dark:text-green-400">
                                            <CheckCircle2 size={12} /> Active
                                        </span>
                                    ) : (
                                        <span className="inline-flex items-center gap-1 text-xs font-bold text-gray-400 dark:text-gray-500">
                                            <XCircle size={12} /> Inactive
                                        </span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-right flex justify-end gap-2">
                                    <button 
                                        onClick={() => handleEdit(wh)}
                                        className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 text-gray-600 dark:text-gray-300 text-sm font-medium rounded hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors flex items-center gap-1"
                                    >
                                        <Edit2 size={14} /> Modify
                                    </button>
                                    {!wh.isMain && (
                                        <button 
                                            onClick={() => setDeleteConfirmId(wh.id)}
                                            className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 text-sm font-medium rounded hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors flex items-center gap-1"
                                        >
                                            <Trash2 size={14} />
                                        </button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Edit/Add Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
                    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl w-full max-w-md animate-in fade-in zoom-in-95 transition-colors">
                        <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50">
                            <h3 className="text-lg font-bold text-gray-800 dark:text-white">{editingWarehouse?.id ? 'Modify Warehouse' : 'Add New Warehouse'}</h3>
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors"><X size={20}/></button>
                        </div>
                        <form onSubmit={handleSave} className="p-6 space-y-4">
                            <div>
                                <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1">Warehouse Name</label>
                                <input 
                                    autoFocus
                                    className="w-full px-3 py-2 border border-gray-300 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white dark:bg-slate-800 text-gray-900 dark:text-white transition-colors"
                                    value={editingWarehouse?.name || ''}
                                    onChange={e => setEditingWarehouse(prev => ({ ...prev!, name: e.target.value }))}
                                    placeholder="e.g. 4PC-GW"
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1">Code</label>
                                    <input 
                                        className="w-full px-3 py-2 border border-gray-300 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none uppercase bg-white dark:bg-slate-800 text-gray-900 dark:text-white transition-colors font-mono"
                                        value={editingWarehouse?.code || ''}
                                        onChange={e => setEditingWarehouse(prev => ({ ...prev!, code: e.target.value.toUpperCase() }))}
                                        placeholder="CODE"
                                        maxLength={5}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1">Status</label>
                                    <select 
                                        className="w-full px-3 py-2 border border-gray-300 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white dark:bg-slate-800 text-gray-900 dark:text-white transition-colors"
                                        value={editingWarehouse?.status || 'ACTIVE'}
                                        onChange={e => setEditingWarehouse(prev => ({ ...prev!, status: e.target.value as 'ACTIVE' | 'INACTIVE' }))}
                                    >
                                        <option value="ACTIVE">Active</option>
                                        <option value="INACTIVE">Inactive</option>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1">Warehouse Type</label>
                                <select 
                                    className="w-full px-3 py-2 border border-gray-300 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white dark:bg-slate-800 text-gray-900 dark:text-white transition-colors font-medium"
                                    value={editingWarehouse?.type || 'BRANCH'}
                                    onChange={e => setEditingWarehouse(prev => ({ ...prev!, type: e.target.value as WarehouseType }))}
                                >
                                    <option value="BRANCH">Branch</option>
                                    <option value="MAIN">Main Warehouse (Limit 1)</option>
                                    <option value="TRANSFER">Transfer Point</option>
                                </select>
                                <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                                    {editingWarehouse?.type === 'MAIN' 
                                        ? "This will be the central inventory hub." 
                                        : "Standard storage or transit location."}
                                </p>
                            </div>

                            {error && (
                                <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 p-3 rounded-lg text-sm flex items-center gap-2 border border-red-100 dark:border-red-900/30">
                                    <AlertCircle size={16} /> {error}
                                </div>
                            )}

                            <div className="flex gap-3 pt-4 border-t border-gray-100 dark:border-slate-800">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 font-bold rounded-lg hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors">Cancel</button>
                                <button type="submit" className="flex-1 px-4 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-all active:scale-95 shadow-lg shadow-blue-200 dark:shadow-none">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Delete Confirmation */}
            {deleteConfirmId && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
                    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl w-full max-w-sm p-6 text-center animate-in fade-in zoom-in-95 transition-colors">
                        <div className="w-12 h-12 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900/30">
                            <Trash2 size={24} />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Delete Warehouse?</h3>
                        <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">
                            Are you sure you want to delete this warehouse? This action cannot be undone.
                        </p>
                        <div className="flex gap-3">
                            <button onClick={() => setDeleteConfirmId(null)} className="flex-1 px-4 py-2 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 font-bold rounded-lg hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors">Cancel</button>
                            <button onClick={confirmDelete} className="flex-1 px-4 py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 transition-all active:scale-95">Delete</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default WarehouseConfig;

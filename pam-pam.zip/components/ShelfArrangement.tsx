import React, { useState, useMemo, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { ShelfLane } from '../types';
import { 
    Plus, Trash2, Printer, Edit2, Layers, 
    X, Warehouse as WarehouseIcon, Search,
    LayoutGrid, List, ArrowUp, FileDown,
    CheckSquare, Square, MapPin
} from 'lucide-react';
import { toDataURL } from 'qrcode';
import * as XLSX from 'xlsx';

interface GeneratedLocation {
    id: string;
    locationNo: string;
    shelfNo: string;
    landwayCode: string;
    area: string;
    warehouseName: string;
    bayNum: number;
    rowNum: number;
    colNum: number;
}

// Subcomponent for generating QR Code images asynchronously
const QRCodeImage = ({ text, margin = 1, darkColor = '#000000' }: { text: string, margin?: number, darkColor?: string }) => {
    const [src, setSrc] = useState('');
    
    useEffect(() => {
        toDataURL(text, { width: 256, margin: margin, color: { dark: darkColor, light: '#ffffff' } })
            .then(url => setSrc(url))
            .catch(err => console.error("QR Gen Error", err));
    }, [text, margin, darkColor]);

    if (!src) return <div className="w-full h-full bg-gray-100 rounded animate-pulse" />;
    return <img src={src} alt={text} className="w-full h-full object-contain" />;
};

const ShelfArrangement: React.FC = () => {
    const { warehouses, shelfLanes, addShelfLane, updateShelfLane, deleteShelfLane } = useInventory();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
    const [showPrintPreview, setShowPrintPreview] = useState(false);
    const [modalType, setModalType] = useState<'ADD' | 'UPDATE'>('ADD');
    const [selectedLane, setSelectedLane] = useState<ShelfLane | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedLocationIds, setSelectedLocationIds] = useState<Set<string>>(new Set());
    
    // View Mode for Locations
    const [viewMode, setViewMode] = useState<'GRID' | 'TABLE'>('GRID');

    // Print Configuration State
    const [printConfig, setPrintConfig] = useState({
        width: 60,
        height: 40,
        qrMargin: 1,
        qrColor: '#000000'
    });
    
    // Pagination
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    // Form State
    const [formData, setFormData] = useState<Partial<ShelfLane>>({
        warehouseId: '',
        warehouseName: '',
        warehouseCode: '',
        areaName: '',
        areaCode: '',
        laneCode: '',
        sortOrder: 1,
        shelfCount: 0,
        shelfRows: 0,
        shelfCols: 0
    });

    // Helper to handle warehouse selection
    const handleWarehouseSelect = (warehouseId: string) => {
        const selectedWh = warehouses.find(w => w.id === warehouseId);
        if (selectedWh) {
            setFormData(prev => ({
                ...prev,
                warehouseId: selectedWh.id,
                warehouseName: selectedWh.name,
                warehouseCode: selectedWh.code,
                areaName: `${selectedWh.name} Area`, 
                areaCode: `${selectedWh.code}-Z1`
            }));
        } else {
            setFormData(prev => ({
                ...prev,
                warehouseId: '',
                warehouseName: '',
                warehouseCode: '',
                areaName: '',
                areaCode: ''
            }));
        }
    };

    const openAddModal = () => {
        setModalType('ADD');
        setFormData({
            warehouseId: '',
            warehouseName: '',
            warehouseCode: '',
            areaName: '',
            areaCode: '',
            laneCode: '',
            sortOrder: (shelfLanes.length || 0) + 1,
            shelfCount: 0,
            shelfRows: 0,
            shelfCols: 0
        });
        setIsModalOpen(true);
    };

    const openUpdateModal = (lane: ShelfLane) => {
        setModalType('UPDATE');
        setSelectedLane(lane);
        setFormData({ ...lane });
        setIsModalOpen(true);
    };

    const handleSave = async () => {
        if (!formData.warehouseId) {
            alert("Please select a Warehouse from the configuration.");
            return;
        }

        let processedLaneCode = (formData.laneCode || '').toUpperCase().trim();
        const codeRegex = /^[A-Z0-9]+$/; 
        
        if (!processedLaneCode || !codeRegex.test(processedLaneCode)) {
            alert("Lane Code must contain only letters and numbers.");
            return;
        }
        
        if (!formData.shelfCount || !formData.shelfRows || !formData.shelfCols) {
            alert("Please fill in all quantity fields (Shelf Count, Rows, Cols).");
            return;
        }

        const storageNum = (formData.shelfCount || 0) * (formData.shelfRows || 0) * (formData.shelfCols || 0);

        if (modalType === 'ADD') {
            if (shelfLanes.some(l => l.laneCode === processedLaneCode && l.warehouseId === formData.warehouseId)) {
                alert(`Lane code ${processedLaneCode} already exists in this warehouse.`);
                return;
            }

            const newLane: ShelfLane = {
                id: crypto.randomUUID(), // Temporarily assign ID, DB might overwrite
                ...formData as ShelfLane,
                laneCode: processedLaneCode,
                storageNum
            };
            await addShelfLane(newLane);
        } else if (selectedLane) {
            const updatedLane: ShelfLane = {
                ...formData as ShelfLane,
                id: selectedLane.id,
                laneCode: processedLaneCode, 
                storageNum
            };
            await updateShelfLane(updatedLane);
        }
        setIsModalOpen(false);
    };

    const handleDelete = async (id: string) => {
        if (confirm("Are you sure you want to delete this lane arrangement?")) {
            await deleteShelfLane(id);
        }
    };

    const handleOpenPrintModal = (lane: ShelfLane) => {
        setSelectedLane(lane);
        setSelectedLocationIds(new Set()); // Reset selection
        setShowPrintPreview(false);
        setIsPrintModalOpen(true);
        setViewMode('GRID');
    };

    const handleBatchPrint = () => {
        if (selectedLocationIds.size === 0) {
            alert("Please select at least one location to print.");
            return;
        }
        setShowPrintPreview(true);
    };

    const handleBatchExport = () => {
        if (selectedLocationIds.size === 0) {
            alert("Please select at least one location to export.");
            return;
        }

        const dataToExport = generatedLocations
            .filter(l => selectedLocationIds.has(l.id))
            .map(l => ({
                'Location Code': l.locationNo,
                'Shelf No': l.shelfNo,
                'Warehouse': l.warehouseName,
                'Area': l.area,
                'Lane': l.landwayCode,
                'Bay': l.bayNum,
                'Row': l.rowNum,
                'Column': l.colNum
            }));

        const ws = XLSX.utils.json_to_sheet(dataToExport);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Locations");
        const fileName = `Shelf_Locations_${selectedLane?.laneCode || 'Export'}_${new Date().toISOString().slice(0, 10)}.xlsx`;
        XLSX.writeFile(wb, fileName);
    };

    const handleActualPrint = async () => {
        if (selectedLocationIds.size === 0) return;

        const selectedLocs = generatedLocations.filter(l => selectedLocationIds.has(l.id));
        
        const printWindow = window.open('', '_blank', 'height=600,width=800');
        if (!printWindow) {
            alert("Pop-up blocked! Please allow pop-ups for this site to print.");
            return;
        }

        const itemsHtmlPromises = selectedLocs.map(async (loc) => {
            try {
                const qrDataUrl = await toDataURL(loc.locationNo, { 
                    width: 256, 
                    margin: printConfig.qrMargin, 
                    color: { dark: printConfig.qrColor, light: '#ffffff' } 
                });
                
                return `
                    <div class="label-container" style="width: ${printConfig.width}mm; height: ${printConfig.height}mm;">
                        <div class="label-header">
                            <span>${loc.warehouseName.substring(0, 12)}</span>
                            <span>${loc.landwayCode}</span>
                        </div>
                        <div class="qr-code">
                            <img src="${qrDataUrl}" alt="${loc.locationNo}" />
                        </div>
                        <div class="label-footer">${loc.locationNo}</div>
                    </div>
                `;
            } catch (e) {
                console.error("QR Gen Error", e);
                return '';
            }
        });

        const itemsHtml = (await Promise.all(itemsHtmlPromises)).join('');

        const html = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Print Batch - ${selectedLane?.laneCode}</title>
                <style>
                    @page {
                        size: auto;
                        margin: 0mm;
                    }
                    body {
                        margin: 10mm;
                        font-family: 'Inter', sans-serif, system-ui;
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                    }
                    .print-grid {
                        display: flex;
                        flex-wrap: wrap;
                        gap: 5px;
                        align-content: flex-start;
                    }
                    .label-container {
                        border: 1px dashed #ddd;
                        box-sizing: border-box;
                        padding: 4px;
                        display: flex;
                        flex-direction: column;
                        justify-content: space-between;
                        background: white;
                        break-inside: avoid;
                        page-break-inside: avoid;
                        float: left;
                    }
                    .label-header {
                        display: flex;
                        justify-content: space-between;
                        font-size: 8px;
                        font-weight: 800;
                        text-transform: uppercase;
                        line-height: 1;
                        color: #333;
                    }
                    .qr-code {
                        flex: 1;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        overflow: hidden;
                        padding: 2px;
                    }
                    .qr-code img {
                        max-width: 100%;
                        max-height: 100%;
                        object-fit: contain;
                        display: block;
                    }
                    .label-footer {
                        text-align: center;
                        font-family: monospace;
                        font-size: 12px;
                        font-weight: 900;
                        line-height: 1;
                        color: #000;
                        letter-spacing: -0.5px;
                    }
                    @media print {
                        body { margin: 0; padding: 10mm; }
                        .label-container {
                            border: 1px solid #eee;
                        }
                    }
                </style>
            </head>
            <body>
                <div class="print-grid">
                    ${itemsHtml}
                </div>
                <script>
                    window.onload = () => {
                        setTimeout(() => {
                            window.print();
                        }, 500);
                    };
                <\/script>
            </body>
            </html>
        `;

        printWindow.document.open();
        printWindow.document.write(html);
        printWindow.document.close();
    };

    const filteredLanes = useMemo(() => {
        return shelfLanes.filter(l => 
            l.laneCode.includes(searchTerm.toUpperCase()) || 
            l.warehouseName.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [shelfLanes, searchTerm]);

    const totalPages = Math.ceil(filteredLanes.length / itemsPerPage);
    const currentItems = filteredLanes.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    const generatedLocations: GeneratedLocation[] = useMemo(() => {
        if (!selectedLane) return [];
        const locs: GeneratedLocation[] = [];
        for (let bay = 1; bay <= selectedLane.shelfCount; bay++) {
            const bayStr = bay.toString().padStart(2, '0');
            const shelfNo = `${selectedLane.laneCode}${bayStr}`;
            for (let row = 1; row <= selectedLane.shelfRows; row++) {
                for (let col = 1; col <= selectedLane.shelfCols; col++) {
                    const locationNo = `${shelfNo}-${row}-${col}B`;
                    locs.push({
                        id: locationNo, 
                        locationNo,
                        shelfNo,
                        landwayCode: selectedLane.laneCode,
                        area: selectedLane.areaName,
                        warehouseName: selectedLane.warehouseName,
                        bayNum: bay,
                        rowNum: row,
                        colNum: col
                    });
                }
            }
        }
        return locs;
    }, [selectedLane]);

    const toggleSelection = (id: string) => {
        const newSet = new Set(selectedLocationIds);
        if (newSet.has(id)) newSet.delete(id);
        else newSet.add(id);
        setSelectedLocationIds(newSet);
    };

    const toggleAll = () => {
        if (selectedLocationIds.size === generatedLocations.length) {
            setSelectedLocationIds(new Set());
        } else {
            setSelectedLocationIds(new Set(generatedLocations.map(l => l.id)));
        }
    };

    const readOnlyInputClass = "w-full px-3 py-2 bg-gray-100 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg text-sm font-bold text-gray-800 dark:text-gray-200 cursor-not-allowed opacity-90";
    const editableInputClass = "w-full px-3 py-2 bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-700 rounded-lg text-sm font-medium text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-colors placeholder:text-gray-400";

    return (
        <div className="p-4 md:p-6 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors duration-300 font-sans print:p-0 print:bg-white print:min-h-0">
            {/* Responsive Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 print:hidden">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
                        <Layers className="text-blue-600 dark:text-blue-400" /> Shelf Arrangement
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Configure aisles (landways) and shelf capacities linked to your warehouses.</p>
                </div>
                <div className="flex w-full md:w-auto gap-2">
                    <button 
                        onClick={openAddModal}
                        className="flex-1 md:flex-none bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 md:py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-200 dark:shadow-none active:scale-95"
                    >
                        <Plus size={18} /> Add Landway
                    </button>
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex flex-col gap-4 print:hidden">
                {/* Search Bar */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-4">
                    <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                        <div className="relative w-full md:max-w-md">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                            <input 
                                className="w-full pl-9 pr-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-xl text-sm bg-gray-50 dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-colors"
                                placeholder="Search lane code or warehouse..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="text-xs text-gray-500 font-bold uppercase tracking-wider hidden md:block">
                            Total Lanes: {shelfLanes.length}
                        </div>
                    </div>
                </div>

                {/* Mobile Card View (Visible on small screens) */}
                <div className="md:hidden space-y-4">
                    {currentItems.map(lane => (
                        <div key={lane.id} className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-5 flex flex-col gap-4">
                            <div className="flex justify-between items-start">
                                <div>
                                    <div className="flex items-center gap-2 mb-1">
                                        <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 px-2.5 py-1 rounded-lg text-sm font-black font-mono border border-blue-200 dark:border-blue-800">
                                            {lane.laneCode}
                                        </span>
                                        <span className="text-xs font-medium text-gray-500">Order: {lane.sortOrder}</span>
                                    </div>
                                    <div className="flex items-center gap-1 text-gray-600 dark:text-gray-300 text-xs font-bold">
                                        <WarehouseIcon size={12} /> {lane.warehouseName}
                                    </div>
                                </div>
                                <div className="text-right">
                                    <span className="block text-2xl font-black text-gray-900 dark:text-white leading-none">{lane.storageNum}</span>
                                    <span className="text-[10px] text-gray-400 uppercase font-bold">Slots</span>
                                </div>
                            </div>

                            <div className="grid grid-cols-3 gap-2 bg-gray-50 dark:bg-slate-950/50 p-3 rounded-xl border border-gray-100 dark:border-slate-800">
                                <div className="text-center">
                                    <span className="block text-xs font-bold text-gray-400 uppercase">Bays</span>
                                    <span className="font-bold text-gray-800 dark:text-white">{lane.shelfCount}</span>
                                </div>
                                <div className="text-center border-l border-gray-200 dark:border-slate-700">
                                    <span className="block text-xs font-bold text-gray-400 uppercase">Rows</span>
                                    <span className="font-bold text-gray-800 dark:text-white">{lane.shelfRows}</span>
                                </div>
                                <div className="text-center border-l border-gray-200 dark:border-slate-700">
                                    <span className="block text-xs font-bold text-gray-400 uppercase">Cols</span>
                                    <span className="font-bold text-gray-800 dark:text-white">{lane.shelfCols}</span>
                                </div>
                            </div>

                            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-gray-100 dark:border-slate-800">
                                <button onClick={() => handleOpenPrintModal(lane)} className="flex flex-col items-center justify-center p-2 rounded-xl bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 hover:bg-blue-100 transition-colors">
                                    <Printer size={18} />
                                    <span className="text-[10px] font-bold mt-1">Print</span>
                                </button>
                                <button onClick={() => openUpdateModal(lane)} className="flex flex-col items-center justify-center p-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 transition-colors">
                                    <Edit2 size={18} />
                                    <span className="text-[10px] font-bold mt-1">Edit</span>
                                </button>
                                <button onClick={() => handleDelete(lane.id)} className="flex flex-col items-center justify-center p-2 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 hover:bg-red-100 transition-colors">
                                    <Trash2 size={18} />
                                    <span className="text-[10px] font-bold mt-1">Delete</span>
                                </button>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Desktop Table View (Hidden on mobile) */}
                <div className="hidden md:block bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-100 dark:bg-slate-950 text-gray-600 dark:text-gray-400 font-bold uppercase text-xs border-b border-gray-200 dark:border-slate-800">
                                <tr>
                                    <th className="px-6 py-4">Landway Code</th>
                                    <th className="px-6 py-4">Sort Order</th>
                                    <th className="px-6 py-4">Shelf Bays</th>
                                    <th className="px-6 py-4">Total Storage</th>
                                    <th className="px-6 py-4">Area / Zone</th>
                                    <th className="px-6 py-4">Warehouse</th>
                                    <th className="px-6 py-4 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                                {currentItems.map(lane => (
                                    <tr key={lane.id} className="hover:bg-blue-50/50 dark:hover:bg-slate-800/50 transition-colors group">
                                        <td className="px-6 py-4">
                                            <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 px-2 py-1 rounded text-xs font-black font-mono border border-blue-200 dark:border-blue-800">
                                                {lane.laneCode}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 font-medium text-gray-700 dark:text-gray-300">{lane.sortOrder}</td>
                                        <td className="px-6 py-4 text-gray-900 dark:text-white font-bold">{lane.shelfCount}</td>
                                        <td className="px-6 py-4">
                                            <span className="flex items-center gap-1 font-mono text-gray-600 dark:text-gray-400 font-bold">
                                                {lane.storageNum} <span className="text-[10px] uppercase text-gray-400 font-normal">slots</span>
                                            </span>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex flex-col">
                                                <span className="font-bold text-gray-800 dark:text-gray-200">{lane.areaName}</span>
                                                <span className="text-[10px] text-gray-400 font-mono">{lane.areaCode}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                                                <WarehouseIcon size={14} /> {lane.warehouseName}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                            <div className="flex items-center justify-end gap-2 opacity-80 group-hover:opacity-100 transition-opacity">
                                                <button 
                                                    onClick={() => handleOpenPrintModal(lane)}
                                                    className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                                                    title="View & Print Locations"
                                                >
                                                    <Printer size={16} />
                                                </button>
                                                <button 
                                                    onClick={() => openUpdateModal(lane)}
                                                    className="p-2 text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors"
                                                    title="Edit"
                                                >
                                                    <Edit2 size={16} />
                                                </button>
                                                <button 
                                                    onClick={() => handleDelete(lane.id)}
                                                    className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                                    title="Delete"
                                                >
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Pagination (Common) */}
                {filteredLanes.length > 0 && (
                    <div className="p-4 flex justify-end items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                        {/* Pagination controls can be implemented here */}
                        <span className="font-bold">Page {currentPage} of {totalPages}</span>
                    </div>
                )}

                {filteredLanes.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-20 text-gray-400 dark:text-gray-600">
                        <div className="w-16 h-16 bg-white dark:bg-slate-900 rounded-full flex items-center justify-center mb-4 shadow-sm">
                            <Layers size={32} />
                        </div>
                        <p className="text-lg font-bold">No Shelf Arrangements</p>
                        <p className="text-sm">Add a new landway to get started.</p>
                    </div>
                )}
            </div>

            {/* Add/Edit Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm print:hidden">
                    <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl flex flex-col max-h-[95vh] animate-in zoom-in-95 duration-200 border border-gray-100 dark:border-slate-800">
                        
                        <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50 rounded-t-2xl">
                            <div>
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                                    {modalType === 'ADD' ? 'Add Landway' : 'Edit Configuration'}
                                </h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Configure shelf layout.</p>
                            </div>
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors p-1 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full">
                                <X size={20}/>
                            </button>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto p-6 space-y-6">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-1.5 flex items-center gap-1">
                                    Select Warehouse <span className="text-red-500">*</span>
                                </label>
                                <div className="relative">
                                    <select 
                                        className={`${editableInputClass} pl-10 appearance-none font-bold`}
                                        value={formData.warehouseId}
                                        onChange={(e) => handleWarehouseSelect(e.target.value)}
                                        disabled={modalType === 'UPDATE'}
                                    >
                                        <option value="">-- Choose Warehouse --</option>
                                        {warehouses.map(w => (
                                            <option key={w.id} value={w.id}>{w.name} (Code: {w.code})</option>
                                        ))}
                                    </select>
                                    <WarehouseIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                                </div>
                            </div>

                            <div className="bg-gray-50 dark:bg-slate-900/50 p-4 rounded-xl border border-gray-200 dark:border-slate-800 space-y-3">
                                <h4 className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase flex items-center gap-2 mb-2">
                                    <MapPin size={12} /> Location Details
                                </h4>
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Warehouse Name</label>
                                    <input className={readOnlyInputClass} value={formData.warehouseName} disabled />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Warehouse Code</label>
                                    <input className={readOnlyInputClass} value={formData.warehouseCode} disabled />
                                </div>
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                                            Landway Code <span className="text-red-500">*</span>
                                        </label>
                                        <input 
                                            className={editableInputClass}
                                            placeholder="e.g. ZA"
                                            value={formData.laneCode}
                                            onChange={e => setFormData({...formData, laneCode: e.target.value.toUpperCase()})}
                                            maxLength={4}
                                            disabled={modalType === 'UPDATE'}
                                        />
                                        <p className="text-[10px] text-gray-400 mt-1">Generated: {formData.laneCode}01-1-1B</p>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">Sort Order</label>
                                        <input 
                                            type="number"
                                            className={editableInputClass}
                                            value={formData.sortOrder}
                                            onChange={e => setFormData({...formData, sortOrder: parseInt(e.target.value) || 0})}
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <div className="flex items-center gap-2 mb-2 pb-2 border-b border-gray-100 dark:border-slate-800">
                                    <h4 className="text-xs font-bold text-orange-600 dark:text-orange-400 uppercase flex items-center gap-2">
                                        <LayoutGrid size={12} /> Configuration
                                    </h4>
                                </div>

                                <div className="grid grid-cols-3 gap-3">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5 text-center">Bays <span className="text-red-500">*</span></label>
                                        <input 
                                            type="number"
                                            className={`${editableInputClass} text-center font-bold`}
                                            value={formData.shelfCount}
                                            onChange={e => setFormData({...formData, shelfCount: parseInt(e.target.value) || 0})}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5 text-center">Cols <span className="text-red-500">*</span></label>
                                        <input 
                                            type="number"
                                            className={`${editableInputClass} text-center font-bold`}
                                            value={formData.shelfCols}
                                            onChange={e => setFormData({...formData, shelfCols: parseInt(e.target.value) || 0})}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5 text-center">Rows <span className="text-red-500">*</span></label>
                                        <input 
                                            type="number"
                                            className={`${editableInputClass} text-center font-bold`}
                                            value={formData.shelfRows}
                                            onChange={e => setFormData({...formData, shelfRows: parseInt(e.target.value) || 0})}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="p-6 border-t border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50 dark:bg-slate-950 rounded-b-2xl">
                            <div className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                                Total Storage: <span className="font-bold text-blue-600 dark:text-blue-400">{(formData.shelfCount || 0) * (formData.shelfRows || 0) * (formData.shelfCols || 0)}</span> slots
                            </div>
                            <div className="flex gap-3">
                                <button onClick={() => setIsModalOpen(false)} className="px-4 py-2 border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-700 dark:text-gray-300 font-bold rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">Cancel</button>
                                <button onClick={handleSave} className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-sm transition-all shadow-md active:scale-95">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Batch Print Modal */}
            {isPrintModalOpen && selectedLane && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-0 md:p-4 backdrop-blur-sm print:p-0 print:bg-white print:static print:inset-auto print:h-auto print:flex print:items-start">
                    <div className="bg-white dark:bg-slate-900 md:rounded-2xl shadow-2xl w-full max-w-7xl h-full md:h-[95vh] flex flex-col border border-gray-200 dark:border-slate-800 animate-in zoom-in-95 print:h-auto print:w-full print:max-w-none print:shadow-none print:border-none print:rounded-none print:overflow-visible">
                        
                        {/* Print Header */}
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center p-4 border-b border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-950/50 md:rounded-t-2xl print:hidden gap-3">
                            <div>
                                <h3 className="font-bold text-gray-800 dark:text-white flex items-center gap-2"><Printer size={18}/> Batch Printing</h3>
                                <p className="text-xs text-gray-500 mt-1">Select labels to print for Lane {selectedLane.laneCode}</p>
                            </div>
                            <div className="flex flex-wrap gap-2 w-full md:w-auto">
                                {!showPrintPreview && (
                                    <div className="bg-gray-200 dark:bg-slate-800 rounded-lg p-1 flex mr-2">
                                        <button 
                                            onClick={() => setViewMode('GRID')}
                                            className={`p-2 rounded-md transition-all ${viewMode === 'GRID' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:text-gray-400'}`}
                                            title="Visual Grid"
                                        >
                                            <LayoutGrid size={18} />
                                        </button>
                                        <button 
                                            onClick={() => setViewMode('TABLE')}
                                            className={`p-2 rounded-md transition-all ${viewMode === 'TABLE' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 hover:text-gray-700 dark:text-gray-400'}`}
                                            title="List Table"
                                        >
                                            <List size={18} />
                                        </button>
                                    </div>
                                )}
                                {!showPrintPreview ? (
                                    <>
                                        <button onClick={() => setIsPrintModalOpen(false)} className="flex-1 md:flex-none px-4 py-2 border border-gray-300 dark:border-slate-700 rounded-lg text-sm font-bold text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors">Close</button>
                                        <button onClick={handleBatchExport} className="flex-1 md:flex-none px-4 py-2 border border-gray-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-700 dark:text-gray-300 rounded-lg text-sm font-bold hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2">
                                            <FileDown size={16} /> <span className="hidden sm:inline">Export</span>
                                        </button>
                                        <button onClick={handleBatchPrint} className="flex-1 md:flex-none px-5 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 shadow-sm transition-colors flex items-center justify-center gap-2">
                                            <Printer size={16} /> Print ({selectedLocationIds.size})
                                        </button>
                                    </>
                                ) : (
                                    <>
                                        <button onClick={() => setShowPrintPreview(false)} className="flex-1 md:flex-none px-4 py-2 border border-gray-300 dark:border-slate-700 rounded-lg text-sm font-bold text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors">Back</button>
                                        <button onClick={handleActualPrint} className="flex-1 md:flex-none px-5 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 shadow-sm transition-colors flex items-center justify-center gap-2">
                                            <Printer size={16} /> Confirm
                                        </button>
                                    </>
                                )}
                            </div>
                        </div>

                        {/* Content Body */}
                        <div className="flex-1 flex overflow-hidden bg-white dark:bg-slate-900 print:overflow-visible print:p-0 print:h-auto">
                            <div className="flex-1 overflow-y-auto print:overflow-visible print:h-auto">
                                {!showPrintPreview ? (
                                    viewMode === 'TABLE' ? (
                                        <table className="min-w-full divide-y divide-gray-200 dark:divide-slate-800">
                                            <thead className="bg-gray-50 dark:bg-slate-950 sticky top-0 z-10">
                                                <tr>
                                                    <th className="px-6 py-4 text-left w-16 bg-gray-50 dark:bg-slate-950">
                                                        <button 
                                                            onClick={toggleAll} 
                                                            className="flex items-center text-gray-400 hover:text-blue-600 dark:hover:text-blue-400"
                                                        >
                                                            {selectedLocationIds.size === generatedLocations.length && generatedLocations.length > 0 
                                                                ? <CheckSquare size={20} className="text-blue-600 dark:text-blue-400" /> 
                                                                : <Square size={20} />
                                                            }
                                                        </button>
                                                    </th>
                                                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider bg-gray-50 dark:bg-slate-950">Location No</th>
                                                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider bg-gray-50 dark:bg-slate-950">Shelf No</th>
                                                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider bg-gray-50 dark:bg-slate-950">Area</th>
                                                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider bg-gray-50 dark:bg-slate-950">Warehouse</th>
                                                </tr>
                                            </thead>
                                            <tbody className="bg-white dark:bg-slate-900 divide-y divide-gray-200 dark:divide-slate-800">
                                                {generatedLocations.map((loc) => (
                                                    <tr 
                                                        key={loc.id} 
                                                        className={`hover:bg-blue-50/50 dark:hover:bg-blue-900/10 cursor-pointer transition-colors ${selectedLocationIds.has(loc.id) ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
                                                        onClick={() => toggleSelection(loc.id)}
                                                    >
                                                        <td className="px-6 py-4">
                                                            <div className="flex items-center text-gray-400">
                                                                {selectedLocationIds.has(loc.id) 
                                                                    ? <CheckSquare size={18} className="text-blue-600 dark:text-blue-400" /> 
                                                                    : <Square size={18} />
                                                                }
                                                            </div>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white font-mono">{loc.locationNo}</td>
                                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 font-mono">{loc.shelfNo}</td>
                                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">{loc.area}</td>
                                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">{loc.warehouseName}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    ) : (
                                        <div className="p-4 md:p-6 bg-gray-50 dark:bg-slate-950 overflow-y-auto h-full space-y-8">
                                            {Array.from({length: selectedLane.shelfCount}).map((_, bayIdx) => {
                                                const bayNum = bayIdx + 1;
                                                const bayStr = bayNum.toString().padStart(2, '0');
                                                const shelfNo = `${selectedLane.laneCode}${bayStr}`;
                                                
                                                return (
                                                    <div key={shelfNo} className="bg-white dark:bg-slate-900 p-4 md:p-6 rounded-2xl border border-gray-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
                                                        <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-100 dark:border-slate-800">
                                                            <h4 className="text-sm font-bold text-gray-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                                                <Layers size={14} className="text-blue-500" /> Bay {bayNum} ({shelfNo})
                                                            </h4>
                                                            <span className="text-xs text-gray-400 font-mono flex items-center gap-1">
                                                                <ArrowUp size={10} /> Bottom-Up
                                                            </span>
                                                        </div>
                                                        
                                                        {/* Simulation Grid: Responsive Layout */}
                                                        <div className="overflow-x-auto pb-2">
                                                            <div 
                                                                className="grid gap-2 min-w-max" 
                                                                style={{ gridTemplateColumns: `repeat(${selectedLane.shelfCols}, minmax(60px, 1fr))` }}
                                                            >
                                                                {Array.from({length: selectedLane.shelfRows}).map((_, rowIdx) => {
                                                                    // Invert row index for display so Row 1 is at the bottom
                                                                    const displayRowNumber = selectedLane.shelfRows - rowIdx;
                                                                    
                                                                    return Array.from({length: selectedLane.shelfCols}).map((_, colIdx) => {
                                                                        const colNum = colIdx + 1;
                                                                        const locId = `${shelfNo}-${displayRowNumber}-${colNum}B`;
                                                                        const isSelected = selectedLocationIds.has(locId);
                                                                        
                                                                        return (
                                                                            <div 
                                                                                key={locId}
                                                                                onClick={() => toggleSelection(locId)}
                                                                                className={`relative p-2 rounded-xl border-2 cursor-pointer transition-all flex flex-col items-center gap-2 group w-[80px] h-[90px] md:w-auto md:h-auto ${
                                                                                    isSelected 
                                                                                    ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-500 dark:border-blue-400 shadow-sm' 
                                                                                    : 'bg-gray-50 dark:bg-slate-950 border-transparent hover:border-blue-300 dark:hover:border-blue-700'
                                                                                }`}
                                                                            >
                                                                                <div className="w-10 h-10 md:w-16 md:h-16 bg-white p-1 rounded-lg shadow-sm border border-gray-100 dark:border-slate-800 flex items-center justify-center overflow-hidden shrink-0">
                                                                                    <QRCodeImage text={locId} margin={0} />
                                                                                </div>
                                                                                <div className="text-center w-full">
                                                                                    <span className="text-[10px] font-bold text-gray-900 dark:text-white font-mono tracking-tight block truncate w-full">{displayRowNumber}-{colNum}B</span>
                                                                                </div>
                                                                                
                                                                                <div className={`absolute top-1 right-1 w-4 h-4 rounded-full flex items-center justify-center transition-all ${isSelected ? 'bg-blue-500 scale-100' : 'bg-gray-200 dark:bg-slate-700 scale-0 group-hover:scale-100'}`}>
                                                                                    <CheckSquare size={10} className="text-white" />
                                                                                </div>
                                                                            </div>
                                                                        );
                                                                    });
                                                                })}
                                                            </div>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    )
                                ) : (
                                    /* Accurate Print Preview Grid */
                                    <div className="p-8 bg-gray-200/50 dark:bg-black/50 min-h-full print:p-0 print:bg-white overflow-auto">
                                        <div className="flex flex-wrap gap-4 justify-center content-start print:block">
                                            {generatedLocations.filter(l => selectedLocationIds.has(l.id)).map((loc, idx) => (
                                                <div 
                                                    key={idx} 
                                                    className="bg-white border border-gray-300 flex flex-col items-center justify-between p-1 break-inside-avoid page-break-inside-avoid overflow-hidden relative shadow-sm print:shadow-none print:border-none print:float-left print:m-1"
                                                    style={{ 
                                                        width: `${printConfig.width}mm`, 
                                                        height: `${printConfig.height}mm`,
                                                        boxSizing: 'border-box'
                                                    }}
                                                >
                                                    <div className="w-full flex justify-between items-start px-1 pt-1">
                                                        <span className="text-[8px] font-bold uppercase leading-none">{loc.warehouseName.slice(0, 10)}</span>
                                                        <span className="text-[8px] font-bold leading-none">{loc.landwayCode}</span>
                                                    </div>
                                                    
                                                    <div className="flex-1 w-full flex items-center justify-center overflow-hidden p-1">
                                                        <QRCodeImage 
                                                            text={loc.locationNo} 
                                                            margin={printConfig.qrMargin} 
                                                            darkColor={printConfig.qrColor}
                                                        />
                                                    </div>
                                                    
                                                    <div className="w-full text-center pb-1">
                                                        <span className="font-mono text-base font-black text-black leading-none tracking-wider block">{loc.locationNo}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="p-3 px-6 text-right text-[10px] font-mono text-gray-400 dark:text-gray-600 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-950 md:rounded-b-2xl print:hidden flex justify-between items-center">
                            <span>Selected: {selectedLocationIds.size}</span>
                            <span>Target Size: {printConfig.width}mm x {printConfig.height}mm</span>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ShelfArrangement;

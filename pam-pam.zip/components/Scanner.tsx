
import React, { useEffect, useRef, useState } from 'react';
import { X, Camera, Zap, ScanLine, MapPin, Package, CheckCircle2, QrCode, AlertTriangle, Loader2, Keyboard } from 'lucide-react';
import jsQR from 'jsqr';

interface ScannerProps {
  onScan: (code: string) => void;
  onClose: () => void;
  title?: string;
  type?: 'product' | 'location' | 'general';
}

declare global {
  interface Window {
    BarcodeDetector: any;
  }
}

const Scanner: React.FC<ScannerProps> = ({ onScan, onClose, title = "Scan Barcode / QR", type = 'general' }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasCamera, setHasCamera] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [scanState, setScanState] = useState<'scanning' | 'processing' | 'success' | 'error'>('scanning');
  const [mode, setMode] = useState<'NATIVE' | 'JSQR'>('NATIVE');
  const [manualCode, setManualCode] = useState('');
  
  // Refs to maintain state inside the animation loop without triggering re-renders/re-effects
  const scanStateRef = useRef<'scanning' | 'processing' | 'success' | 'error'>('scanning');
  const onScanRef = useRef(onScan);
  
  // Optimization Refs
  const lastProcessTime = useRef<number>(0);
  const isProcessingFrame = useRef<boolean>(false);
  const DETECTION_INTERVAL = 100; // ms between detection attempts

  // Update onScanRef whenever prop changes to avoid stale closures
  useEffect(() => {
      onScanRef.current = onScan;
  }, [onScan]);

  useEffect(() => {
    let stream: MediaStream | null = null;
    let detector: any = null;
    let animationFrameId: number;
    let mounted = true;

    const initCamera = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error("Camera API not available. Ensure you are using HTTPS or localhost.");
        }

        const videoStream = await navigator.mediaDevices.getUserMedia({
          video: { 
              facingMode: 'environment',
              width: { ideal: 720 }, // Reduced resolution for better performance
              height: { ideal: 720 }
          }
        });

        if (!mounted) {
            videoStream.getTracks().forEach(track => track.stop());
            return;
        }

        stream = videoStream;
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          // Wait for video to be ready
          await new Promise<void>((resolve) => {
              if (videoRef.current) {
                  videoRef.current.onloadedmetadata = () => {
                      videoRef.current?.play().then(() => resolve()).catch(e => console.warn("Play error", e));
                  };
              } else {
                  resolve();
              }
          });
        }

        // Determine Scanning Capability
        if ('BarcodeDetector' in window) {
          try {
            detector = new window.BarcodeDetector({ formats: ['qr_code', 'ean_13', 'code_128', 'code_39', 'upc_a'] });
            setMode('NATIVE');
          } catch (e) {
            console.warn("BarcodeDetector failed to init, falling back to jsQR", e);
            setMode('JSQR');
          }
        } else {
          setMode('JSQR');
        }
        
        const scanFrame = async (timestamp: number) => {
            if (!mounted) return;
            
            // Check ref instead of state to prevent re-running effect
            if (scanStateRef.current !== 'scanning' || !videoRef.current || videoRef.current.paused || videoRef.current.ended) {
                if (scanStateRef.current === 'scanning') animationFrameId = requestAnimationFrame(scanFrame);
                return;
            }

            // Throttle detection
            if (timestamp - lastProcessTime.current < DETECTION_INTERVAL) {
                animationFrameId = requestAnimationFrame(scanFrame);
                return;
            }

            if (isProcessingFrame.current) {
                animationFrameId = requestAnimationFrame(scanFrame);
                return;
            }

            if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
              isProcessingFrame.current = true;
              lastProcessTime.current = timestamp;

              try {
                let code: string | null = null;

                if (mode === 'NATIVE' && detector) {
                    const barcodes = await detector.detect(videoRef.current);
                    if (barcodes.length > 0) {
                        code = barcodes[0].rawValue;
                    }
                } else {
                    // JSQR Fallback - Optimized
                    const canvas = document.createElement('canvas');
                    // Downscale to improve performance (50% scale is usually sufficient)
                    const scale = 0.5;
                    canvas.width = videoRef.current.videoWidth * scale;
                    canvas.height = videoRef.current.videoHeight * scale;
                    
                    const ctx = canvas.getContext('2d', { willReadFrequently: true });
                    if (ctx) {
                        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
                        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                        const qrCode = jsQR(imageData.data, imageData.width, imageData.height, {
                            inversionAttempts: "dontInvert",
                        });
                        if (qrCode) code = qrCode.data;
                    }
                }

                if (code) {
                      // Update Refs immediately to stop processing
                      scanStateRef.current = 'processing';
                      setScanState('processing'); // Trigger UI update
                      
                      if (navigator.vibrate) navigator.vibrate(50);
                      
                      setTimeout(() => {
                          if (!mounted) return;
                          scanStateRef.current = 'success';
                          setScanState('success');
                          if (navigator.vibrate) navigator.vibrate([50, 50, 50]); 
                          setTimeout(() => { 
                              if (mounted) onScanRef.current(code!); 
                          }, 300);
                      }, 200);
                }

              } catch (err) {
                // Silent catch for frame processing errors
              } finally {
                  isProcessingFrame.current = false;
              }
            }
            animationFrameId = requestAnimationFrame(scanFrame);
        };
          
        animationFrameId = requestAnimationFrame(scanFrame);

      } catch (err: any) {
        console.warn("Camera init error:", err);
        if (!mounted) return;
        
        setHasCamera(false);
        
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
            setError("Permission denied. Please allow camera access in browser settings.");
        } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
            setError("No camera found on this device.");
        } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
            setError("Camera is in use by another application.");
        } else {
            setError("Could not access camera: " + (err.message || "Unknown error"));
        }
      }
    };

    initCamera();

    return () => {
      mounted = false;
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []); // Run ONLY once on mount

  const handleSimulateScan = () => {
     if (scanState === 'scanning') {
         scanStateRef.current = 'processing';
         setScanState('processing');
         
         if (navigator.vibrate) navigator.vibrate(50);
         
         setTimeout(() => {
             scanStateRef.current = 'success';
             setScanState('success');
             const mockCodes = ['8801111001', '8801111002', 'AZ01-3-5B', 'SKU-001', 'SKU-003', 'A1-02-B'];
             const randomCode = mockCodes[Math.floor(Math.random() * mockCodes.length)];
             
             if (navigator.vibrate) navigator.vibrate([50, 50]);
             
             setTimeout(() => {
                 onScan(randomCode);
             }, 600);
         }, 500);
     }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (manualCode.trim()) {
          onScan(manualCode.trim());
      }
  };

  const getOverlayStyle = () => {
      switch (scanState) {
          case 'success': return 'border-green-500 shadow-[0_0_0_9999px_rgba(22,163,74,0.5)]';
          case 'processing': return 'border-blue-400 shadow-[0_0_0_9999px_rgba(59,130,246,0.5)] animate-pulse';
          case 'error': return 'border-red-500 shadow-[0_0_0_9999px_rgba(239,68,68,0.5)]';
          default: 
            return type === 'location' 
                ? 'border-purple-500 shadow-[0_0_0_9999px_rgba(0,0,0,0.7)]' 
                : 'border-white/70 shadow-[0_0_0_9999px_rgba(0,0,0,0.7)]';
      }
  };

  const getIcon = () => {
      if (type === 'location') return <MapPin size={20} className="text-white/90" />;
      if (type === 'product') return <Package size={20} className="text-white/90" />;
      return <QrCode size={20} className="text-white/90" />;
  };

  const getStatusText = () => {
      if (scanState === 'success') return 'Scanned Successfully';
      if (scanState === 'processing') return 'Processing...';
      if (scanState === 'error') return 'Scan Failed';
      return 'Align code in frame';
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col">
      <style>{`
        @keyframes scan-laser {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        .animate-scan-laser {
          animation: scan-laser 2s linear infinite;
        }
      `}</style>
      
      <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
        {hasCamera ? (
          <>
            <video 
                ref={videoRef} 
                className="absolute inset-0 w-full h-full object-cover opacity-80"
                playsInline 
                muted 
            />
            
            {/* Status Overlay Center */}
            {(scanState === 'success' || scanState === 'processing') && (
                <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none">
                    <div className="bg-white/90 backdrop-blur-md rounded-full p-6 shadow-2xl transform scale-110 transition-all duration-300">
                        {scanState === 'success' ? (
                            <CheckCircle2 size={64} className="text-green-600 animate-in zoom-in spin-in-12 duration-300" />
                        ) : (
                            <Loader2 size={64} className="text-blue-600 animate-spin" />
                        )}
                    </div>
                </div>
            )}

            {/* Scanning Frame */}
            <div 
                className={`relative z-10 ${type === 'product' ? 'w-72 h-48' : 'w-64 h-64'} border-[4px] rounded-3xl transition-all duration-300 overflow-hidden cursor-pointer ${getOverlayStyle()}`}
                onClick={handleSimulateScan}
            >
                {/* Laser Line */}
                {scanState === 'scanning' && (
                    <div className="absolute left-0 right-0 h-0.5 bg-red-500/90 shadow-[0_0_15px_rgba(239,68,68,1)] animate-scan-laser z-20"></div>
                )}

                {/* Corner Markers */}
                <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-white/30 rounded-tl-xl -mt-1 -ml-1"></div>
                <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-white/30 rounded-tr-xl -mt-1 -mr-1"></div>
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-white/30 rounded-bl-xl -mb-1 -ml-1"></div>
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-white/30 rounded-br-xl -mb-1 -mr-1"></div>
            </div>
            
            {/* Context & Instruction Overlay */}
            <div className="absolute bottom-32 left-0 right-0 flex justify-center pointer-events-none">
                <div className="bg-black/60 backdrop-blur-md px-6 py-3 rounded-full text-white font-medium flex items-center gap-3 border border-white/10 shadow-lg animate-in slide-in-from-bottom-4">
                    {scanState === 'success' ? <CheckCircle2 size={20} className="text-green-400"/> : getIcon()}
                    <span className="text-sm font-bold tracking-wide">{getStatusText()}</span>
                </div>
            </div>
            
            {mode === 'JSQR' && scanState === 'scanning' && (
                 <div className="absolute top-6 left-6 flex items-center gap-1 bg-white/10 backdrop-blur-md text-white/70 text-[10px] font-bold px-3 py-1 rounded-full border border-white/10">
                    <Zap size={10} fill="currentColor" /> QR MODE
                 </div>
            )}
          </>
        ) : (
          <div className="text-white text-center p-8 max-w-sm flex flex-col items-center">
            <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mb-6 animate-pulse">
                <AlertTriangle size={32} className="text-red-400" />
            </div>
            <h3 className="text-xl font-bold mb-2">Camera Access Failed</h3>
            <p className="text-sm text-gray-400 mb-6 max-w-[260px] leading-relaxed">
                {error || "We couldn't access your camera. Please check permissions."}
            </p>
            
            <div className="w-full space-y-3">
                <div className="bg-gray-800 p-4 rounded-xl border border-gray-700 w-full mb-2">
                    <p className="text-xs text-gray-400 mb-2 font-bold uppercase text-left">Manual Entry</p>
                    <form onSubmit={handleManualSubmit} className="flex gap-2">
                        <input 
                            className="flex-1 bg-gray-900 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-blue-500 outline-none"
                            placeholder="Type code here..."
                            value={manualCode}
                            onChange={(e) => setManualCode(e.target.value)}
                            autoFocus
                        />
                        <button type="submit" className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-2 rounded-lg text-sm font-bold">OK</button>
                    </form>
                </div>

                <button onClick={() => window.location.reload()} className="w-full px-6 py-3 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-600 transition-colors text-sm">
                    Retry Camera
                </button>
                <button onClick={onClose} className="w-full px-6 py-3 bg-transparent border border-gray-700 text-gray-400 font-bold rounded-xl hover:bg-gray-800 transition-colors text-sm">
                    Close Scanner
                </button>
            </div>
          </div>
        )}
        
        {hasCamera && (
            <button 
                onClick={onClose}
                className="absolute top-6 right-6 p-3 bg-black/40 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-colors z-30 border border-white/10"
            >
                <X size={24} />
            </button>
        )}
      </div>
      
      {hasCamera && (
          <div className="bg-gray-900 px-6 py-8 rounded-t-3xl -mt-6 relative z-10 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] border-t border-white/10">
            <h3 className="text-center font-bold text-white text-lg mb-2">{title}</h3>
            <p className="text-center text-gray-400 text-xs uppercase tracking-widest font-bold">
                {type === 'product' ? 'Point at Barcode' : 
                type === 'location' ? 'Point at Shelf Label' : 
                'Ready to Scan'}
            </p>
          </div>
      )}
    </div>
  );
};

export default Scanner;

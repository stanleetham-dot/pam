import React, { useState, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    Search, Plus, FileText, Calendar, User, ArrowLeft, Save, Trash2, 
    Scan, Box, CheckCircle2, X, Clock, XCircle, Printer, Edit2,
    Filter, ArrowUp, ArrowDown, ArrowUpDown, CheckSquare, Square,
    ChevronsLeft, ChevronLeft, ChevronRight, ChevronsRight
} from 'lucide-react';
import { Product, AdjustmentItem, AdjustmentBill } from '../types';
import Scanner from './Scanner';

const StatusBadge: React.FC<{ status: 'PENDING' | 'APPROVED' | 'REJECTED'; t: (en: string, zh: string) => string }> = ({ status, t }) => {
    switch (status) {
        case 'APPROVED':
            return (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-green-100 text-green-700 border border-green-200">
                    <CheckCircle2 size={12} /> {t('Approved', '已批准')}
                </span>
            );
        case 'REJECTED':
            return (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-700 border border-red-200">
                    <XCircle size={12} /> {t('Rejected', '已拒绝')}
                </span>
            );
        default:
            return (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-yellow-100 text-yellow-700 border border-yellow-200 animate-pulse">
                    <Clock size={12} /> {t('Pending Review', '待审核')}
                </span>
            );
    }
};

interface CreateBillProps {
    onCancel: () => void;
    onSubmit: (items: AdjustmentItem[], note: string) => void;
    products: Product[];
    t: (en: string, zh: string) => string;
}

const CreateBillView: React.FC<CreateBillProps> = ({ onCancel, onSubmit, products, t }) => {
    const [items, setItems] = useState<AdjustmentItem[]>([]);
    const [note, setNote] = useState('');
    const [search, setSearch] = useState('');
    const [scannerOpen, setScannerOpen] = useState(false);

    const handleAddItem = (product: Product) => {
        if (items.find(i => i.productId === product.id)) return;
        setItems([...items, {
            productId: product.id,
            productName: product.name,
            sku: product.sku,
            barcode: product.barcode,
            currentStock: product.stock,
            actualStock: product.stock,
            adjustmentQty: 0,
            reason: 'Manual Adjustment'
        }]);
    };

    const handleUpdateItem = (id: string, updates: Partial<AdjustmentItem>) => {
        setItems(items.map(i => {
            if (i.productId === id) {
                const updated = { ...i, ...updates };
                if (updates.actualStock !== undefined) {
                    updated.adjustmentQty = updates.actualStock - i.currentStock;
                }
                return updated;
            }
            return i;
        }));
    };

    const handleRemoveItem = (id: string) => setItems(items.filter(i => i.productId !== id));

    const searchedProducts = search 
        ? products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase()) || p.barcode.includes(search))
        : [];

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 h-[calc(100vh-140px)] flex flex-col animate-in fade-in slide-in-from-right-4">
             {scannerOpen && <Scanner onScan={code => { setSearch(code); setScannerOpen(false); }} onClose={() => setScannerOpen(false)} title={t("Scan Item to Add", "扫描商品添加")} />}
             
             <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50/50">
                 <div className="flex items-center gap-3">
                     <button onClick={onCancel} className="p-2 hover:bg-gray-200 rounded-full transition-colors"><ArrowLeft size={20} /></button>
                     <h2 className="text-lg font-bold text-gray-800">{t('Create Adjustment Bill', '创建调整单')}</h2>
                 </div>
                 <div className="flex gap-2">
                     <button onClick={onCancel} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg font-medium">{t('Cancel', '取消')}</button>
                     <button 
                        onClick={() => onSubmit(items, note)}
                        disabled={items.length === 0}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                     >
                         <Save size={18} /> {t('Submit', '提交')}
                     </button>
                 </div>
             </div>

             <div className="flex-1 flex overflow-hidden">
                 {/* Left: Product Search */}
                 <div className="w-1/3 border-r border-gray-200 flex flex-col bg-gray-50">
                     <div className="p-4 border-b border-gray-200">
                         <div className="relative">
                             <input 
                                className="w-full pl-9 pr-10 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                                placeholder={t("Search or Scan Product...", "搜索或扫描商品...")}
                                value={search}
                                onChange={e => setSearch(e.target.value)}
                             />
                             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                             <button onClick={() => setScannerOpen(true)} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-blue-600">
                                 <Scan size={18} />
                             </button>
                         </div>
                     </div>
                     <div className="flex-1 overflow-y-auto p-2 space-y-2">
                         {searchedProducts.map(p => (
                             <button 
                                key={p.id} 
                                onClick={() => handleAddItem(p)}
                                className="w-full text-left p-3 bg-white border border-gray-200 rounded-lg hover:border-blue-400 hover:shadow-sm transition-all group"
                             >
                                 <p className="font-bold text-sm text-gray-800">{p.name}</p>
                                 <div className="flex justify-between mt-1">
                                     <span className="text-xs font-mono text-gray-500 bg-gray-100 px-1 rounded">{p.sku}</span>
                                     <span className="text-xs font-bold text-gray-600">{t('Stock:', '库存:')} {p.stock}</span>
                                 </div>
                             </button>
                         ))}
                         {search && searchedProducts.length === 0 && (
                             <div className="text-center p-8 text-gray-400">{t('No products found', '未找到商品')}</div>
                         )}
                         {!search && (
                             <div className="text-center p-8 text-gray-400 flex flex-col items-center">
                                 <Search size={32} className="mb-2 opacity-50" />
                                 <p>{t('Search to add items', '搜索以添加商品')}</p>
                             </div>
                         )}
                     </div>
                 </div>

                 {/* Right: Bill Items */}
                 <div className="w-2/3 flex flex-col bg-white">
                     <div className="p-4 border-b border-gray-100">
                         <label className="block text-xs font-bold text-gray-500 uppercase mb-1">{t('Note / Reference', '备注 / 参考')}</label>
                         <input 
                            className="w-full border-b border-gray-200 focus:border-blue-500 outline-none py-1 text-sm transition-colors text-gray-900"
                            placeholder={t("Reason for adjustment...", "调整原因...")}
                            value={note}
                            onChange={e => setNote(e.target.value)}
                         />
                     </div>
                     <div className="flex-1 overflow-y-auto p-4">
                         <table className="w-full text-left border-collapse">
                             <thead className="bg-gray-50 text-xs font-bold text-gray-500 uppercase">
                                 <tr>
                                     <th className="px-4 py-3 rounded-l-lg">{t('Product', '商品')}</th>
                                     <th className="px-4 py-3 text-center">{t('Current', '当前')}</th>
                                     <th className="px-4 py-3 text-center w-24">{t('Actual', '实际')}</th>
                                     <th className="px-4 py-3 text-center">{t('Diff', '差异')}</th>
                                     <th className="px-4 py-3">{t('Reason', '原因')}</th>
                                     <th className="px-4 py-3 rounded-r-lg"></th>
                                 </tr>
                             </thead>
                             <tbody className="divide-y divide-gray-100">
                                 {items.map(item => (
                                     <tr key={item.productId} className="group hover:bg-gray-50">
                                         <td className="px-4 py-3">
                                             <p className="font-medium text-sm text-gray-900">{item.productName}</p>
                                             <p className="text-xs text-gray-500 font-mono">{item.sku}</p>
                                         </td>
                                         <td className="px-4 py-3 text-center text-sm">{item.currentStock}</td>
                                         <td className="px-4 py-3">
                                             <input 
                                                type="number"
                                                className="w-full px-2 py-1 border border-gray-300 rounded text-center font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none text-gray-900"
                                                value={item.actualStock}
                                                onChange={e => handleUpdateItem(item.productId, { actualStock: parseInt(e.target.value) || 0 })}
                                             />
                                         </td>
                                         <td className={`px-4 py-3 text-center font-bold text-sm ${item.adjustmentQty < 0 ? 'text-red-600' : item.adjustmentQty > 0 ? 'text-green-600' : 'text-gray-400'}`}>
                                             {item.adjustmentQty > 0 ? '+' : ''}{item.adjustmentQty}
                                         </td>
                                         <td className="px-4 py-3">
                                             <select 
                                                className="w-full text-xs border-gray-200 rounded py-1 bg-transparent text-gray-900"
                                                value={item.reason}
                                                onChange={e => handleUpdateItem(item.productId, { reason: e.target.value })}
                                             >
                                                 <option>Manual Adjustment</option>
                                                 <option>Damaged</option>
                                                 <option>Lost</option>
                                                 <option>Found</option>
                                                 <option>Expired</option>
                                             </select>
                                         </td>
                                         <td className="px-4 py-3 text-right">
                                             <button onClick={() => handleRemoveItem(item.productId)} className="text-gray-400 hover:text-red-600 transition-colors">
                                                 <Trash2 size={16} />
                                             </button>
                                         </td>
                                     </tr>
                                 ))}
                                 {items.length === 0 && (
                                     <tr>
                                         <td colSpan={6} className="text-center py-12 text-gray-400">
                                             <Box size={48} className="mx-auto mb-2 opacity-20" />
                                             <p>{t('No items added yet', '暂无商品添加')}</p>
                                         </td>
                                     </tr>
                                 )}
                             </tbody>
                         </table>
                     </div>
                 </div>
             </div>
        </div>
    );
};

const BillListView: React.FC<{ 
    bills: AdjustmentBill[], 
    onCreate: () => void, 
    onView: (bill: AdjustmentBill) => void,
    onQuickAdjust: () => void,
    onBulkApprove: (ids: string[]) => void,
    t: (en: string, zh: string) => string
}> = ({ bills, onCreate, onView, onQuickAdjust, onBulkApprove, t }) => {
    const [search, setSearch] = useState('');
    const [statusFilter, setStatusFilter] = useState<string>('All');
    const [dateRange, setDateRange] = useState({ start: '', end: '' });
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' }>({ key: 'createdAt', direction: 'desc' });
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(25);

    useEffect(() => { setCurrentPage(1); }, [search, statusFilter, dateRange]);

    const filteredBills = bills.filter(b => {
        const matchesSearch = b.serialNumber.toLowerCase().includes(search.toLowerCase()) || b.createdBy.toLowerCase().includes(search.toLowerCase());
        const matchesStatus = statusFilter === 'All' || b.status === statusFilter;
        let matchesDate = true;
        if (dateRange.start && new Date(b.createdAt) < new Date(dateRange.start)) matchesDate = false;
        if (dateRange.end) {
             const endDate = new Date(dateRange.end);
             endDate.setHours(23, 59, 59, 999);
             if (new Date(b.createdAt) > endDate) matchesDate = false;
        }
        return matchesSearch && matchesStatus && matchesDate;
    }).sort((a, b) => {
        const { key, direction } = sortConfig;
        let comparison = 0;
        if (key === 'createdAt') comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        else if (key === 'serialNumber') comparison = a.serialNumber.localeCompare(b.serialNumber);
        else if (key === 'status') comparison = a.status.localeCompare(b.status);
        return direction === 'asc' ? comparison : -comparison;
    });

    const totalItems = filteredBills.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = filteredBills.slice(indexOfFirstItem, indexOfLastItem);

    const handlePageChange = (page: number) => { if (page >= 1 && page <= totalPages) setCurrentPage(page); };
    const handleSort = (key: string) => setSortConfig(current => ({ key, direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc' }));

    const toggleSelection = (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        const newSet = new Set(selectedIds);
        if (newSet.has(id)) newSet.delete(id);
        else newSet.add(id);
        setSelectedIds(newSet);
    };

    const toggleAll = () => {
        if (selectedIds.size === filteredBills.filter(b => b.status === 'PENDING').length) {
            setSelectedIds(new Set());
        } else {
            setSelectedIds(new Set(filteredBills.filter(b => b.status === 'PENDING').map(b => b.id)));
        }
    };

    const pendingCount = filteredBills.filter(b => b.status === 'PENDING').length;
    const isAllSelected = pendingCount > 0 && selectedIds.size === pendingCount;

    const handleBulkApproveClick = () => {
        if (window.confirm(`Approve ${selectedIds.size} selected bills?`)) {
            onBulkApprove(Array.from(selectedIds));
            setSelectedIds(new Set());
        }
    };

    const SortableHeader = ({ label, sortKey }: { label: string, sortKey: string }) => (
        <th className="px-6 py-3 cursor-pointer hover:bg-gray-200 transition-colors select-none" onClick={() => handleSort(sortKey)}>
            <div className="flex items-center gap-1">
                {label}
                {sortConfig.key === sortKey ? (
                    sortConfig.direction === 'asc' ? <ArrowUp size={14} className="text-blue-600" /> : <ArrowDown size={14} className="text-blue-600" />
                ) : <ArrowUpDown size={14} className="text-gray-400 opacity-0 group-hover:opacity-100" />}
            </div>
        </th>
    );

    return (
        <div className="animate-in fade-in slide-in-from-bottom-2 flex flex-col h-full min-h-screen p-6 bg-gray-50">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4 shrink-0">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2"><FileText className="text-blue-600" /> {t('Adjustment Bills', '库存调整单')}</h1>
                    <p className="text-gray-500 text-sm mt-1">{t('Manage stock discrepancies and audit logs.', '管理库存差异和审计日志。')}</p>
                </div>
                <div className="flex gap-2">
                     <button onClick={onQuickAdjust} className="px-4 py-2 bg-white border border-blue-200 text-blue-600 rounded-lg text-sm font-bold hover:bg-blue-50 flex items-center gap-2 shadow-sm"><Edit2 size={18} /> {t('Quick Adjust', '快速调整')}</button>
                     <button onClick={onCreate} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center gap-2 shadow-sm"><Plus size={18} /> {t('Create Bill', '创建单据')}</button>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col flex-1">
                {/* Advanced Filter Bar */}
                <div className="p-4 border-b border-gray-200 bg-gray-50/50 flex flex-col gap-4">
                    <div className="flex flex-col md:flex-row justify-between gap-4 items-center">
                        <div className="flex gap-2 overflow-x-auto no-scrollbar w-full md:w-auto">
                             {['All', 'PENDING', 'APPROVED', 'REJECTED'].map(status => (
                                 <button key={status} onClick={() => setStatusFilter(status)} className={`px-3 py-1.5 text-xs font-bold rounded-full border transition-colors ${statusFilter === status ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-100'}`}>
                                     {status === 'All' ? t('All Status', '所有状态') : status}
                                 </button>
                             ))}
                        </div>
                        <div className="flex gap-2 w-full md:w-auto">
                            <input type="date" className="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900" value={dateRange.start} onChange={e => setDateRange({...dateRange, start: e.target.value})} />
                            <span className="self-center text-gray-400">-</span>
                            <input type="date" className="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900" value={dateRange.end} onChange={e => setDateRange({...dateRange, end: e.target.value})} />
                        </div>
                        <div className="relative max-w-xs w-full">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                            <input type="text" placeholder={t("Search Serial # or Creator...", "搜索单号或创建人...")} className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900" value={search} onChange={e => setSearch(e.target.value)} />
                        </div>
                    </div>
                    {selectedIds.size > 0 && (
                        <div className="bg-blue-50 border border-blue-100 p-2 rounded-lg flex items-center justify-between animate-in fade-in slide-in-from-top-1">
                            <span className="text-sm font-medium text-blue-800 ml-2">{selectedIds.size} {t('bills selected', '个单据已选')}</span>
                            <button onClick={handleBulkApproveClick} className="px-3 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-md hover:bg-blue-700 shadow-sm flex items-center gap-1">
                                <CheckCircle2 size={14} /> {t('Approve Selected', '批准选中')}
                            </button>
                        </div>
                    )}
                </div>

                <div className="overflow-x-auto flex-1">
                    <table className="w-full text-left text-sm border-collapse">
                        <thead className="bg-gray-50 text-gray-500 font-medium">
                            <tr className="group">
                                <th className="px-4 py-3 w-10 text-center">
                                    {statusFilter === 'PENDING' || statusFilter === 'All' ? (
                                        <button onClick={toggleAll} disabled={pendingCount === 0} className="hover:text-blue-600 disabled:opacity-30">
                                            {isAllSelected ? <CheckSquare size={18} className="text-blue-600" /> : <Square size={18} />}
                                        </button>
                                    ) : null}
                                </th>
                                <SortableHeader label={t("Serial Number", "流水号")} sortKey="serialNumber" />
                                <SortableHeader label={t("Created At", "创建时间")} sortKey="createdAt" />
                                <th className="px-6 py-3">{t('Created By', '创建人')}</th>
                                <SortableHeader label={t("Status", "状态")} sortKey="status" />
                                <th className="px-6 py-3 text-right">{t('Items', '商品数')}</th>
                                <th className="px-6 py-3 text-right">{t('Actions', '操作')}</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {currentItems.map(bill => (
                                <tr key={bill.id} onClick={() => onView(bill)} className={`hover:bg-blue-50 cursor-pointer transition-colors group ${selectedIds.has(bill.id) ? 'bg-blue-50' : ''}`}>
                                    <td className="px-4 py-4 text-center" onClick={(e) => e.stopPropagation()}>
                                        {bill.status === 'PENDING' && (
                                            <button onClick={(e) => toggleSelection(bill.id, e)} className="text-gray-400 hover:text-blue-600">
                                                {selectedIds.has(bill.id) ? <CheckSquare size={18} className="text-blue-600" /> : <Square size={18} />}
                                            </button>
                                        )}
                                    </td>
                                    <td className="px-6 py-4 font-mono font-bold text-gray-700">{bill.serialNumber}</td>
                                    <td className="px-6 py-4 text-gray-600">{new Date(bill.createdAt).toLocaleDateString('en-GB')} <span className="text-gray-400 text-xs">{new Date(bill.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span></td>
                                    <td className="px-6 py-4 flex items-center gap-2"><div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-500">{bill.createdBy.charAt(0)}</div>{bill.createdBy}</td>
                                    <td className="px-6 py-4"><StatusBadge status={bill.status} t={t} /></td>
                                    <td className="px-6 py-4 text-right font-medium">{bill.items.length}</td>
                                    <td className="px-6 py-4 text-right">
                                        <button 
                                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                                            title={t("Print Bill", "打印单据")}
                                        >
                                            <Printer size={18} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {currentItems.length === 0 && (
                                <tr>
                                    <td colSpan={7} className="text-center py-12 text-gray-400">{t('No bills found matching filters.', '未找到符合条件的单据。')}</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="border-t border-gray-200 px-4 py-3 bg-gray-50 flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-gray-600 shrink-0">
                     <div className="flex items-center gap-2">
                         <span>{t('Rows per page:', '每页行数:')}</span>
                         <select 
                             className="bg-white border border-gray-300 rounded px-2 py-1 text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none"
                             value={itemsPerPage}
                             onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                         >
                             <option value={10}>10</option>
                             <option value={25}>25</option>
                             <option value={50}>50</option>
                             <option value={100}>100</option>
                         </select>
                         <span className="ml-2">
                             {t('Showing', '显示')} {totalItems === 0 ? 0 : indexOfFirstItem + 1}-{Math.min(indexOfLastItem, totalItems)} {t('of', '/')} {totalItems}
                         </span>
                     </div>
                     
                     <div className="flex items-center gap-1">
                         <button onClick={() => handlePageChange(1)} disabled={currentPage === 1} className="p-1 rounded hover:bg-gray-200 disabled:opacity-30 disabled:hover:bg-transparent text-gray-600"><ChevronsLeft size={18} /></button>
                         <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} className="p-1 rounded hover:bg-gray-200 disabled:opacity-30 disabled:hover:bg-transparent text-gray-600"><ChevronLeft size={18} /></button>
                         <span className="px-2">{t('Page', '页')} {currentPage} {t('of', '/')} {totalPages || 1}</span>
                         <button onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages || totalPages === 0} className="p-1 rounded hover:bg-gray-200 disabled:opacity-30 disabled:hover:bg-transparent text-gray-600"><ChevronRight size={18} /></button>
                         <button onClick={() => handlePageChange(totalPages)} disabled={currentPage === totalPages || totalPages === 0} className="p-1 rounded hover:bg-gray-200 disabled:opacity-30 disabled:hover:bg-transparent text-gray-600"><ChevronsRight size={18} /></button>
                     </div>
                 </div>
            </div>
        </div>
    );
};

const InventoryAdjustment: React.FC<{ initialView?: 'LIST' | 'QUICK' }> = ({ initialView = 'LIST' }) => {
    const { products, adjustmentBills, createAdjustmentBill, approveAdjustmentBill, rejectAdjustmentBill, currentUser, language } = useInventory();
    const [view, setView] = useState<'LIST' | 'CREATE' | 'DETAIL' | 'QUICK'>(initialView);
    const [selectedBill, setSelectedBill] = useState<AdjustmentBill | null>(null);

    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    const canApprove = currentUser?.role !== 'USER' || currentUser?.permissions?.includes('ACTION_APPROVE_ADJUSTMENT');

    const handleCreateSubmit = (items: AdjustmentItem[], note: string) => {
        createAdjustmentBill(items, note);
        setView('LIST');
    };

    const handleBulkApprove = (ids: string[]) => {
        if (!canApprove) {
            alert(t("You don't have permission to approve adjustments.", "您没有批准调整的权限。"));
            return;
        }
        ids.forEach(id => approveAdjustmentBill(id));
    };

    if (view === 'CREATE') return <CreateBillView onCancel={() => setView('LIST')} onSubmit={handleCreateSubmit} products={products} t={t} />;
    
    if (view === 'DETAIL' && selectedBill) {
        return (
            <div className="animate-in fade-in slide-in-from-right-4">
                <div className="flex items-center justify-between mb-6">
                    <button onClick={() => setView('LIST')} className="flex items-center gap-2 text-gray-500 hover:text-gray-800 font-medium transition-colors"><ArrowLeft size={20} /> {t('Back to List', '返回列表')}</button>
                    <div className="flex gap-2">
                         <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 flex items-center gap-2 shadow-sm"><Printer size={18} /> {t('Print', '打印')}</button>
                         {selectedBill.status === 'PENDING' && canApprove && (
                             <>
                                <button onClick={() => { rejectAdjustmentBill(selectedBill.id); setView('LIST'); }} className="px-4 py-2 bg-red-50 text-red-600 border border-red-200 rounded-lg font-medium hover:bg-red-100">{t('Reject', '拒绝')}</button>
                                <button onClick={() => { approveAdjustmentBill(selectedBill.id); setView('LIST'); }} className="px-4 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 shadow-sm">{t('Approve', '批准')}</button>
                             </>
                         )}
                    </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                    <div className="p-6 border-b border-gray-100 flex justify-between items-start bg-gray-50/50">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 mb-1">{selectedBill.serialNumber}</h1>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                                <span className="flex items-center gap-1"><Calendar size={14}/> {new Date(selectedBill.createdAt).toLocaleDateString('en-GB')}</span>
                                <span className="flex items-center gap-1"><User size={14}/> {selectedBill.createdBy}</span>
                            </div>
                        </div>
                        <StatusBadge status={selectedBill.status} t={t} />
                    </div>
                    {selectedBill.note && <div className="p-4 bg-yellow-50 border-b border-yellow-100 text-sm text-yellow-800 flex items-start gap-2"><FileText size={16} className="mt-0.5" /> {t('Note:', '备注:')} {selectedBill.note}</div>}
                    <div className="p-0">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-50 text-gray-500 font-medium border-b border-gray-200">
                                <tr><th className="px-6 py-3">{t('Product', '商品')}</th><th className="px-6 py-3">SKU</th><th className="px-6 py-3 text-center">{t('Previous', '原库存')}</th><th className="px-6 py-3 text-center">{t('Adjusted To', '调整后')}</th><th className="px-6 py-3 text-center">{t('Difference', '差异')}</th><th className="px-6 py-3">{t('Reason', '原因')}</th></tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {selectedBill.items.map((item, idx) => (
                                    <tr key={idx}>
                                        <td className="px-6 py-4 font-medium text-gray-900">{item.productName}</td>
                                        <td className="px-6 py-4 font-mono text-gray-500">{item.sku}</td>
                                        <td className="px-6 py-4 text-center text-gray-500">{item.currentStock}</td>
                                        <td className="px-6 py-4 text-center font-bold">{item.actualStock}</td>
                                        <td className={`px-6 py-4 text-center font-bold ${item.adjustmentQty > 0 ? 'text-green-600' : 'text-red-600'}`}>{item.adjustmentQty > 0 ? '+' : ''}{item.adjustmentQty}</td>
                                        <td className="px-6 py-4 text-gray-600"><span className="bg-gray-100 px-2 py-1 rounded text-xs border border-gray-200">{item.reason}</span></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }

    if (view === 'QUICK') return <CreateBillView onCancel={() => setView('LIST')} onSubmit={(items, note) => { createAdjustmentBill(items, note, 'APPROVED'); setView('LIST'); }} products={products} t={t} />;

    return <BillListView bills={adjustmentBills} onCreate={() => setView('CREATE')} onView={(b) => { setSelectedBill(b); setView('DETAIL'); }} onQuickAdjust={() => setView('QUICK')} onBulkApprove={handleBulkApprove} t={t} />;
};

export default InventoryAdjustment;
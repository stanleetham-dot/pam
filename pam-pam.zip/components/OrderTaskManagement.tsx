
import React, { useState, useMemo, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { DistributionOrder, DistributionOutlet } from '../types';
import { Search, RefreshCcw, CheckSquare, X, Calendar, Clock, MapPin, Truck, Save, AlertCircle, User, ChevronDown, Building, History, Lock } from 'lucide-react';

const OrderTaskManagement: React.FC = () => {
    const { distributionOrders, addDistributionOrder, updateDistributionOrder, outlets, language, currentUser } = useInventory();
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;
    const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    // Scheduling State
    const [selectedRecipientId, setSelectedRecipientId] = useState<string>('');
    const [scheduleForm, setScheduleForm] = useState<{
        date: string;
        time: string;
        address: string;
        unit: string;
        contact: string;
        postCode: string;
    }>({ date: '', time: '', address: '', unit: '', contact: '', postCode: '' });

    // Address Autocomplete State
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [filteredOutlets, setFilteredOutlets] = useState<DistributionOutlet[]>([]);

    const activeOrder = useMemo(() => distributionOrders.find(o => o.id === selectedOrderId), [distributionOrders, selectedOrderId]);

    // Helper to check if order can be scheduled
    const canSchedule = useMemo(() => {
        if (!activeOrder) return false;
        // Restricted statuses as per requirement
        const restricted = ['Pending', 'Picking', 'Pick Complete', 'Discrepancy'];
        return !restricted.includes(activeOrder.status);
    }, [activeOrder]);

    // Auto-Lookup Address when Order is Selected
    useEffect(() => {
        if (activeOrder) {
            // Find outlet matching the branch name
            const matchedOutlet = outlets.find(o => o.recipient === activeOrder.receivingBranch);
            
            if (matchedOutlet) {
                setSelectedRecipientId(matchedOutlet.id);
            } else {
                setSelectedRecipientId('CUSTOM');
            }

            // Calculate tomorrow's date for default delivery date
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            const tomorrowStr = tomorrow.toISOString().split('T')[0];

            // Use existing delivery details if set, otherwise fallback to outlet data
            setScheduleForm({
                date: activeOrder.deliveryDetails?.sendPeriod || tomorrowStr,
                time: activeOrder.deliveryDetails?.deliveryTime || '09:00 - 12:00',
                address: activeOrder.deliveryDetails?.address || matchedOutlet?.address || '',
                unit: activeOrder.deliveryDetails?.unit || matchedOutlet?.unit || '',
                contact: activeOrder.deliveryDetails?.phone || matchedOutlet?.phone || '',
                postCode: activeOrder.deliveryDetails?.postCode || matchedOutlet?.postCode || ''
            });
        }
    }, [activeOrder, outlets]);

    // Handle changing the Recipient Dropdown
    const handleRecipientChange = (outletId: string) => {
        setSelectedRecipientId(outletId);
        
        if (outletId === 'CUSTOM') {
            // Don't clear fields, just let user edit
            return;
        }

        const outlet = outlets.find(o => o.id === outletId);
        if (outlet) {
            setScheduleForm(prev => ({
                ...prev,
                address: outlet.address || '',
                unit: outlet.unit || '',
                contact: outlet.phone || '',
                postCode: outlet.postCode || ''
            }));
        }
    };

    const handleAddressChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const val = e.target.value;
        setScheduleForm(prev => ({ ...prev, address: val }));
        
        if (val.length > 1) {
            const lowerVal = val.toLowerCase();
            const matches = outlets.filter(o => 
                o.address.toLowerCase().includes(lowerVal) || 
                o.recipient.toLowerCase().includes(lowerVal)
            );
            setFilteredOutlets(matches);
            setShowSuggestions(matches.length > 0);
        } else {
            setShowSuggestions(false);
        }
    };

    const handleSuggestionClick = (outlet: DistributionOutlet) => {
        setScheduleForm(prev => ({
            ...prev,
            address: outlet.address,
            unit: outlet.unit,
            contact: outlet.phone,
            postCode: outlet.postCode
        }));
        setSelectedRecipientId(outlet.id);
        setShowSuggestions(false);
    };

    const handleConfirmSchedule = () => {
        if (!activeOrder) return;
        if (!scheduleForm.address || !scheduleForm.date) {
            alert(t("Please confirm address and delivery date.", "请确认地址和送货日期。"));
            return;
        }

        // Find recipient name - either from outlet list or fallback to order branch
        const selectedOutlet = outlets.find(o => o.id === selectedRecipientId);
        const recipientName = selectedOutlet ? selectedOutlet.recipient : activeOrder.receivingBranch;

        const deliveryDetails: DistributionOutlet = {
            id: activeOrder.deliveryDetails?.id || crypto.randomUUID(),
            recipient: recipientName,
            address: scheduleForm.address,
            unit: scheduleForm.unit,
            phone: scheduleForm.contact,
            postCode: scheduleForm.postCode,
            sendPeriod: scheduleForm.date,
            deliveryTime: scheduleForm.time,
            deliveryMethod: selectedOutlet?.deliveryMethod || 'Scheduled Delivery'
        };

        updateDistributionOrder({
            ...activeOrder,
            deliveryDetails: deliveryDetails,
            status: 'Ready to Ship', // Move to Distribution Center workflow
            scheduledBy: currentUser?.name || 'System',
            scheduledAt: new Date().toISOString()
        });

        alert(t("Delivery scheduled! Sent to Distribution Center.", "配送已安排！已发送至配送中心。"));
        setSelectedOrderId(null);
    };

    const handleReplenishOrder = () => {
        if (!activeOrder) return;
        
        // Match the base order number (everything before the last hyphen if it's a number)
        const suffixRegex = /^(.*?)(?:-(\d+))?$/;
        const match = activeOrder.orderNumber.match(suffixRegex);
        
        // Base is either group 1 (if matched) or the whole string
        const baseOrderNumber = match ? match[1] : activeOrder.orderNumber;

        let maxSuffix = 0;

        // Scan ALL orders to find any that start with this base to determine highest suffix
        distributionOrders.forEach(o => {
            if (o.orderNumber === baseOrderNumber) {
                // If the order is exactly the base, suffix is effectively 0 (next is 1)
                maxSuffix = Math.max(maxSuffix, 0);
            } else if (o.orderNumber.startsWith(baseOrderNumber + '-')) {
                // Check if the part after base is a number
                const rest = o.orderNumber.substring(baseOrderNumber.length + 1);
                if (/^\d+$/.test(rest)) {
                    const suffix = parseInt(rest, 10);
                    maxSuffix = Math.max(maxSuffix, suffix);
                }
            }
        });

        const newOrderNumber = `${baseOrderNumber}-${maxSuffix + 1}`;

        const newOrder: DistributionOrder = {
            ...activeOrder,
            id: crypto.randomUUID(),
            orderNumber: newOrderNumber,
            status: 'Pending', 
            createTime: new Date().toISOString(),
            assignedDriverId: undefined,
            driverNote: undefined,
            scheduledBy: undefined,
            scheduledAt: undefined,
            deliveryDetails: undefined, 
            items: activeOrder.items.map(i => ({...i, id: crypto.randomUUID(), pickedQty: 0, status: 'PENDING'}))
        };

        addDistributionOrder(newOrder);
        alert(t(`Replenishment order ${newOrderNumber} created.`, `补货订单 ${newOrderNumber} 已创建。`));
    };

    // Include ALL statuses as requested so they remain visible for tracking/replenish history
    const filteredOrders = distributionOrders.filter(o => 
        o.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.receivingBranch.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="p-6 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors">
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6 flex items-center gap-2">
                <CheckSquare className="text-blue-600" />
                {t('Task Management', '任务管理')}
            </h1>
            
             <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col h-[calc(100vh-150px)] transition-colors">
                <div className="p-4 border-b border-gray-200 dark:border-slate-800 flex gap-4 bg-gray-50/50 dark:bg-slate-950/50">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                        <input 
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
                            placeholder={t("Search all orders...", "搜索所有订单...")}
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>
                <div className="flex-1 overflow-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-gray-100 dark:bg-slate-950 text-gray-500 dark:text-gray-400 font-bold sticky top-0 border-b border-gray-200 dark:border-slate-800">
                            <tr>
                                <th className="px-6 py-3">{t('Order #', '订单号')}</th>
                                <th className="px-6 py-3">{t('Branch', '门店')}</th>
                                <th className="px-6 py-3">{t('Date Created', '创建日期')}</th>
                                <th className="px-6 py-3">{t('Scheduled By', '安排人')}</th>
                                <th className="px-6 py-3">{t('Status', '状态')}</th>
                                <th className="px-6 py-3 text-right">{t('Actions', '操作')}</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                            {filteredOrders.map(order => (
                                <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
                                    <td className="px-6 py-3 font-mono font-medium text-gray-900 dark:text-white">{order.orderNumber}</td>
                                    <td className="px-6 py-3 text-gray-700 dark:text-gray-300">{order.receivingBranch}</td>
                                    <td className="px-6 py-3 text-gray-600 dark:text-gray-400">
                                        {new Date(order.createTime).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-3">
                                        {order.scheduledBy ? (
                                            <div className="flex items-center gap-1 text-blue-600 dark:text-blue-400 font-bold text-xs">
                                                <User size={12} /> {order.scheduledBy}
                                            </div>
                                        ) : (
                                            <span className="text-gray-400 text-xs">-</span>
                                        )}
                                    </td>
                                    <td className="px-6 py-3">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                                            order.status === 'Approved' || order.status === 'Delivered' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                                            order.status === 'Ready to Ship' || order.status === 'Shipped' || order.status === 'In Transit' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                                            order.status === 'Delivery Failed' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' :
                                            'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400'
                                        }`}>
                                            {order.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-3 text-right">
                                        <button 
                                            onClick={() => { setSelectedOrderId(order.id); }}
                                            className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 font-bold hover:underline"
                                        >
                                            {t('Manage', '管理')}
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {filteredOrders.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="py-12 text-center text-gray-400 dark:text-gray-600">
                                        {t('No orders found.', '未找到订单。')}
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
             </div>
             
             {activeOrder && (
                 <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 backdrop-blur-sm animate-in fade-in duration-200">
                     <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl shadow-2xl border border-gray-200 dark:border-slate-800 transition-colors flex flex-col max-h-[90vh]">
                         <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50 rounded-t-2xl">
                             <div>
                                 <h3 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                                     <Truck className="text-blue-600 dark:text-blue-400" /> {t('Schedule Delivery', '安排配送')}
                                 </h3>
                                 <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 font-medium">{activeOrder.orderNumber}</p>
                             </div>
                             <button onClick={() => setSelectedOrderId(null)} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-slate-800 text-gray-500 transition-colors"><X size={20}/></button>
                         </div>
                         
                         <div className="p-6 flex-1 overflow-y-auto space-y-8 relative">
                             {!canSchedule && (
                                 <div className="bg-amber-50 dark:bg-amber-900/20 border-l-4 border-amber-500 p-4 mb-4 rounded-r-lg flex items-start gap-3 animate-in fade-in">
                                     <Lock className="text-amber-500 shrink-0 mt-0.5" size={20} />
                                     <div>
                                         <h4 className="text-sm font-bold text-amber-800 dark:text-amber-300 uppercase mb-1">Scheduling Locked</h4>
                                         <p className="text-sm text-amber-700 dark:text-amber-400">
                                             This order is currently <strong>{activeOrder.status}</strong>. It must be <strong>Approved</strong> before scheduling delivery.
                                         </p>
                                     </div>
                                 </div>
                             )}

                             {/* Address Section */}
                             <div className={`space-y-5 ${!canSchedule ? 'opacity-50 pointer-events-none' : ''}`}>
                                 <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-slate-800">
                                     <h4 className="text-sm font-extrabold text-gray-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
                                         <MapPin size={16} className="text-blue-500" /> {t('Recipient & Location', '收件人与位置')}
                                     </h4>
                                 </div>

                                 <div>
                                     <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase">{t('Select Recipient', '选择收件人')}</label>
                                     <div className="relative">
                                         <select 
                                             className="w-full pl-10 pr-10 py-3 bg-blue-50/50 dark:bg-slate-800 border border-blue-100 dark:border-slate-700 rounded-xl text-sm font-bold text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer transition-colors"
                                             value={selectedRecipientId}
                                             onChange={(e) => handleRecipientChange(e.target.value)}
                                             disabled={!canSchedule}
                                         >
                                             <option value="CUSTOM">{t('Custom / Manual Entry', '自定义 / 手动输入')}</option>
                                             {outlets.map(outlet => (
                                                 <option key={outlet.id} value={outlet.id}>
                                                     {outlet.recipient} {outlet.recipient === activeOrder.receivingBranch ? '(Match)' : ''}
                                                 </option>
                                             ))}
                                         </select>
                                         <Building className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-500 pointer-events-none" size={16} />
                                         <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={16} />
                                     </div>
                                 </div>
                                 
                                 <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                     <div className="md:col-span-2">
                                         <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase">Street Address</label>
                                         <div className="relative">
                                             <textarea 
                                                 rows={2}
                                                 className="w-full px-4 py-3 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all resize-none placeholder:text-gray-400"
                                                 value={scheduleForm.address}
                                                 onChange={handleAddressChange}
                                                 onFocus={() => { if(scheduleForm.address) handleAddressChange({ target: { value: scheduleForm.address } } as any); }}
                                                 onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                                                 placeholder="Full address..."
                                                 disabled={!canSchedule}
                                             />
                                             {showSuggestions && (
                                                 <div className="absolute z-10 w-full bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl shadow-xl mt-1 max-h-48 overflow-y-auto">
                                                     {filteredOutlets.map(outlet => (
                                                         <div 
                                                             key={outlet.id}
                                                             className="p-3 hover:bg-gray-50 dark:hover:bg-slate-700 cursor-pointer border-b border-gray-100 dark:border-slate-700 last:border-0"
                                                             onClick={() => handleSuggestionClick(outlet)}
                                                         >
                                                             <div className="flex justify-between items-center mb-0.5">
                                                                 <span className="text-sm font-bold text-gray-900 dark:text-white">{outlet.recipient}</span>
                                                                 {outlet.id === selectedRecipientId && <span className="text-[10px] text-blue-500 font-bold bg-blue-50 dark:bg-blue-900/30 px-1.5 py-0.5 rounded">Current</span>}
                                                             </div>
                                                             <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1">{outlet.address}</p>
                                                         </div>
                                                     ))}
                                                 </div>
                                             )}
                                         </div>
                                     </div>
                                     <div>
                                         <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase">Unit No</label>
                                         <input 
                                             className="w-full px-4 py-3 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                                             value={scheduleForm.unit}
                                             onChange={e => setScheduleForm({...scheduleForm, unit: e.target.value})}
                                             placeholder="e.g. #01-01"
                                             disabled={!canSchedule}
                                         />
                                     </div>
                                     <div>
                                         <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase">Postcode</label>
                                         <input 
                                             className="w-full px-4 py-3 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                                             value={scheduleForm.postCode}
                                             onChange={e => setScheduleForm({...scheduleForm, postCode: e.target.value})}
                                             placeholder="e.g. 123456"
                                             disabled={!canSchedule}
                                         />
                                     </div>
                                     <div className="md:col-span-2">
                                         <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase">Contact Phone</label>
                                         <div className="relative">
                                            <input 
                                                className="w-full pl-10 pr-4 py-3 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                                                value={scheduleForm.contact}
                                                onChange={e => setScheduleForm({...scheduleForm, contact: e.target.value})}
                                                placeholder="+65 1234 5678"
                                                disabled={!canSchedule}
                                            />
                                            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                            </div>
                                         </div>
                                     </div>
                                 </div>
                                 {!scheduleForm.address && (
                                     <div className="flex items-center gap-2 p-3 bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 rounded-lg text-xs font-bold border border-amber-100 dark:border-amber-900/30 animate-in fade-in">
                                         <AlertCircle size={14} /> Please select a recipient or enter address manually.
                                     </div>
                                 )}
                             </div>

                             {/* Timing Section */}
                             <div className={`space-y-5 pt-2 ${!canSchedule ? 'opacity-50 pointer-events-none' : ''}`}>
                                <h4 className="text-sm font-extrabold text-gray-800 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-gray-100 dark:border-slate-800">
                                     <Calendar size={16} className="text-purple-500" /> {t('Timing Preference', '时间偏好')}
                                 </h4>
                                 <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                     <div>
                                         <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase">{t('Delivery Date', '送货日期')}</label>
                                         <input 
                                             type="date"
                                             className="w-full px-4 py-3 border border-gray-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold"
                                             value={scheduleForm.date}
                                             onChange={e => setScheduleForm({...scheduleForm, date: e.target.value})}
                                             disabled={!canSchedule}
                                         />
                                     </div>
                                     <div>
                                         <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase">{t('Time Slot', '时间段')}</label>
                                         <div className="relative">
                                            <select 
                                                className="w-full px-4 py-3 border border-gray-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none appearance-none font-bold cursor-pointer"
                                                value={scheduleForm.time}
                                                onChange={e => setScheduleForm({...scheduleForm, time: e.target.value})}
                                                disabled={!canSchedule}
                                            >
                                                <option value="09:00 - 12:00">Morning (09:00 - 12:00)</option>
                                                <option value="12:00 - 15:00">Afternoon (12:00 - 15:00)</option>
                                                <option value="15:00 - 18:00">Late Afternoon (15:00 - 18:00)</option>
                                                <option value="18:00 - 21:00">Evening (18:00 - 21:00)</option>
                                                <option value="Anytime">Anytime</option>
                                            </select>
                                            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
                                                <Clock size={16} />
                                            </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </div>

                         <div className="p-6 border-t border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-950/50 rounded-b-2xl flex flex-col md:flex-row justify-between items-center gap-4">
                             <button onClick={handleReplenishOrder} className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 text-xs font-bold flex items-center gap-2 transition-colors">
                                 <RefreshCcw size={14} /> {t('Create Copy (Replenish)', '创建副本 (补货)')}
                             </button>
                             <div className="flex gap-3 w-full md:w-auto">
                                <button onClick={() => setSelectedOrderId(null)} className="flex-1 md:flex-none px-6 py-3 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 font-bold rounded-xl hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors text-sm">
                                    {t('Cancel', '取消')}
                                </button>
                                <button 
                                    onClick={handleConfirmSchedule} 
                                    disabled={!canSchedule}
                                    className={`flex-1 md:flex-none px-8 py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-200 dark:shadow-none flex items-center justify-center gap-2 transition-all text-sm ${!canSchedule ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700 active:scale-95'}`}
                                >
                                    <Truck size={18} /> {t('Confirm Schedule', '确认安排')}
                                </button>
                             </div>
                         </div>
                     </div>
                 </div>
             )}
        </div>
    );
};

export default OrderTaskManagement;

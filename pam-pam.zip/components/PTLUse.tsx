
import React, { useState } from 'react';
import { Zap, CheckCircle2, ArrowRight } from 'lucide-react';

const PTLUse: React.FC = () => {
    // Simulated active task
    const [activeLocation, setActiveLocation] = useState('A1-04-B');
    const [activeQty, setActiveQty] = useState(5);
    const [isComplete, setIsComplete] = useState(false);

    const handleConfirm = () => {
        setIsComplete(true);
        setTimeout(() => {
            // Simulate moving to next task
            setIsComplete(false);
            setActiveLocation('B2-10-A');
            setActiveQty(2);
        }, 1500);
    };

    return (
        <div className="flex flex-col items-center justify-center h-full bg-gray-100 dark:bg-slate-950 text-gray-900 dark:text-white p-6 transition-colors duration-300">
            <div className="max-w-2xl w-full text-center">
                <div className="mb-8 flex items-center justify-center gap-3 text-blue-600 dark:text-blue-400">
                    <Zap size={32} />
                    <h1 className="text-3xl font-bold">Pick-to-Light System</h1>
                </div>

                {isComplete ? (
                    <div className="animate-in zoom-in duration-300 flex flex-col items-center">
                        <CheckCircle2 size={120} className="text-green-500 mb-6" />
                        <h2 className="text-4xl font-bold text-green-600 dark:text-green-400">PICK CONFIRMED</h2>
                    </div>
                ) : (
                    <div className="space-y-8 animate-in fade-in duration-500">
                        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-gray-200 dark:border-slate-800 shadow-2xl transition-colors">
                            <p className="text-gray-500 dark:text-gray-400 text-lg uppercase tracking-widest font-bold mb-2">Target Location</p>
                            <div className="text-8xl font-black font-mono text-blue-600 dark:text-yellow-400 tracking-wider">
                                {activeLocation}
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-6">
                            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-gray-200 dark:border-slate-800 transition-colors shadow-sm">
                                <p className="text-gray-500 dark:text-gray-400 uppercase font-bold text-sm">Product</p>
                                <p className="text-2xl font-bold mt-1 text-gray-900 dark:text-white">Wireless Mouse M185</p>
                            </div>
                            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-gray-200 dark:border-slate-800 transition-colors shadow-sm">
                                <p className="text-gray-500 dark:text-gray-400 uppercase font-bold text-sm">Pick Quantity</p>
                                <p className="text-6xl font-bold text-blue-600 dark:text-white mt-1 tabular-nums">{activeQty}</p>
                            </div>
                        </div>

                        <button 
                            onClick={handleConfirm}
                            className="w-full py-6 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-2xl shadow-lg shadow-blue-600/30 dark:shadow-blue-900/50 transition-all active:scale-95 flex items-center justify-center gap-4"
                        >
                            CONFIRM PICK <ArrowRight size={32} />
                        </button>
                    </div>
                )}
                
                <div className="mt-12">
                    <p className="text-xs text-gray-400 dark:text-gray-600 font-bold uppercase tracking-[0.3em]">Operational Terminal Mode</p>
                </div>
            </div>
        </div>
    );
};

export default PTLUse;

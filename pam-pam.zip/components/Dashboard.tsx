
import React from 'react';
import { useInventory } from '../context/InventoryContext';
import { ViewState } from '../types';
import { 
  Scan, 
  ArrowDownToLine, 
  ClipboardCheck, 
  Tag, 
  Clock, 
  TrendingUp, 
  Package, 
  AlertTriangle,
  AlertCircle,
  Archive,
  Smartphone
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

interface DashboardProps {
  onNavigate: (view: ViewState) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { stats, transactions, products, theme, language } = useInventory();
  const isDark = theme === 'dark';

  const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

  // Mock data for charts
  const weeklyData = [
    { name: 'Mon', inbound: 40, outbound: 24 },
    { name: 'Tue', inbound: 30, outbound: 13 },
    { name: 'Wed', inbound: 20, outbound: 58 },
    { name: 'Thu', inbound: 27, outbound: 39 },
    { name: 'Fri', inbound: 18, outbound: 48 },
    { name: 'Sat', inbound: 23, outbound: 38 },
    { name: 'Sun', inbound: 34, outbound: 43 },
  ];

  // Logic for expiring products (Next 30 days)
  const expiringProducts = products
    .map(p => {
      let earliestDate = p.expiryDate;
      let relevantBatch = 'N/A';
      let relevantQty = p.stock;

      if (p.expiryLogs && p.expiryLogs.length > 0) {
          const activeLogs = p.expiryLogs.filter(l => l.status === 'ACTIVE').sort((a,b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
          if (activeLogs.length > 0) {
              earliestDate = activeLogs[0].expiryDate;
              relevantBatch = activeLogs[0].batchNumber || 'N/A';
              relevantQty = activeLogs[0].quantity || 0;
          }
      }

      if (!earliestDate || earliestDate === 'N/A') return { ...p, daysRemaining: null, relevantBatch, relevantQty };
      
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const exp = new Date(earliestDate);
      const diffTime = exp.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return { ...p, daysRemaining: diffDays, relevantBatch, relevantQty };
    })
    .filter(p => p.daysRemaining !== null && p.daysRemaining <= 30)
    .sort((a, b) => (a.daysRemaining as number) - (b.daysRemaining as number))
    .slice(0, 4);

  const QuickActionCard = ({ title, icon: Icon, color, onClick }: any) => (
    <button 
      onClick={onClick}
      className="flex flex-col items-center justify-center p-6 bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 hover:shadow-md hover:border-blue-300 dark:hover:border-blue-700 transition-all duration-200 group"
    >
      <div className={`p-4 rounded-full mb-3 ${color} group-hover:scale-110 transition-transform`}>
        <Icon size={28} className="text-white" />
      </div>
      <span className="font-semibold text-gray-700 dark:text-gray-200 text-sm">{title}</span>
    </button>
  );

  return (
    <div className="p-6 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors duration-300">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{t('Command Center', '指挥中心')}</h1>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">{t('Real-time overview of warehouse operations', '仓库运营实时概览')}</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl shadow-sm border border-gray-100 dark:border-slate-800 flex items-center justify-between transition-colors">
          <div>
            <p className="text-gray-500 dark:text-gray-400 text-xs uppercase font-semibold">{t('Total Stock', '总库存')}</p>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{stats.totalProducts} <span className="text-sm font-normal text-gray-400">{t('SKUs', 'SKU数')}</span></h3>
          </div>
          <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg text-blue-600 dark:text-blue-400">
            <Package size={24} />
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl shadow-sm border border-gray-100 dark:border-slate-800 flex items-center justify-between transition-colors">
          <div>
            <p className="text-gray-500 dark:text-gray-400 text-xs uppercase font-semibold">{t('Capacity', '库容率')}</p>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{stats.warehouseCapacity}%</h3>
          </div>
          <div className={`p-3 rounded-lg ${stats.warehouseCapacity > 90 ? 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400' : 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400'}`}>
            <TrendingUp size={24} />
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl shadow-sm border border-gray-100 dark:border-slate-800 flex items-center justify-between transition-colors">
          <div>
            <p className="text-gray-500 dark:text-gray-400 text-xs uppercase font-semibold">{t('Inbound (Today)', '今日入库')}</p>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{stats.totalInboundToday}</h3>
          </div>
          <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg text-purple-600 dark:text-purple-400">
            <ArrowDownToLine size={24} />
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl shadow-sm border border-gray-100 dark:border-slate-800 flex items-center justify-between transition-colors">
          <div>
            <p className="text-gray-500 dark:text-gray-400 text-xs uppercase font-semibold">{t('Low Stock Alerts', '低库存预警')}</p>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{stats.lowStockItems}</h3>
          </div>
          <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-lg text-yellow-600 dark:text-yellow-400">
            <AlertTriangle size={24} />
          </div>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">{t('Quick Actions', '快捷操作')}</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <QuickActionCard title={t('SCAN TO SHELF', '扫码上架')} icon={Scan} color="bg-blue-600" onClick={() => onNavigate(ViewState.SCAN_TO_SHELF)} />
          <QuickActionCard title={t('INBOUND', '快速入库')} icon={ArrowDownToLine} color="bg-indigo-500" onClick={() => onNavigate(ViewState.INBOUND)} />
          <QuickActionCard title={t('INVENTORY CHECK', '库存盘点')} icon={ClipboardCheck} color="bg-emerald-500" onClick={() => onNavigate(ViewState.INVENTORY_PRODUCT)} />
          <QuickActionCard title={t('SKU LOOKUP', 'SKU 查询')} icon={Tag} color="bg-orange-500" onClick={() => onNavigate(ViewState.SKU_LOOKUP)} />
          <QuickActionCard title={t('EXPIRE UPDATE', '效期更新')} icon={Clock} color="bg-red-500" onClick={() => onNavigate(ViewState.INVENTORY_EXPIRE)} />
        </div>
      </div>

      {/* Main Grid: Charts & Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col transition-colors">
          <h3 className="font-semibold text-gray-800 dark:text-white mb-6">{t('Weekly Throughput', '本周吞吐量')}</h3>
          <div className="relative w-full h-[300px] min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? "#334155" : "#f0f0f0"} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: 'none', backgroundColor: isDark ? '#1e293b' : '#fff', color: isDark ? '#fff' : '#000', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'}}
                  cursor={{fill: isDark ? '#334155' : '#f9fafb'}}
                />
                <Bar dataKey="inbound" name="Inbound" fill="#818cf8" radius={[4, 4, 0, 0]} />
                <Bar dataKey="outbound" name="Outbound" fill="#34d399" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl shadow-sm border border-red-100 dark:border-red-900/30 relative overflow-hidden transition-colors">
             <div className="absolute -top-4 -right-4 p-4 opacity-5 dark:opacity-10 pointer-events-none">
                <AlertTriangle size={120} className="text-red-600 dark:text-red-500" />
             </div>
             <div className="flex items-center gap-2 mb-4 relative z-10">
                <AlertCircle className="text-red-500" size={20} />
                <h3 className="font-bold text-gray-800 dark:text-white">{t('Expiring Soon', '临期提醒')}</h3>
             </div>
             <div className="space-y-3 relative z-10">
                {expiringProducts.length > 0 ? (
                    expiringProducts.map(p => {
                        const days = p.daysRemaining as number;
                        const isExpired = days < 0;
                        return (
                            <div key={p.id} className="group relative flex items-center justify-between p-3 bg-red-50/50 dark:bg-red-900/10 rounded-lg border border-red-100 dark:border-red-900/30 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all cursor-default">
                                <div className="overflow-hidden mr-2">
                                    <p className="font-semibold text-gray-800 dark:text-gray-200 text-sm truncate" title={p.name}>{p.name}</p>
                                    <p className="text-xs text-gray-500 dark:text-gray-500 font-mono">{p.sku}</p>
                                </div>
                                <div className={`text-right flex-shrink-0 ${isExpired ? 'text-red-700 dark:text-red-400' : 'text-orange-600 dark:text-orange-400'}`}>
                                    <span className="text-[10px] block font-bold uppercase opacity-80">{isExpired ? t('Expired', '已过期') : t('Expires in', '剩余')}</span>
                                    <div className="leading-none">
                                      <span className="text-lg font-bold tabular-nums">{Math.abs(days)}</span>
                                      <span className="text-[10px] ml-1 font-medium">{t('days', '天')}</span>
                                    </div>
                                </div>
                                <div className="absolute inset-0 bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-lg border border-red-200 dark:border-red-800 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-between px-4 z-20 shadow-sm pointer-events-none">
                                    <div className="text-left">
                                        <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase">{t('Batch', '批次')}</p>
                                        <p className="font-mono text-sm text-gray-800 dark:text-gray-200 font-bold">{p.relevantBatch}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase">{t('Qty', '数量')}</p>
                                        <p className="font-mono text-sm text-gray-800 dark:text-gray-200 font-bold">{p.relevantQty}</p>
                                    </div>
                                </div>
                            </div>
                        );
                    })
                ) : (
                    <div className="text-center py-6 text-gray-400 bg-gray-50 dark:bg-slate-800/50 rounded-lg border border-gray-100 dark:border-slate-800 border-dashed">
                        <ClipboardCheck size={32} className="mx-auto mb-2 opacity-50" />
                        <p className="text-xs font-medium">{t('No items expiring soon', '暂无临期商品')}</p>
                    </div>
                )}
             </div>
             {expiringProducts.length > 0 && (
                 <button onClick={() => onNavigate(ViewState.INVENTORY_EXPIRE)} className="w-full mt-4 text-xs font-semibold text-red-600 dark:text-red-400 hover:text-red-700 py-2 border border-red-100 dark:border-red-900/30 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors relative z-10">
                    {t('View All Expiring Items', '查看所有临期商品')}
                 </button>
             )}
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 transition-colors">
            <h3 className="font-semibold text-gray-800 dark:text-white mb-4">{t('Recent Activity', '近期活动')}</h3>
            <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 no-scrollbar">
              {transactions.length > 0 ? (
                transactions.slice(0, 5).map((t) => (
                  <div key={t.id} className="flex gap-3 pb-3 border-b border-gray-50 dark:border-slate-800 last:border-0">
                    <div className={`mt-1 min-w-[8px] h-2 rounded-full ${t.type === 'INBOUND' ? 'bg-purple-500' : t.type === 'OUTBOUND' ? 'bg-green-500' : 'bg-blue-500'}`} />
                    <div>
                      <p className="text-sm font-medium text-gray-800 dark:text-gray-200">{t.type === 'TRANSFER' ? 'Item Moved' : t.type}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{t.productName}{t.toLocation && <span className="text-gray-400"> → {t.toLocation}</span>}</p>
                      <p className="text-[10px] text-gray-400 mt-1">{new Date(t.timestamp).toLocaleDateString('en-GB')} {new Date(t.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} • {t.user}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-400 italic text-center py-4">{t('No recent activity.', '暂无活动记录')}</p>
              )}
            </div>
            <button className="w-full mt-4 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 py-2 border border-blue-100 dark:border-slate-800 rounded-lg hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors">{t('View All Logs', '查看所有日志')}</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

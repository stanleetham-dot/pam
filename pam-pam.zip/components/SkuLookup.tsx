
import React, { useState, useEffect, useRef } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    Search, Scan, Package, MapPin, Box, Info, Calendar, 
    DollarSign, Tag, Archive, Clock, AlertCircle, CheckCircle2,
    Hash, Factory, Layers, AlertTriangle, XCircle, ArrowRight,
    History, Hourglass
} from 'lucide-react';
import { Product } from '../types';
import Scanner from './Scanner';

interface SkuLookupProps {
  onClose?: () => void;
}

const DetailRow: React.FC<{ label: string; value: string | number | React.ReactNode; icon?: React.ElementType }> = ({ label, value, icon: Icon }) => (
  <div className="flex items-start py-3 border-b border-gray-100 dark:border-slate-800 last:border-0 group hover:bg-gray-50/50 dark:hover:bg-slate-800/30 transition-colors px-2 rounded-lg">
    <div className="flex items-center gap-2 w-1/3 min-w-[120px] text-gray-500 dark:text-gray-400 font-medium text-sm">
        {Icon && <Icon size={14} className="text-gray-400 dark:text-gray-500" />}
        {label}
    </div>
    <div className="flex-1 text-gray-900 dark:text-gray-100 font-medium text-sm text-right break-words">
      {value || <span className="text-gray-400 dark:text-gray-600 italic">-</span>}
    </div>
  </div>
);

const SkuLookup: React.FC<SkuLookupProps> = ({ onClose }) => {
  const { searchProduct, currentUser } = useInventory();
  const [query, setQuery] = useState('');
  const [product, setProduct] = useState<Product | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [animationClass, setAnimationClass] = useState('');
  const [activeTab, setActiveTab] = useState<'DETAILS' | 'LOGS'>('DETAILS');
  
  const inputRef = useRef<HTMLInputElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    // Auto-focus input on mount
    inputRef.current?.focus();
  }, []);

  const playSound = (type: 'success' | 'error') => {
    try {
        if (!audioContextRef.current) {
            const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
            if (AudioContext) audioContextRef.current = new AudioContext();
        }
        const ctx = audioContextRef.current;
        if (!ctx) return;
        if (ctx.state === 'suspended') ctx.resume();
        
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        const now = ctx.currentTime;
        if (type === 'success') {
            osc.frequency.setValueAtTime(800, now);
            osc.frequency.exponentialRampToValueAtTime(1200, now + 0.1);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        } else {
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(200, now);
            osc.frequency.linearRampToValueAtTime(150, now + 0.2);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        }
        osc.start(now);
        osc.stop(now + 0.3);
    } catch (e) {
        console.error("Audio error", e);
    }
  };

  const handleSearch = (searchVal: string) => {
    const trimmed = searchVal.trim();
    setQuery(trimmed);
    if (!trimmed) return;

    const found = searchProduct(trimmed);
    if (found) {
        setProduct(found);
        setError(null);
        setActiveTab('DETAILS');
        playSound('success');
        setAnimationClass('animate-in fade-in zoom-in-95 duration-300');
    } else {
        setProduct(null);
        setError(`Product not found: ${trimmed}`);
        playSound('error');
        setAnimationClass('animate-subtle-shake');
        setTimeout(() => setAnimationClass(''), 500);
    }
  };

  const onManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(query);
  };

  const getDaysRemaining = (dateStr: string) => {
      if (!dateStr || dateStr === 'N/A') return null;
      const today = new Date();
      today.setHours(0,0,0,0);
      const exp = new Date(dateStr);
      if (isNaN(exp.getTime())) return null;
      const diffTime = exp.getTime() - today.getTime();
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr || dateStr === 'N/A') return 'N/A';
    try {
        const d = new Date(dateStr);
        return d.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
    } catch { return dateStr; }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 p-4 md:p-8 font-sans transition-colors duration-300">
      <style>{`
        @keyframes subtle-shake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-4px); }
          40% { transform: translateX(4px); }
          60% { transform: translateX(-2px); }
          80% { transform: translateX(2px); }
        }
        .animate-subtle-shake {
          animation: subtle-shake 0.3s ease-in-out;
        }
      `}</style>

      {isScannerOpen && (
        <Scanner 
            onScan={(code) => {
                setQuery(code);
                handleSearch(code);
                setIsScannerOpen(false);
            }} 
            onClose={() => setIsScannerOpen(false)} 
            title="Scan SKU / QR Code"
            type="product"
        />
      )}

      {/* Header */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
            <Tag className="text-blue-600 dark:text-blue-400" />
            SKU Lookup
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Quickly access product details and history</p>
        </div>
        {onClose && (
            <button onClick={onClose} className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-gray-200 dark:border-slate-800 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
                <ArrowRight className="rotate-180" size={20} />
            </button>
        )}
      </div>

      <div className="flex-1 max-w-5xl mx-auto w-full flex flex-col gap-6">
        
        {/* Search Bar */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 transition-colors">
            <form onSubmit={onManualSubmit} className="flex gap-3">
                <div className="relative flex-1">
                    <input 
                        ref={inputRef}
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-4 focus:ring-blue-100 dark:focus:ring-blue-900/20 focus:border-blue-500 outline-none text-lg font-medium text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-600 transition-all"
                        placeholder="Scan or enter Barcode/SKU/Name..."
                    />
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={20} />
                </div>
                <button 
                    type="button"
                    onClick={() => setIsScannerOpen(true)}
                    className="bg-blue-600 text-white px-6 rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 dark:shadow-none flex items-center gap-2 font-bold active:scale-95"
                >
                    <Scan size={20} /> <span className="hidden sm:inline">Scan</span>
                </button>
            </form>
            
            {error && (
                <div className={`mt-3 flex items-center gap-2 text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 px-4 py-2 rounded-lg border border-red-100 dark:border-red-900/30 text-sm font-medium ${animationClass}`}>
                    <AlertCircle size={16} /> {error}
                </div>
            )}
        </div>

        {/* Product Result */}
        {product ? (
            <div className={`flex flex-col md:flex-row gap-6 ${animationClass}`}>
                
                {/* Left Column: Product Identity & Quick Stats */}
                <div className="w-full md:w-1/3 flex flex-col gap-4">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden transition-colors">
                        <div className="p-6 flex flex-col items-center text-center border-b border-gray-100 dark:border-slate-800 bg-gradient-to-b from-white to-gray-50 dark:from-slate-900 dark:to-slate-900/50">
                            <div className="w-40 h-40 bg-white dark:bg-slate-800 rounded-2xl border border-gray-200 dark:border-slate-700 shadow-sm flex items-center justify-center overflow-hidden mb-4 relative group transition-colors">
                                {product.imageUrl ? (
                                    <img src={product.imageUrl} className="w-full h-full object-cover" alt="Product" />
                                ) : (
                                    <Package size={64} className="text-gray-300 dark:text-slate-700" />
                                )}
                                <div className="absolute top-2 right-2">
                                    <span className={`flex h-3 w-3 rounded-full ${
                                        product.stock > 20 ? 'bg-green-500' : product.stock > 0 ? 'bg-orange-500' : 'bg-red-500'
                                    }`}></span>
                                </div>
                            </div>
                            <h2 className="text-xl font-bold text-gray-900 dark:text-white leading-tight mb-2">{product.name}</h2>
                            <span className="inline-flex items-center gap-1.5 bg-gray-100 dark:bg-slate-800 px-3 py-1 rounded-full text-xs font-bold text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-slate-700">
                                <Scan size={12} /> {product.barcode}
                            </span>
                        </div>
                        <div className="grid grid-cols-2 divide-x divide-gray-100 dark:divide-slate-800 border-b border-gray-100 dark:border-slate-800">
                            <div className="p-4 text-center hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
                                <p className="text-xs text-gray-500 dark:text-gray-500 font-bold uppercase mb-1">Stock</p>
                                <p className="text-xl font-bold text-gray-900 dark:text-white">{product.stock} <span className="text-sm font-normal text-gray-500">{product.unit}</span></p>
                            </div>
                            <div className="p-4 text-center hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
                                <p className="text-xs text-gray-500 dark:text-gray-500 font-bold uppercase mb-1">Price</p>
                                <p className="text-xl font-bold text-blue-600 dark:text-blue-400">${product.standardPrice.toFixed(2)}</p>
                            </div>
                        </div>
                        <div className="p-4 bg-blue-50/50 dark:bg-blue-900/10 text-center">
                            <p className="text-xs text-blue-600 dark:text-blue-400 font-bold uppercase mb-1">Location Shelf</p>
                            <p className="text-2xl font-mono font-bold text-blue-800 dark:text-blue-300 tracking-wide">{product.location}</p>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-4 transition-colors">
                        <h4 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase mb-3">System Info</h4>
                        <div className="space-y-3">
                            <div className="flex justify-between text-sm">
                                <span className="text-gray-500 dark:text-gray-400">Created</span>
                                <span className="font-medium text-gray-900 dark:text-gray-200">{new Date(product.createdAt).toLocaleDateString('en-GB')}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-gray-500 dark:text-gray-400">Last Update</span>
                                <span className="font-medium text-gray-900 dark:text-gray-200">{new Date(product.updatedAt).toLocaleDateString('en-GB')}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-gray-500 dark:text-gray-400">Updated By</span>
                                <span className="font-medium text-gray-900 dark:text-gray-200">{product.updatedBy || 'System'}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right Column: Details & Logs */}
                <div className="flex-1 bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col overflow-hidden min-h-[500px] transition-colors">
                    <div className="flex border-b border-gray-200 dark:border-slate-800">
                        <button 
                            onClick={() => setActiveTab('DETAILS')}
                            className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-all ${activeTab === 'DETAILS' ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/30 dark:bg-blue-900/10' : 'border-transparent text-gray-500 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800/50'}`}
                        >
                            <Info size={16} /> Product Details
                        </button>
                        <button 
                            onClick={() => setActiveTab('LOGS')}
                            className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-all ${activeTab === 'LOGS' ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/30 dark:bg-blue-900/10' : 'border-transparent text-gray-500 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800/50'}`}
                        >
                            <History size={16} /> Expiry Logs
                            {product.expiryLogs && product.expiryLogs.length > 0 && (
                                <span className="bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400 px-1.5 py-0.5 rounded-full text-[10px] border border-gray-200 dark:border-slate-700">
                                    {product.expiryLogs.length}
                                </span>
                            )}
                        </button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-6 bg-gray-50/30 dark:bg-slate-950/20">
                        {activeTab === 'DETAILS' ? (
                            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
                                <div>
                                    <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2"><Tag size={16} className="text-blue-500 dark:text-blue-400"/> General Information</h4>
                                    <div className="bg-white dark:bg-slate-900 rounded-xl border border-gray-200 dark:border-slate-800 p-4 shadow-sm transition-colors">
                                        <DetailRow label="SKU Code" value={product.sku} icon={Hash} />
                                        <DetailRow label="Category" value={product.category} icon={Layers} />
                                        <DetailRow label="Brand" value={product.brand} icon={Tag} />
                                        <DetailRow label="Origin" value={product.origin} icon={MapPin} />
                                        <DetailRow label="Specification" value={product.specification} icon={Box} />
                                    </div>
                                </div>

                                <div>
                                    <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2"><DollarSign size={16} className="text-green-500 dark:text-green-400"/> Pricing & Cost</h4>
                                    <div className="bg-white dark:bg-slate-900 rounded-xl border border-gray-200 dark:border-slate-800 p-4 shadow-sm transition-colors">
                                        <DetailRow label="Standard Price" value={`$${product.standardPrice.toFixed(2)}`} />
                                        <DetailRow label="Wholesale Price" value={`$${product.wholesalePrice.toFixed(2)}`} />
                                        {(currentUser?.role === 'ADMIN' || currentUser?.role === 'INSPECTOR') && (
                                            <DetailRow label="Purchase Price" value={`$${product.purchasePrice.toFixed(2)}`} />
                                        )}
                                    </div>
                                </div>

                                <div>
                                    <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2"><Calendar size={16} className="text-orange-500 dark:text-orange-400"/> Shelf Life & Expiry</h4>
                                    <div className="bg-white dark:bg-slate-900 rounded-xl border border-gray-200 dark:border-slate-800 p-4 shadow-sm transition-colors">
                                        <DetailRow label="Primary Expiry" value={formatDate(product.expiryDate)} icon={Calendar} />
                                        <DetailRow label="Mfg Date" value={product.mfgDate} icon={Factory} />
                                        <DetailRow label="Shelf Life" value={product.shelfLife ? `${product.shelfLife} Months` : ''} icon={Hourglass} />
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="animate-in fade-in slide-in-from-bottom-2 h-full flex flex-col">
                                {product.expiryLogs && product.expiryLogs.length > 0 ? (
                                    <div className="bg-white dark:bg-slate-900 rounded-xl border border-gray-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
                                        <table className="w-full text-left text-sm">
                                            <thead className="bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800 text-gray-500 dark:text-gray-400 font-bold uppercase text-xs">
                                                <tr>
                                                    <th className="px-4 py-3">Status</th>
                                                    <th className="px-4 py-3">Batch #</th>
                                                    <th className="px-4 py-3">Expiry Date</th>
                                                    <th className="px-4 py-3 text-right">Qty</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                                                {product.expiryLogs.map(log => {
                                                    const daysLeft = getDaysRemaining(log.expiryDate);
                                                    const isExpired = daysLeft !== null && daysLeft < 0;
                                                    const isUrgent = daysLeft !== null && daysLeft >= 0 && daysLeft <= 14;
                                                    
                                                    return (
                                                        <tr key={log.id} className="hover:bg-gray-50 dark:hover:bg-slate-800/50 transition-colors">
                                                            <td className="px-4 py-3">
                                                                {log.status === 'REMOVED' ? (
                                                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-slate-700">
                                                                        <Archive size={10} /> Removed
                                                                    </span>
                                                                ) : isExpired ? (
                                                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-900/50">
                                                                        <XCircle size={10} /> Expired
                                                                    </span>
                                                                ) : isUrgent ? (
                                                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 border border-orange-200 dark:border-orange-900/50">
                                                                        <Clock size={10} /> Urgent
                                                                    </span>
                                                                ) : (
                                                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 border border-green-200 dark:border-green-900/50">
                                                                        <CheckCircle2 size={10} /> Active
                                                                    </span>
                                                                )}
                                                            </td>
                                                            <td className="px-4 py-3 font-mono text-gray-600 dark:text-gray-400">{log.batchNumber || '-'}</td>
                                                            <td className="px-4 py-3">
                                                                <div className="font-medium text-gray-800 dark:text-gray-100">{formatDate(log.expiryDate)}</div>
                                                                {log.status === 'ACTIVE' && !isExpired && (
                                                                    <div className="text-[10px] text-gray-400 dark:text-gray-500">{daysLeft} days left</div>
                                                                )}
                                                            </td>
                                                            <td className="px-4 py-3 text-right font-bold text-gray-700 dark:text-gray-300">{log.quantity}</td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : (
                                    <div className="flex flex-col items-center justify-center h-64 text-gray-400 dark:text-slate-700">
                                        <History size={48} className="mb-3 opacity-20" />
                                        <p className="font-medium">No expiry history found.</p>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        ) : (
            // Empty State
            !query && (
                <div className="flex-1 flex flex-col items-center justify-center text-gray-400 dark:text-slate-700 opacity-60">
                    <Scan size={64} className="mb-4 stroke-1" />
                    <p className="text-lg">Ready for lookup</p>
                </div>
            )
        )}
      </div>
    </div>
  );
};

export default SkuLookup;


import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useInventory } from '../context/InventoryContext';
import { Driver, DistributionOrder } from '../types';
import { 
    Truck, MapPin, Search, User, 
    Square, X, Save, 
    CheckSquare, Navigation,
    FileText, UserMinus, RotateCcw,
    LocateFixed, AlertTriangle, ShieldCheck, Loader2, Globe, Calendar, Clock,
    Map as MapIcon, Layers, Phone, Car, Users, Bike, Plus
} from 'lucide-react';
import L from 'leaflet';
import { GoogleGenAI, Type } from "@google/genai";

// Haversine formula to calculate distance between two coordinates in meters
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
}

// Leaflet Map Component
const LeafletMap = ({ orders, drivers, onPinClick, selectedOrderIds, selectedDriverId }: { orders: DistributionOrder[], drivers: Driver[], onPinClick: (id: string) => void, selectedOrderIds: Set<string>, selectedDriverId: string | null }) => {
    const mapContainerRef = useRef<HTMLDivElement>(null);
    const mapInstanceRef = useRef<L.Map | null>(null);
    const tileLayerRef = useRef<L.TileLayer | null>(null);
    const labelsLayerRef = useRef<L.TileLayer | null>(null);
    const layersRef = useRef<Record<string, L.Layer>>({}); // Track layers by ID to update instead of redraw
    const onPinClickRef = useRef(onPinClick); // Ref to avoid stale closures in event listeners
    const { theme } = useInventory();
    const [mapLayer, setMapLayer] = useState<'standard' | 'satellite'>('standard');
    
    // Update ref when prop changes
    useEffect(() => { onPinClickRef.current = onPinClick; }, [onPinClick]);

    // Store driver positions locally for smooth animation
    const [driverPositions, setDriverPositions] = useState<Record<string, { lat: number; lng: number }>>({});

    // Initialize driver start positions
    useEffect(() => {
        setDriverPositions(prev => {
            const next = { ...prev };
            drivers.forEach(d => {
                if (!next[d.id]) {
                    next[d.id] = {
                        lat: 1.3521 + (Math.random() - 0.5) * 0.05,
                        lng: 103.8198 + (Math.random() - 0.5) * 0.05
                    };
                }
            });
            return next;
        });
    }, [drivers]); 

    // Simulation Loop: Move drivers towards assigned order
    useEffect(() => {
        const interval = setInterval(() => {
            setDriverPositions(prev => {
                const next = { ...prev };
                let hasChanges = false;
                drivers.forEach(driver => {
                    if (!next[driver.id]) return;
                    
                    const assignedOrder = orders.find(o => 
                        o.assignedDriverId === driver.id && 
                        o.deliveryDetails?.latitude && 
                        o.status !== 'Delivered'
                    );
                    
                    const currentPos = next[driver.id];
                    let targetLat = currentPos.lat;
                    let targetLng = currentPos.lng;
                    let speed = 0.0000; 
                    
                    // If assigned an order with coords, move towards it
                    if (assignedOrder && assignedOrder.deliveryDetails?.latitude && assignedOrder.deliveryDetails?.longitude) {
                        targetLat = assignedOrder.deliveryDetails.latitude;
                        targetLng = assignedOrder.deliveryDetails.longitude;
                        speed = 0.0003; 
                    }
                    
                    const dist = Math.sqrt(Math.pow(targetLat - currentPos.lat, 2) + Math.pow(targetLng - currentPos.lng, 2));
                    if (dist > 0.0005 && speed > 0) {
                        const angle = Math.atan2(targetLat - currentPos.lat, targetLng - currentPos.lng);
                        const noise = (Math.random() - 0.5) * 0.00005;
                        next[driver.id] = {
                            lat: currentPos.lat + Math.sin(angle) * speed + noise,
                            lng: currentPos.lng + Math.cos(angle) * speed + noise
                        };
                        hasChanges = true;
                    }
                });
                return hasChanges ? next : prev;
            });
        }, 1000);
        return () => clearInterval(interval);
    }, [orders, drivers]);

    // Initialize Map
    useEffect(() => {
        if (!mapContainerRef.current || mapInstanceRef.current) return;

        const map = L.map(mapContainerRef.current, {
            center: [1.3521, 103.8198],
            zoom: 12,
            zoomControl: false,
            attributionControl: false
        });

        L.control.zoom({ position: 'bottomright' }).addTo(map);
        mapInstanceRef.current = map;

        // Force a resize calculation after mount to prevent grey tiles
        setTimeout(() => {
            map.invalidateSize();
        }, 100);

        return () => {
            map.remove();
            mapInstanceRef.current = null;
        };
    }, []);

    // Handle Theme/Tile Layer Changes
    useEffect(() => {
        if (!mapInstanceRef.current) return;

        if (tileLayerRef.current) tileLayerRef.current.remove();
        if (labelsLayerRef.current) labelsLayerRef.current.remove();

        let url = '';
        let options: L.TileLayerOptions = {
            maxZoom: 19,
            subdomains: 'abcd',
        };

        if (mapLayer === 'satellite') {
            // Satellite (Esri World Imagery)
            url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
            options.attribution = 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community';
        } else {
            // Standard (CartoDB)
            url = theme === 'dark' 
                ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png' 
                : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
            options.attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>';
        }

        tileLayerRef.current = L.tileLayer(url, options).addTo(mapInstanceRef.current);

        // Add labels overlay for satellite view to make it usable
        if (mapLayer === 'satellite') {
            const labelsUrl = theme === 'dark' 
                ? 'https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png'
                : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png';
                
            labelsLayerRef.current = L.tileLayer(labelsUrl, {
                subdomains: 'abcd',
                maxZoom: 19,
                zIndex: 600 // High z-index to stay on top
            }).addTo(mapInstanceRef.current);
        }

    }, [theme, mapLayer]);

    // Auto-Focus / Bounds Fitting Effect
    useEffect(() => {
        if (!mapInstanceRef.current) return;
        
        // Prioritize Driver Selection
        if (selectedDriverId && driverPositions[selectedDriverId]) {
             const pos = driverPositions[selectedDriverId];
             mapInstanceRef.current.flyTo([pos.lat, pos.lng], 15, { animate: true });
             return;
        }

        if (selectedOrderIds.size === 1) {
            const orderId = Array.from(selectedOrderIds)[0];
            const order = orders.find(o => o.id === orderId);
            
            if (order && order.deliveryDetails?.latitude && order.deliveryDetails?.longitude) {
                const bounds = L.latLngBounds([
                    [order.deliveryDetails.latitude, order.deliveryDetails.longitude]
                ]);

                if (order.assignedDriverId && driverPositions[order.assignedDriverId]) {
                    const driverPos = driverPositions[order.assignedDriverId];
                    bounds.extend([driverPos.lat, driverPos.lng]);
                    mapInstanceRef.current.fitBounds(bounds, { padding: [100, 100], maxZoom: 15, animate: true });
                } else {
                    mapInstanceRef.current.flyTo([order.deliveryDetails.latitude, order.deliveryDetails.longitude], 15, { animate: true });
                }
            }
        }
    }, [selectedOrderIds, selectedDriverId]); 

    // Efficiently Update Markers & Routes (Diffing)
    useEffect(() => {
        if (!mapInstanceRef.current) return;
        const map = mapInstanceRef.current;
        const activeIds = new Set<string>();

        // 1. Order Pins
        orders.forEach(order => {
            if (order.deliveryDetails?.latitude && order.deliveryDetails?.longitude) {
                const id = `order-${order.id}`;
                activeIds.add(id);

                const isSelected = selectedOrderIds.has(order.id);
                const isAssigned = !!order.assignedDriverId;
                const isGeofenceOk = order.geofenceVerified;
                
                const baseColor = isGeofenceOk ? '#10b981' : isAssigned ? '#2563eb' : '#64748b';
                const color = isSelected ? '#f59e0b' : baseColor;
                const scale = isSelected ? 1.3 : 1;
                const zIndex = isSelected ? 1000 : 500;

                const svg = `
                    <svg xmlns="http://www.w3.org/2000/svg" width="${32 * scale}" height="${32 * scale}" viewBox="0 0 24 24" fill="${color}" stroke="white" stroke-width="2" filter="drop-shadow(0px 2px 2px rgba(0,0,0,0.3))">
                        <path d="M12 0C7.58 0 4 3.58 4 8c0 5.25 7 13 7 13s7-7.75 7-13c0-4.42-3.58-8-8-8zm0 11c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3z"/>
                    </svg>
                `;

                const icon = L.divIcon({
                    html: isSelected 
                        ? `<div class="animate-bounce relative top-[-10px]">${svg}</div>` 
                        : svg,
                    className: 'custom-leaflet-icon',
                    iconSize: [32 * scale, 32 * scale],
                    iconAnchor: [16 * scale, 32 * scale],
                });

                if (layersRef.current[id]) {
                    // Update existing marker
                    const marker = layersRef.current[id] as L.Marker;
                    marker.setLatLng([order.deliveryDetails.latitude, order.deliveryDetails.longitude]);
                    marker.setIcon(icon);
                    marker.setZIndexOffset(zIndex);
                } else {
                    // Create new marker
                    const marker = L.marker([order.deliveryDetails.latitude, order.deliveryDetails.longitude], { 
                        icon,
                        zIndexOffset: zIndex
                    }).addTo(map);
                    
                    marker.on('click', () => {
                        if (onPinClickRef.current) onPinClickRef.current(order.id);
                    });
                    
                    layersRef.current[id] = marker;
                }
            }
        });

        // 2. Drivers and Routes
        drivers.forEach(driver => {
            const pos = driverPositions[driver.id];
            if (!pos) return;

            const isDriverSelected = selectedDriverId === driver.id;
            const assignedOrder = orders.find(o => o.assignedDriverId === driver.id && o.status !== 'Delivered' && o.deliveryDetails?.latitude);
            const isOrderSelected = assignedOrder ? selectedOrderIds.has(assignedOrder.id) : false;
            
            // Show route if order is selected OR driver is selected and has an order
            const showRoute = (isOrderSelected || isDriverSelected) && assignedOrder;
            
            if (showRoute && assignedOrder && assignedOrder.deliveryDetails?.latitude && assignedOrder.deliveryDetails?.longitude) {
                const routeId = `route-${driver.id}`;
                activeIds.add(routeId);

                const latlngs: L.LatLngExpression[] = [
                    [pos.lat, pos.lng],
                    [assignedOrder.deliveryDetails.latitude, assignedOrder.deliveryDetails.longitude]
                ];

                if (layersRef.current[routeId]) {
                    const polyline = layersRef.current[routeId] as L.Polyline;
                    polyline.setLatLngs(latlngs);
                    polyline.setStyle({
                        color: '#f59e0b',
                        weight: 4,
                        dashArray: '10, 10',
                        opacity: 1,
                        className: 'moving-dash-path'
                    });
                } else {
                    const polyline = L.polyline(latlngs, {
                        color: '#f59e0b',
                        weight: 4,
                        opacity: 1,
                        className: 'moving-dash-path',
                        lineCap: 'round'
                    }).addTo(map);
                    layersRef.current[routeId] = polyline;
                }
            }

            // -- Driver Marker --
            const driverId = `driver-${driver.id}`;
            activeIds.add(driverId);

            const driverColor = isDriverSelected ? '#f59e0b' : assignedOrder ? '#22c55e' : '#94a3b8';
            const driverSvg = `
                <div style="transform: rotate(0deg); transition: transform 0.3s; cursor: pointer;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 24 24" fill="${driverColor}" stroke="white" stroke-width="1.5" filter="drop-shadow(0px 3px 3px rgba(0,0,0,0.3))">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M17 8h-8a2 2 0 0 0-2 2v6h2v2h2v-2h4v2h2v-2h2v-6a2 2 0 0 0-2-2zm-8 2h8v3h-8v-3z" fill="white" />
                    </svg>
                </div>
            `;

            const driverIcon = L.divIcon({
                html: isDriverSelected 
                    ? `<div class="animate-bounce relative top-[-5px]">${driverSvg}</div>`
                    : driverSvg,
                className: 'custom-driver-icon',
                iconSize: [44, 44],
                iconAnchor: [22, 22]
            });

            let marker: L.Marker;
            if (layersRef.current[driverId]) {
                marker = layersRef.current[driverId] as L.Marker;
                marker.setLatLng([pos.lat, pos.lng]);
                marker.setIcon(driverIcon);
                marker.setZIndexOffset(isDriverSelected ? 9999 : 900);
            } else {
                marker = L.marker([pos.lat, pos.lng], { 
                    icon: driverIcon,
                    zIndexOffset: 900
                }).addTo(map);
                
                marker.bindTooltip(driver.name, { 
                    direction: 'top', 
                    offset: [0, -20], 
                    permanent: false,
                    className: 'driver-tooltip'
                });
                
                layersRef.current[driverId] = marker;
            }

            if (isDriverSelected) {
                marker.openTooltip();
            } else {
                marker.closeTooltip();
            }
        });

        // Cleanup: Remove layers that are no longer active
        Object.keys(layersRef.current).forEach(key => {
            if (!activeIds.has(key)) {
                layersRef.current[key].remove();
                delete layersRef.current[key];
            }
        });

    }, [orders, drivers, driverPositions, selectedOrderIds, selectedDriverId]);

    return (
        <div className="relative w-full h-full bg-slate-100 dark:bg-slate-900 rounded-2xl overflow-hidden border border-gray-200 dark:border-slate-800 shadow-inner group/map">
            <style>{`
                .custom-leaflet-icon {
                    background: transparent;
                    border: none;
                }
                .custom-driver-icon {
                    background: transparent;
                    border: none;
                }
                /* Route Animation */
                .moving-dash-path {
                    stroke-dasharray: 12, 12;
                    animation: dash 1s linear infinite;
                }
                @keyframes dash {
                    to {
                        stroke-dashoffset: -24;
                    }
                }
                .driver-tooltip {
                    background: rgba(0,0,0,0.8);
                    border: none;
                    color: white;
                    font-weight: bold;
                    border-radius: 4px;
                    padding: 2px 6px;
                }
                .driver-tooltip::before {
                    border-top-color: rgba(0,0,0,0.8);
                }
            `}</style>
            <div ref={mapContainerRef} className="absolute inset-0 z-0" style={{ height: '100%', width: '100%' }} />
            
            {/* Map Layer Controls */}
            <div className="absolute top-4 right-4 z-[400] flex flex-col gap-2">
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-lg border border-gray-200 dark:border-slate-800 p-1 flex flex-col">
                    <button 
                        onClick={() => setMapLayer('standard')}
                        className={`p-2.5 rounded-lg transition-all ${mapLayer === 'standard' ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400 font-bold' : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-slate-800'}`}
                        title="Standard Map"
                    >
                        <MapIcon size={20} />
                    </button>
                    <button 
                        onClick={() => setMapLayer('satellite')}
                        className={`p-2.5 rounded-lg transition-all ${mapLayer === 'satellite' ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400 font-bold' : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-slate-800'}`}
                        title="Satellite View"
                    >
                        <Globe size={20} />
                    </button>
                </div>
            </div>
        </div>
    );
};

// Assign Driver Modal
const AssignDriverModal: React.FC<{ isOpen: boolean; onClose: () => void; selectedCount: number; drivers: Driver[]; onConfirm: (driverId: string, note: string) => void; }> = ({ isOpen, onClose, selectedCount, drivers, onConfirm }) => {
    const [selectedDriverId, setSelectedDriverId] = useState<string | null>(null);
    const [note, setNote] = useState('');
    if (!isOpen) return null;
    const handleSave = () => { if (!selectedDriverId) { alert('Please select a driver.'); return; } onConfirm(selectedDriverId, note); onClose(); setSelectedDriverId(null); setNote(''); };
    return (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden transition-colors">
                <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50">
                    <div><h3 className="text-xl font-bold text-gray-900 dark:text-white">Choose Driver</h3><p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Assigning <span className="font-bold text-blue-600 dark:text-blue-400">{selectedCount}</span> orders.</p></div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full text-gray-500 dark:text-gray-400 transition-colors"><X size={20} /></button>
                </div>
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    <div className="border border-gray-200 dark:border-slate-700 rounded-xl overflow-hidden shadow-sm">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-50 dark:bg-slate-950 text-gray-500 dark:text-gray-400 font-bold text-xs uppercase border-b border-gray-200 dark:border-slate-800">
                                <tr><th className="px-4 py-3 w-10 text-center">Select</th><th className="px-4 py-3">Driver Name</th><th className="px-4 py-3">Phone</th><th className="px-4 py-3">Vehicle</th><th className="px-4 py-3 text-center">Current Load</th></tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-slate-800 bg-white dark:bg-slate-900">
                                {drivers.map(driver => (
                                    <tr key={driver.id} className={`hover:bg-blue-50/50 dark:hover:bg-blue-900/10 cursor-pointer transition-colors ${selectedDriverId === driver.id ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`} onClick={() => setSelectedDriverId(driver.id)}>
                                        <td className="px-4 py-4 text-center"><div className={`w-5 h-5 rounded border flex items-center justify-center mx-auto transition-all ${selectedDriverId === driver.id ? 'bg-blue-600 border-blue-600 text-white' : 'border-gray-300 dark:border-slate-600'}`}>{selectedDriverId === driver.id && <CheckSquare size={14} />}</div></td>
                                        <td className="px-4 py-4"><div className="flex items-center gap-3"><div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-gray-500 dark:text-gray-400 overflow-hidden border border-gray-200 dark:border-slate-700">{driver.avatar ? <img src={driver.avatar} className="w-full h-full object-cover"/> : driver.name.charAt(0)}</div><span className="font-bold text-gray-900 dark:text-white">{driver.name}</span></div></td>
                                        <td className="px-4 py-4 text-gray-600 dark:text-gray-400 font-mono text-xs">{driver.phone}</td>
                                        <td className="px-4 py-4 text-gray-600 dark:text-gray-400">{driver.vehicleType} {driver.plateNumber && <span className="ml-1 font-mono text-xs bg-gray-100 dark:bg-slate-800 px-1 rounded border border-gray-200 dark:border-slate-700">{driver.plateNumber}</span>}</td>
                                        <td className="px-4 py-4 text-center font-mono font-bold text-blue-600 dark:text-blue-400">{driver.currentPacks || 0}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div><label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-2">Note for Driver</label><textarea className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm font-medium text-gray-900 dark:text-white placeholder:text-gray-400 resize-none" rows={3} value={note} onChange={e => setNote(e.target.value)} placeholder="Gate codes, special handling..." /></div>
                </div>
                <div className="p-6 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-900 rounded-b-2xl flex justify-end gap-3">
                    <button onClick={onClose} className="px-5 py-2.5 text-gray-700 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-xl font-bold transition-colors">Cancel</button>
                    <button onClick={handleSave} className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-none flex items-center gap-2 transition-all active:scale-95"><Save size={18} /> Confirm Assignment</button>
                </div>
            </div>
        </div>
    );
};

// --- DRIVER MANAGEMENT COMPONENTS ---

const DriverModal: React.FC<{ isOpen: boolean; onClose: () => void; driver: Driver | null; onSave: (id: string, data: Partial<Driver>) => void }> = ({ isOpen, onClose, driver, onSave }) => {
    const [formData, setFormData] = useState<Partial<Driver>>({
        name: '',
        phone: '',
        plateNumber: '',
        vehicleType: 'Van',
        deliveryMethods: ['Standard']
    });

    useEffect(() => {
        if (driver) {
            setFormData(driver);
        } else {
            setFormData({ name: '', phone: '', plateNumber: '', vehicleType: 'Van', deliveryMethods: ['Standard'] });
        }
    }, [driver, isOpen]);

    if (!isOpen) return null;

    const handleSave = () => {
        if (!formData.name) return alert("Name is required");
        // For new drivers, we assume user creation happens elsewhere or this updates existing user profile
        // In this context, we are editing driver-specific details for existing users
        if (driver) {
            onSave(driver.id, formData);
        }
        onClose();
    };

    const toggleMethod = (method: string) => {
        setFormData(prev => {
            const current = prev.deliveryMethods || [];
            if (current.includes(method)) return { ...prev, deliveryMethods: current.filter(m => m !== method) };
            return { ...prev, deliveryMethods: [...current, method] };
        });
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-lg shadow-2xl flex flex-col transition-colors overflow-hidden">
                <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">Edit Driver Profile</h3>
                    <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full text-gray-500 transition-colors"><X size={20} /></button>
                </div>
                <div className="p-6 space-y-6">
                    <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-2">Driver Name</label>
                        <input className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-bold text-gray-900 dark:text-white" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-2">Phone Number</label>
                        <input className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-gray-900 dark:text-white" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-2">Vehicle Plate No.</label>
                        <input className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-gray-900 dark:text-white uppercase" value={formData.plateNumber} onChange={e => setFormData({...formData, plateNumber: e.target.value.toUpperCase()})} placeholder="SMA 1234 X"/>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-2">Vehicle Type</label>
                        <div className="grid grid-cols-3 gap-3">
                            {['Van', 'Lorry', 'Bike', 'Car'].map(type => (
                                <button 
                                    key={type}
                                    onClick={() => setFormData({...formData, vehicleType: type as any})}
                                    className={`py-3 rounded-xl text-sm font-bold border transition-all flex flex-col items-center gap-2 ${formData.vehicleType === type ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-500 text-blue-700 dark:text-blue-400' : 'bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-700'}`}
                                >
                                    {type === 'Van' && <Truck size={20}/>}
                                    {type === 'Lorry' && <Truck size={20}/>} 
                                    {type === 'Bike' && <Bike size={20}/>}
                                    {type === 'Car' && <Car size={20}/>}
                                    {type}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-2">Delivery Methods</label>
                        <div className="flex flex-wrap gap-2">
                            {['Standard', 'Express', 'Cold Chain', 'Heavy Cargo'].map(method => (
                                <button
                                    key={method}
                                    onClick={() => toggleMethod(method)}
                                    className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${formData.deliveryMethods?.includes(method) ? 'bg-green-50 dark:bg-green-900/20 border-green-500 text-green-700 dark:text-green-400' : 'bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700 text-gray-500 dark:text-gray-400'}`}
                                >
                                    {method}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
                <div className="p-6 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-900 rounded-b-2xl flex justify-end gap-3">
                    <button onClick={onClose} className="px-5 py-2.5 text-gray-600 dark:text-gray-400 font-bold hover:bg-gray-200 dark:hover:bg-slate-800 rounded-xl transition-colors">Cancel</button>
                    <button onClick={handleSave} className="px-6 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-md transition-all active:scale-95">Save Changes</button>
                </div>
            </div>
        </div>
    );
};

// Compact Driver List for Sidebar
const DriverList: React.FC<{ drivers: Driver[]; onEdit: (d: Driver) => void; selectedId?: string | null; onSelect?: (id: string) => void }> = ({ drivers, onEdit, selectedId, onSelect }) => {
    return (
        <div className="flex flex-col gap-2 p-3">
            {drivers.map(driver => (
                <div 
                    key={driver.id} 
                    className={`p-3 rounded-xl border transition-all cursor-pointer group ${selectedId === driver.id ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 ring-1 ring-blue-200 dark:ring-blue-800' : 'bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700 hover:border-blue-300 dark:hover:border-blue-600'}`}
                    onClick={() => onSelect && onSelect(driver.id)}
                >
                    <div className="flex justify-between items-start mb-2">
                         <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-slate-700 flex items-center justify-center text-sm font-bold text-gray-500 dark:text-gray-300 overflow-hidden border border-gray-200 dark:border-slate-600">
                                {driver.avatar ? <img src={driver.avatar} className="w-full h-full object-cover"/> : driver.name.charAt(0)}
                            </div>
                            <div>
                                <h3 className="font-bold text-gray-900 dark:text-white text-sm">{driver.name}</h3>
                                <div className="flex items-center gap-1.5 mt-0.5">
                                    <span className="text-[10px] bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300 px-1.5 py-0.5 rounded border border-gray-200 dark:border-slate-600">{driver.vehicleType}</span>
                                    {driver.plateNumber && <span className="text-[10px] font-mono font-bold text-gray-500 dark:text-gray-400">{driver.plateNumber}</span>}
                                </div>
                            </div>
                        </div>
                        <button 
                            onClick={(e) => { e.stopPropagation(); onEdit(driver); }} 
                            className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                        >
                            <FileText size={16} />
                        </button>
                    </div>
                    
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100 dark:border-slate-700/50">
                         <div className="flex gap-1">
                            {driver.deliveryMethods.slice(0, 2).map(m => (
                                <span key={m} className="text-[9px] text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-slate-900 px-1.5 py-0.5 rounded">
                                    {m}
                                </span>
                            ))}
                            {driver.deliveryMethods.length > 2 && <span className="text-[9px] text-gray-400 px-1">+{driver.deliveryMethods.length - 2}</span>}
                         </div>
                         <div className="text-xs font-bold text-gray-600 dark:text-gray-400">
                            {driver.currentPacks || 0} Active Jobs
                         </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const DistributionCenter: React.FC = () => {
    const { distributionOrders, drivers, assignDriverToOrders, unassignDriverFromOrder, updateDistributionOrder, updateDriver, language, addNotification, checkPermission } = useInventory();
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;
    const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());
    const [selectedDriverId, setSelectedDriverId] = useState<string | null>(null);
    const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [isVerifying, setIsVerifying] = useState(false);
    const [checkingGeofence, setCheckingGeofence] = useState<string | null>(null);
    
    // View Mode for Driver Management
    const [viewMode, setViewMode] = useState<'OPERATIONS' | 'FLEET'>('OPERATIONS');
    const [editingDriver, setEditingDriver] = useState<Driver | null>(null);
    const [isDriverModalOpen, setIsDriverModalOpen] = useState(false);

    const readyOrders = useMemo(() => {
        return distributionOrders.filter(o => {
            const isReady = ['Ready to Ship', 'Shipped', 'In Transit'].includes(o.status);
            const matchesSearch = o.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) || (o.deliveryDetails?.recipient || '').toLowerCase().includes(searchTerm.toLowerCase()) || (o.deliveryDetails?.postCode || '').includes(searchTerm);
            return isReady && matchesSearch;
        });
    }, [distributionOrders, searchTerm]);

    // UseRef to prevent verification from running every single render, only once when data loads
    const hasAutoVerified = useRef(false);

    const handleVerifyLocations = async () => {
        if (readyOrders.length === 0) return;
        setIsVerifying(true);
        try {
            // Check if key is available before proceeding
            const hasKey = (window as any).aistudio?.hasSelectedApiKey ? await (window as any).aistudio.hasSelectedApiKey() : false;
            if (!hasKey) {
                // Silent return for auto-run if key not set
                setIsVerifying(false);
                return;
            }

            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            // Filter unverified orders or select up to 5 to verify
            const ordersToVerify = readyOrders.filter(o => !o.geoVerified || !o.deliveryDetails?.latitude).slice(0, 5);
            
            if (ordersToVerify.length === 0) {
                 // Silent return for auto-run if nothing to do
                 setIsVerifying(false);
                 return;
            }

            const prompt = `Geocode these addresses to coordinates (latitude, longitude). Return JSON.
            Addresses:
            ${ordersToVerify.map(o => `ID: ${o.id}, Address: ${o.deliveryDetails?.address} ${o.deliveryDetails?.unit || ''}, ${o.deliveryDetails?.postCode || ''}`).join('\n')}
            `;

            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: prompt,
                config: {
                    responseMimeType: 'application/json',
                    responseSchema: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                id: { type: Type.STRING },
                                latitude: { type: Type.NUMBER },
                                longitude: { type: Type.NUMBER }
                            }
                        }
                    }
                }
            });

            const results = JSON.parse(response.text || '[]');
            let updatedCount = 0;
            
            results.forEach((res: any) => {
                const order = ordersToVerify.find(o => o.id === res.id);
                if (order && res.latitude && res.longitude) {
                    updateDistributionOrder({
                        ...order,
                        geoVerified: true,
                        deliveryDetails: {
                            ...order.deliveryDetails!,
                            latitude: res.latitude,
                            longitude: res.longitude,
                            geofenceRadius: 500
                        }
                    });
                    updatedCount++;
                }
            });

            if (updatedCount > 0) {
                addNotification('success', t('AI Geocoding Complete', 'AI 地理编码完成'), t(`Updated ${updatedCount} addresses.`, `已更新 ${updatedCount} 个地址。`));
            }

        } catch (e) { 
            console.error("Verification failed", e); 
        } finally { 
            setIsVerifying(false); 
        }
    };

    // Auto-trigger verification on mount/entry if readyOrders populated
    useEffect(() => {
        if (!hasAutoVerified.current && readyOrders.length > 0) {
            const unverified = readyOrders.filter(o => !o.geoVerified || !o.deliveryDetails?.latitude);
            if (unverified.length > 0) {
                // Small timeout to allow UI to settle
                setTimeout(() => handleVerifyLocations(), 500);
            }
            hasAutoVerified.current = true;
        }
    }, [readyOrders]);

    const handleSelectOrder = (id: string) => {
        const newSet = new Set(selectedOrderIds);
        if (newSet.has(id)) newSet.delete(id);
        else newSet.add(id);
        setSelectedOrderIds(newSet);
    };
    
    // When view changes to Operations, reset driver selection
    useEffect(() => {
        if (viewMode === 'OPERATIONS') setSelectedDriverId(null);
    }, [viewMode]);

    const handleMapPinClick = (id: string) => {
        // Exclusive selection for map pins to ensure sidebar shows
        setSelectedOrderIds(new Set([id]));
        setViewMode('OPERATIONS'); // Switch context to operations to show order details
    };

    const handleSelectAll = () => {
        if (selectedOrderIds.size === readyOrders.length && readyOrders.length > 0) setSelectedOrderIds(new Set());
        else setSelectedOrderIds(new Set(readyOrders.map(o => o.id)));
    };

    const handleAssignConfirm = (driverId: string, note: string) => {
        assignDriverToOrders(Array.from(selectedOrderIds), driverId, note);
        setSelectedOrderIds(new Set());
    };

    const handleEditDriver = (driver: Driver) => {
        setEditingDriver(driver);
        setIsDriverModalOpen(true);
    };

    return (
        <div className="flex h-screen bg-white dark:bg-slate-950 transition-colors overflow-hidden">
            {/* View Toggle / Sidebar Control */}
            <div className="w-96 flex flex-col border-r border-gray-200 dark:border-slate-800 bg-white dark:bg-slate-900 z-20 shadow-xl">
                <div className="p-6 border-b border-gray-100 dark:border-slate-800 shrink-0">
                    <h1 className="text-2xl font-extrabold text-gray-900 dark:text-white flex items-center gap-2 mb-4"><Truck className="text-blue-600 dark:text-blue-400" /> {t('Distribution', '配送中心')}</h1>
                    
                    {/* Mode Switcher */}
                    <div className="flex p-1 bg-gray-100 dark:bg-slate-800 rounded-xl mb-4">
                        <button 
                            onClick={() => setViewMode('OPERATIONS')}
                            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${viewMode === 'OPERATIONS' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-900'}`}
                        >
                            {t('Operations', '运营操作')}
                        </button>
                        <button 
                            onClick={() => setViewMode('FLEET')}
                            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${viewMode === 'FLEET' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-900'}`}
                        >
                            {t('Fleet Mgmt', '车队管理')}
                        </button>
                    </div>

                    {viewMode === 'OPERATIONS' && (
                        <div className="flex flex-col gap-3">
                            <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} /><input className="w-full pl-9 pr-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500 transition-all dark:text-white placeholder:text-gray-400" placeholder={t("Search recipient, code...", "搜索收件人, 单号...")} value={searchTerm} onChange={e => setSearchTerm(e.target.value)}/></div>
                            <div className="flex items-center justify-between"><div className="flex items-center gap-2"><button onClick={handleSelectAll} className="text-gray-400 hover:text-blue-600 transition-colors p-1 rounded hover:bg-gray-100 dark:hover:bg-slate-800">{selectedOrderIds.size === readyOrders.length && readyOrders.length > 0 ? <CheckSquare size={20} className="text-blue-600"/> : <Square size={20}/>}</button><span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{selectedOrderIds.size} Selected</span></div>{checkPermission('DM_DISTRIBUTION_CENTER', 'edit') && (<button onClick={() => setIsAssignModalOpen(true)} disabled={selectedOrderIds.size === 0} className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-md active:scale-95 flex items-center gap-2"><User size={14} /> Assign Driver</button>)}</div>
                        </div>
                    )}
                    
                    {viewMode === 'FLEET' && (
                         <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{drivers.length} Drivers</span>
                            <button className="text-blue-600 dark:text-blue-400 text-xs font-bold hover:underline flex items-center gap-1"><Plus size={12}/> Add Driver</button>
                         </div>
                    )}
                </div>
                
                {viewMode === 'OPERATIONS' ? (
                    <div className="flex-1 overflow-y-auto p-2 space-y-2 bg-gray-50 dark:bg-slate-950/30">
                        {readyOrders.map(order => (
                            <div key={order.id} className={`p-3 rounded-xl border transition-all cursor-pointer group ${selectedOrderIds.has(order.id) ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800' : 'bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700 hover:border-blue-300'}`} onClick={() => handleSelectOrder(order.id)}>
                                <div className="flex items-start gap-3">
                                    <div className="mt-1">{selectedOrderIds.has(order.id) ? <CheckSquare size={18} className="text-blue-600"/> : <Square size={18} className="text-gray-300 group-hover:text-blue-400 transition-colors"/>}</div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex justify-between items-start mb-1"><h4 className="font-bold text-sm text-gray-900 dark:text-white truncate">{order.deliveryDetails?.recipient || 'Unknown'}</h4><span className="text-[10px] font-mono font-bold bg-gray-100 dark:bg-slate-700 px-1.5 py-0.5 rounded text-gray-600 dark:text-gray-300">{order.items.length}P</span></div>
                                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1 truncate">{order.deliveryDetails?.address || 'No Address'}</p>
                                        
                                        {order.deliveryDetails?.sendPeriod && (
                                            <div className="flex items-center gap-2 mt-1 text-[10px] text-blue-600 dark:text-blue-400 font-bold bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded w-fit">
                                                <Calendar size={10} /> {order.deliveryDetails.sendPeriod}
                                                {order.deliveryDetails.deliveryTime && <span className="opacity-70">| {order.deliveryDetails.deliveryTime}</span>}
                                            </div>
                                        )}

                                        <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100 dark:border-slate-800"><span className="text-[10px] font-mono text-gray-400">{order.orderNumber}</span>{order.assignedDriverId ? (<div className="flex items-center gap-2"><span className="text-[9px] font-bold uppercase bg-green-100 text-green-700 px-1.5 py-0.5 rounded dark:bg-green-900/30 dark:text-green-400">Assigned</span></div>) : (<span className="text-[9px] font-bold uppercase bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded dark:bg-amber-900/30 dark:text-amber-400">Unassigned</span>)}</div>
                                    </div>
                                </div>
                            </div>
                        ))}
                        {readyOrders.length === 0 && (<div className="p-8 text-center text-gray-400 dark:text-gray-600 h-full flex flex-col items-center justify-center"><Truck size={32} className="mb-2 opacity-20" /><p className="text-sm font-medium">No ready orders.</p></div>)}
                    </div>
                ) : (
                    <div className="h-full flex flex-col">
                        <div className="flex-1 overflow-y-auto bg-gray-50 dark:bg-slate-950/30">
                            <DriverList 
                                drivers={drivers} 
                                onEdit={handleEditDriver} 
                                selectedId={selectedDriverId}
                                onSelect={(id) => setSelectedDriverId(prev => prev === id ? null : id)}
                            />
                        </div>
                    </div>
                )}
            </div>
            
            {/* Main Content Area (Map) */}
            <div className="flex-1 relative z-0">
                <LeafletMap 
                    orders={readyOrders} 
                    drivers={drivers} 
                    onPinClick={handleMapPinClick} 
                    selectedOrderIds={selectedOrderIds} 
                    selectedDriverId={selectedDriverId}
                />
            </div>
            
            <AssignDriverModal isOpen={isAssignModalOpen} onClose={() => setIsAssignModalOpen(false)} selectedCount={selectedOrderIds.size} drivers={drivers} onConfirm={handleAssignConfirm}/>
            
            {/* Driver Management Modal */}
            <DriverModal 
                isOpen={isDriverModalOpen} 
                onClose={() => setIsDriverModalOpen(false)} 
                driver={editingDriver}
                onSave={updateDriver}
            />
        </div>
    );
};

export default DistributionCenter;

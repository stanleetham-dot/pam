
import React, { useState, useEffect, useCallback } from 'react';
import { 
    ArrowLeft, Save, Shield, Info, CheckSquare, Square, CornerDownRight, RotateCw, ThumbsUp, RotateCcw, ThumbsDown,
    LayoutDashboard, BrainCircuit, ClipboardList, Truck, ArrowDownToLine, Package, History, 
    ClipboardCheck, Zap, Warehouse, Settings, Layers, ArrowRightLeft, MapPin, Boxes, 
    ShoppingCart, FileText, Tag, Clock, Search, Edit2, ShieldAlert, Scan, Users, Circle
} from 'lucide-react';
import { RoleConfig, PermissionObject } from '../types';
import { APP_MODULES, PERMISSION_MODULES } from '../constants';

interface RoleDetailConfigProps {
    role: string;
    config?: RoleConfig;
    onSave: (config: RoleConfig) => void;
    onClose: () => void;
}

const GLOBAL_ACTIONS = [
    { name: 'View Cost Prices', key: 'view_cost_price' },
    { name: 'Approve Adjustments', key: 'approve_adjustments' },
    { name: 'Export Data (Excel)', key: 'export_data' },
    { name: 'Manage Users', key: 'manage_users' },
    { name: 'System Settings', key: 'manage_settings' }
];

const getModuleIcon = (key: string) => {
    switch (key) {
        case 'DASHBOARD': return LayoutDashboard;
        case 'AI_ASSISTANT': return BrainCircuit;
        case 'TASK_MANAGER': return CheckSquare;
        case 'ORDER_MGMT_GROUP': return ClipboardList;
        case 'OM_TASK_MANAGEMENT': return CheckSquare;
        case 'OM_DISTRIBUTION_ORDER': return Truck;
        case 'PICKING_PLAN': return ClipboardCheck;
        case 'DISTRIBUTION_METHOD': return ArrowDownToLine;
        case 'WAREHOUSE_MGMT_GROUP': return Warehouse;
        case 'WAREHOUSE_CONFIG': return Settings;
        case 'SHELF_ARRANGEMENT': return Layers;
        case 'DELIVERY_MGMT_GROUP': return Truck;
        case 'DM_DISTRIBUTION_CENTER': return Warehouse;
        case 'DM_TRANSFER_OUT_ORDER': return ArrowRightLeft;
        case 'DM_DELIVERY_TRACKING': return MapPin;
        case 'PURCHASING_GROUP': return ShoppingCart;
        case 'PURCHASING': return FileText;
        case 'RECEIVING_ORDERS': return ArrowDownToLine;
        case 'INBOUND': return ArrowDownToLine;
        case 'PRODUCT_MGMT_GROUP': return Tag;
        case 'INVENTORY_PRODUCT': return Package;
        case 'INVENTORY_EXPIRE': return Clock;
        case 'INVENTORY_GROUP': return Boxes;
        case 'INVENTORY_QUERY': return Search;
        case 'INVENTORY_ADJUSTMENT': return Edit2;
        case 'INVENTORY_TRANSFER': return ArrowRightLeft;
        case 'INVENTORY_DISCREPANCY': return ShieldAlert;
        case 'SCAN_OPS_GROUP': return Scan;
        case 'SCAN_TO_SHELF': return Scan;
        case 'SKU_LOOKUP': return Search;
        case 'SHELF_LOGS': return History;
        case 'ACCOUNT_MANAGEMENT': return Users;
        case 'SETTINGS': return Settings;
        default: return Circle;
    }
};

const Switch: React.FC<{ checked: boolean, onChange: () => void, disabled?: boolean, colorClass?: string }> = ({ checked, onChange, disabled, colorClass = 'bg-blue-600' }) => (
    <button
        type="button"
        disabled={disabled}
        onClick={onChange}
        className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${checked ? colorClass : 'bg-gray-200 dark:bg-slate-700'} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
        <span className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${checked ? 'translate-x-5' : 'translate-x-0'}`} />
    </button>
);

// Extracted PermissionRow component to prevent re-renders losing focus
const PermissionRow: React.FC<{ 
    itemKey: string;
    label: string;
    isChild?: boolean;
    localConfig: RoleConfig | null;
    togglePerm: (key: string, type: keyof PermissionObject) => void;
    toggleAllRow: (key: string, val: boolean) => void;
    handleSharingChange: (key: string, val: string) => void;
}> = React.memo(({ itemKey, label, isChild, localConfig, togglePerm, toggleAllRow, handleSharingChange }) => {
    const perms = localConfig?.objects[itemKey] || { create: false, read: false, edit: false, delete: false, approve: false, reject: false, undo: false, sharing: 'Own Only' };
    const isAll = perms.read && perms.create && perms.edit && perms.delete && perms.approve && perms.reject && perms.undo;
    const Icon = getModuleIcon(itemKey);

    return (
        <tr className={`hover:bg-blue-50/50 dark:hover:bg-blue-900/10 transition-colors border-b border-gray-100 dark:border-slate-800 ${isChild ? 'bg-white dark:bg-slate-900' : 'bg-gray-50/50 dark:bg-slate-950/30'}`}>
            <td className="px-6 py-4">
                <div className={`flex items-center gap-3 ${isChild ? 'pl-8' : ''}`}>
                    {isChild && <CornerDownRight size={14} className="text-gray-400 dark:text-gray-600 shrink-0" />}
                    <div className="flex items-center gap-2 overflow-hidden">
                        <Icon size={16} className={`${isChild ? 'text-gray-400 dark:text-gray-500' : 'text-blue-600 dark:text-blue-400'} shrink-0`} />
                        <div className="min-w-0">
                            <span className={`text-sm block truncate ${isChild ? 'font-medium text-gray-600 dark:text-gray-400' : 'font-bold text-gray-800 dark:text-gray-200'}`}>{label}</span>
                            <p className="text-[10px] text-gray-400 dark:text-gray-500 font-mono mt-0.5 truncate">{itemKey}</p>
                        </div>
                    </div>
                </div>
            </td>
            <td className="px-2 py-4 text-center">
                <button onClick={() => toggleAllRow(itemKey, !isAll)} className="text-gray-400 dark:text-gray-600 hover:text-blue-600 dark:hover:text-blue-400 transition-colors p-1 rounded hover:bg-gray-100 dark:hover:bg-slate-800">
                    {isAll ? <CheckSquare size={20} className="text-blue-600 dark:text-blue-400" /> : <Square size={20} />}
                </button>
            </td>
            <td className="px-2 py-4 text-center">
                <Switch checked={perms.read} onChange={() => togglePerm(itemKey, 'read')} colorClass="bg-blue-500" />
            </td>
            <td className="px-2 py-4 text-center">
                <Switch checked={perms.create} onChange={() => togglePerm(itemKey, 'create')} colorClass="bg-indigo-500" />
            </td>
            <td className="px-2 py-4 text-center">
                <Switch checked={perms.edit} onChange={() => togglePerm(itemKey, 'edit')} colorClass="bg-violet-500" />
            </td>
            <td className="px-2 py-4 text-center">
                <Switch checked={perms.delete} onChange={() => togglePerm(itemKey, 'delete')} colorClass="bg-red-500" />
            </td>
            <td className="px-2 py-4 text-center border-l border-gray-100 dark:border-slate-800 pl-4">
                <Switch checked={perms.approve} onChange={() => togglePerm(itemKey, 'approve')} colorClass="bg-emerald-500" />
            </td>
            <td className="px-2 py-4 text-center">
                <Switch checked={perms.reject} onChange={() => togglePerm(itemKey, 'reject')} colorClass="bg-rose-500" />
            </td>
            <td className="px-2 py-4 text-center border-l border-gray-100 dark:border-slate-800 pl-4">
                <Switch checked={perms.undo} onChange={() => togglePerm(itemKey, 'undo')} colorClass="bg-amber-500" />
            </td>
            <td className="px-4 py-4 text-right">
                <select 
                    className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg text-[11px] px-2 py-1 outline-none focus:ring-2 focus:ring-blue-500 text-gray-700 dark:text-gray-300 font-medium cursor-pointer transition-colors w-24"
                    value={perms.sharing}
                    onChange={(e) => handleSharingChange(itemKey, e.target.value)}
                >
                    <option>Everyone</option>
                    <option>Business Unit</option>
                    <option>Own Only</option>
                </select>
            </td>
        </tr>
    );
});

const RoleDetailConfig: React.FC<RoleDetailConfigProps> = ({ role, config, onSave, onClose }) => {
    const [localConfig, setLocalConfig] = useState<RoleConfig | null>(null);

    useEffect(() => {
        if (config) {
            const mergedObjects = { ...config.objects };
            PERMISSION_MODULES.forEach(mod => {
                if (!mergedObjects[mod.key]) {
                    // Create default if missing
                    mergedObjects[mod.key] = {
                        create: false,
                        read: false,
                        edit: false,
                        delete: false,
                        approve: false,
                        reject: false,
                        undo: false,
                        sharing: 'Own Only'
                    };
                } else {
                    // Ensure existing entries have new properties (migration)
                    const existing = mergedObjects[mod.key];
                    mergedObjects[mod.key] = {
                        ...existing,
                        approve: existing.approve ?? false,
                        reject: existing.reject ?? false,
                        undo: existing.undo ?? false
                    };
                }
            });
            setLocalConfig({ ...config, objects: mergedObjects });
        }
    }, [config]);

    const togglePerm = useCallback((objKey: string, type: keyof PermissionObject) => {
        if (type === 'sharing') return;
        setLocalConfig(prev => {
            if (!prev) return null;
            return {
                ...prev,
                objects: {
                    ...prev.objects,
                    [objKey]: {
                        ...prev.objects[objKey],
                        [type]: !prev.objects[objKey][type]
                    }
                }
            };
        });
    }, []);

    const toggleColumn = useCallback((type: keyof PermissionObject | 'all') => {
        setLocalConfig(prev => {
            if (!prev) return null;
            
            const allKeys = Object.keys(prev.objects);
            let targetVal = true;

            if (type === 'all') {
                // Check if every permission is true for every object
                const allTrue = allKeys.every(key => {
                    const p = prev.objects[key];
                    return p.read && p.create && p.edit && p.delete && p.approve && p.reject && p.undo;
                });
                targetVal = !allTrue;
            } else {
                // Check if this specific permission is true for every object
                const allTrue = allKeys.every(key => prev.objects[key][type]);
                targetVal = !allTrue;
            }

            const newObjects = { ...prev.objects };
            allKeys.forEach(key => {
                if (type === 'all') {
                    newObjects[key] = {
                        ...newObjects[key],
                        read: targetVal,
                        create: targetVal,
                        edit: targetVal,
                        delete: targetVal,
                        approve: targetVal,
                        reject: targetVal,
                        undo: targetVal
                    };
                } else {
                    newObjects[key] = {
                        ...newObjects[key],
                        [type]: targetVal
                    };
                }
            });

            return { ...prev, objects: newObjects };
        });
    }, []);

    const handleSharingChange = useCallback((objKey: string, value: string) => {
        setLocalConfig(prev => {
            if (!prev) return null;
            return {
                ...prev,
                objects: {
                    ...prev.objects,
                    [objKey]: {
                        ...prev.objects[objKey],
                        sharing: value
                    }
                }
            };
        });
    }, []);

    const toggleAction = (actKey: string) => {
        setLocalConfig(prev => {
            if (!prev) return null;
            return {
                ...prev,
                actions: {
                    ...prev.actions,
                    [actKey]: !prev.actions[actKey]
                }
            };
        });
    };

    const toggleAllRow = useCallback((objKey: string, val: boolean) => {
        setLocalConfig(prev => {
            if (!prev) return null;
            return {
                ...prev,
                objects: {
                    ...prev.objects,
                    [objKey]: {
                        ...prev.objects[objKey],
                        create: val,
                        read: val,
                        edit: val,
                        delete: val,
                        approve: val,
                        reject: val,
                        undo: val
                    }
                }
            };
        });
    }, []);

    const cycleAllSharing = () => {
        setLocalConfig(prev => {
            if (!prev) return null;
            const scopes = ['Everyone', 'Business Unit', 'Own Only'];
            const firstKey = Object.keys(prev.objects)[0];
            // Cycle based on the first item's current value
            const currentScope = prev.objects[firstKey]?.sharing || 'Own Only';
            const nextIndex = (scopes.indexOf(currentScope) + 1) % scopes.length;
            const nextScope = scopes[nextIndex];

            const newObjects = { ...prev.objects };
            Object.keys(newObjects).forEach(key => {
                newObjects[key] = { ...newObjects[key], sharing: nextScope };
            });

            return { ...prev, objects: newObjects };
        });
    };

    if (!localConfig) return null;

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 absolute inset-0 z-30 animate-in slide-in-from-right duration-300 transition-colors">
            {/* Header */}
            <div className="px-8 py-5 border-b border-gray-200 dark:border-slate-800 flex items-center justify-between bg-white dark:bg-slate-900 shadow-sm shrink-0 transition-colors">
                <div className="flex items-center gap-4">
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full transition-colors text-gray-500 dark:text-gray-400">
                        <ArrowLeft size={20} />
                    </button>
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${role === 'ADMIN' ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400' : 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'}`}>
                            <Shield size={24} />
                        </div>
                        <div>
                            <h1 className="text-xl font-bold text-gray-900 dark:text-white">{role} Configuration</h1>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Define access levels and functional permissions.</p>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <button onClick={onClose} className="px-4 py-2 text-gray-600 dark:text-gray-400 font-bold hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-sm">
                        Discard
                    </button>
                    <button 
                        onClick={() => { onSave(localConfig); onClose(); }} 
                        className="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 flex items-center gap-2 transition-all transform active:scale-95 text-sm"
                    >
                        <Save size={18} /> Save Changes
                    </button>
                </div>
            </div>

            <div className="flex flex-1 overflow-hidden">
                <div className="flex-1 overflow-y-auto p-8 no-scrollbar">
                    <div className="mb-6 flex justify-between items-end">
                        <h2 className="text-lg font-bold text-gray-900 dark:text-white">Module Access Control</h2>
                        <span className="text-xs text-gray-500 dark:text-gray-400 bg-white dark:bg-slate-900 px-3 py-1 rounded-full border border-gray-200 dark:border-slate-800 shadow-sm flex items-center gap-1">
                            <Info size={12}/> Changes reflect immediately after saving
                        </span>
                    </div>
                    
                    <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-xl shadow-sm relative transition-colors overflow-hidden">
                        <table className="w-full text-left border-collapse">
                            <thead className="bg-gray-50 dark:bg-slate-950 text-gray-500 dark:text-gray-400 font-bold text-[10px] uppercase tracking-wider sticky top-0 z-20 shadow-sm transition-colors border-b border-gray-200 dark:border-slate-800">
                                <tr>
                                    <th className="px-6 py-4 rounded-tl-xl">Module Hierarchy</th>
                                    
                                    {/* ALL Column */}
                                    <th className="px-2 py-4 text-center w-12 cursor-pointer hover:text-blue-600 transition-colors group" onClick={() => toggleColumn('all')} title="Toggle All">
                                        <div className="flex flex-col items-center gap-1">
                                            <span>All</span>
                                            <CheckSquare size={12} className="opacity-30 group-hover:opacity-100 transition-opacity" />
                                        </div>
                                    </th>

                                    {/* READ Column */}
                                    <th className="px-2 py-4 text-center w-16 cursor-pointer hover:text-blue-600 transition-colors group" onClick={() => toggleColumn('read')}>
                                        <div className="flex flex-col items-center gap-1">
                                            <span>Read</span>
                                            <Square size={12} className="opacity-30 group-hover:opacity-100 transition-opacity" />
                                        </div>
                                    </th>

                                    {/* CREATE Column */}
                                    <th className="px-2 py-4 text-center w-16 cursor-pointer hover:text-indigo-600 transition-colors group" onClick={() => toggleColumn('create')}>
                                        <div className="flex flex-col items-center gap-1">
                                            <span>Create</span>
                                            <Square size={12} className="opacity-30 group-hover:opacity-100 transition-opacity" />
                                        </div>
                                    </th>

                                    {/* EDIT Column */}
                                    <th className="px-2 py-4 text-center w-16 cursor-pointer hover:text-violet-600 transition-colors group" onClick={() => toggleColumn('edit')}>
                                        <div className="flex flex-col items-center gap-1">
                                            <span>Edit</span>
                                            <Square size={12} className="opacity-30 group-hover:opacity-100 transition-opacity" />
                                        </div>
                                    </th>

                                    {/* DELETE Column */}
                                    <th className="px-2 py-4 text-center w-16 cursor-pointer text-red-500 hover:text-red-700 transition-colors group" onClick={() => toggleColumn('delete')}>
                                        <div className="flex flex-col items-center gap-1">
                                            <span>Delete</span>
                                            <Square size={12} className="opacity-30 group-hover:opacity-100 transition-opacity" />
                                        </div>
                                    </th>

                                    {/* APPROVE Column */}
                                    <th className="px-2 py-4 text-center w-16 text-emerald-600 hover:text-emerald-800 border-l border-gray-200 dark:border-slate-800 pl-4 cursor-pointer group" onClick={() => toggleColumn('approve')}>
                                        <div className="flex flex-col items-center gap-1">
                                            <ThumbsUp size={14} />
                                            <span>Approve</span>
                                        </div>
                                    </th>

                                    {/* REJECT Column */}
                                    <th className="px-2 py-4 text-center w-16 text-rose-500 hover:text-rose-700 cursor-pointer group" onClick={() => toggleColumn('reject')}>
                                        <div className="flex flex-col items-center gap-1">
                                            <ThumbsDown size={14} />
                                            <span>Reject</span>
                                        </div>
                                    </th>

                                    {/* UNDO Column */}
                                    <th className="px-2 py-4 text-center w-16 text-amber-600 hover:text-amber-800 border-l border-gray-200 dark:border-slate-800 pl-4 cursor-pointer group" onClick={() => toggleColumn('undo')}>
                                        <div className="flex flex-col items-center gap-1">
                                            <RotateCcw size={14} />
                                            <span>Undo</span>
                                        </div>
                                    </th>

                                    <th className="px-4 py-4 text-right rounded-tr-xl w-32">
                                        <button 
                                            onClick={cycleAllSharing}
                                            className="flex items-center gap-1 ml-auto hover:text-blue-600 transition-colors group"
                                            title="Quick Access: Cycle All"
                                        >
                                            Data Scope <RotateCw size={12} className="group-hover:rotate-180 transition-transform duration-300" />
                                        </button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-slate-800 transition-colors">
                                {APP_MODULES.map(mod => (
                                    <React.Fragment key={mod.key}>
                                        <PermissionRow 
                                            itemKey={mod.key} 
                                            label={mod.label} 
                                            localConfig={localConfig}
                                            togglePerm={togglePerm}
                                            toggleAllRow={toggleAllRow}
                                            handleSharingChange={handleSharingChange}
                                        />
                                        {mod.children?.map(child => (
                                            <PermissionRow 
                                                key={child.key} 
                                                itemKey={child.key} 
                                                label={child.label} 
                                                isChild={true} 
                                                localConfig={localConfig}
                                                togglePerm={togglePerm}
                                                toggleAllRow={toggleAllRow}
                                                handleSharingChange={handleSharingChange}
                                            />
                                        ))}
                                    </React.Fragment>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="w-80 bg-white dark:bg-slate-900 border-l border-gray-200 dark:border-slate-800 flex flex-col shadow-xl z-30 transition-colors">
                    <div className="p-6 bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800 transition-colors">
                        <h2 className="text-lg font-bold text-gray-900 dark:text-white">Global Actions</h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Specific functional capabilities.</p>
                    </div>
                    <div className="flex-1 overflow-y-auto p-6 space-y-4 no-scrollbar">
                        {GLOBAL_ACTIONS.map(act => (
                            <div 
                                key={act.key} 
                                className="flex items-center justify-between p-4 rounded-xl border border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-200 dark:hover:border-blue-800 hover:shadow-sm transition-all"
                            >
                                <span className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase">{act.name}</span>
                                <Switch checked={!!localConfig.actions[act.key]} onChange={() => toggleAction(act.key)} />
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RoleDetailConfig;

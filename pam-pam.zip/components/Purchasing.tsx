
import React, { useState } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    Plus, Search, ShoppingCart, FileText, 
    Calendar, User, CheckCircle2, Clock, 
    ArrowRight, DollarSign, Filter, X, Trash2
} from 'lucide-react';
import { PurchaseOrder, Product } from '../types';

const StatusBadge: React.FC<{ status: PurchaseOrder['status'] }> = ({ status }) => {
    const styles = {
        'DRAFT': 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700',
        'ORDERED': 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-400 dark:border-blue-800',
        'PARTIAL': 'bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-900/30 dark:text-orange-400 dark:border-orange-800',
        'COMPLETED': 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800',
        'CANCELLED': 'bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800'
    };
    
    return (
        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border uppercase tracking-wider ${styles[status] || styles['DRAFT']}`}>
            {status}
        </span>
    );
};

const CreatePOModal: React.FC<{ isOpen: boolean; onClose: () => void; onSubmit: (po: any) => void; products: Product[] }> = ({ isOpen, onClose, onSubmit, products }) => {
    const [supplier, setSupplier] = useState('');
    const [expectedDate, setExpectedDate] = useState('');
    const [selectedItems, setSelectedItems] = useState<{ productId: string, name: string, quantity: number, unitCost: number, sku: string }[]>([]);
    const [itemSearch, setItemSearch] = useState('');

    if (!isOpen) return null;

    const addItem = (product: Product) => {
        if (selectedItems.some(i => i.productId === product.id)) return;
        setSelectedItems([...selectedItems, { 
            productId: product.id, 
            name: product.name, 
            sku: product.sku,
            quantity: 1, 
            unitCost: product.purchasePrice || 0 
        }]);
        setItemSearch('');
    };

    const updateItem = (index: number, field: string, value: number) => {
        const newItems = [...selectedItems];
        (newItems[index] as any)[field] = value;
        setSelectedItems(newItems);
    };

    const removeItem = (index: number) => {
        setSelectedItems(selectedItems.filter((_, i) => i !== index));
    };

    const totalAmount = selectedItems.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);

    const handleSubmit = () => {
        if (!supplier || !expectedDate || selectedItems.length === 0) return alert("Please fill all fields.");
        onSubmit({
            poNumber: `PO-${Date.now().toString().slice(-6)}`,
            supplier,
            orderDate: new Date().toISOString().split('T')[0],
            expectedDate,
            status: 'DRAFT',
            totalAmount,
            items: selectedItems
        });
        onClose();
        setSupplier('');
        setExpectedDate('');
        setSelectedItems([]);
    };

    const searchedProducts = products.filter(p => p.name.toLowerCase().includes(itemSearch.toLowerCase()) || p.sku.toLowerCase().includes(itemSearch.toLowerCase())).slice(0, 5);

    return (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-4xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden transition-colors">
                <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50">
                    <div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Create Purchase Order</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Draft a new order for suppliers.</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full text-gray-500 dark:text-gray-400 transition-colors"><X size={20}/></button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    <div className="grid grid-cols-2 gap-6">
                        <div>
                            <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-1.5">Supplier Name</label>
                            <input className="w-full px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-colors" value={supplier} onChange={e => setSupplier(e.target.value)} placeholder="e.g. Acme Corp" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-1.5">Expected Date</label>
                            <input type="date" className="w-full px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-colors" value={expectedDate} onChange={e => setExpectedDate(e.target.value)} />
                        </div>
                    </div>

                    <div className="border-t border-gray-100 dark:border-slate-800 pt-6">
                        <div className="flex justify-between items-center mb-4">
                            <h4 className="text-sm font-bold text-gray-800 dark:text-white uppercase">Order Items</h4>
                            <div className="relative w-64">
                                <input 
                                    className="w-full pl-8 pr-4 py-1.5 text-sm border border-gray-200 dark:border-slate-700 rounded-lg bg-gray-50 dark:bg-slate-800 outline-none focus:border-blue-500" 
                                    placeholder="Add product..." 
                                    value={itemSearch}
                                    onChange={e => setItemSearch(e.target.value)}
                                />
                                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
                                {itemSearch && (
                                    <div className="absolute top-full left-0 w-full bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg shadow-lg mt-1 z-10 overflow-hidden">
                                        {searchedProducts.map(p => (
                                            <button key={p.id} onClick={() => addItem(p)} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 dark:hover:bg-slate-700 truncate">
                                                {p.name}
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>

                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-50 dark:bg-slate-950 text-gray-500 dark:text-gray-400 font-bold uppercase text-xs">
                                <tr>
                                    <th className="px-4 py-3">Product</th>
                                    <th className="px-4 py-3 w-32">Qty</th>
                                    <th className="px-4 py-3 w-32">Unit Cost</th>
                                    <th className="px-4 py-3 w-32 text-right">Total</th>
                                    <th className="px-4 py-3 w-10"></th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                                {selectedItems.map((item, idx) => (
                                    <tr key={idx}>
                                        <td className="px-4 py-3">
                                            <p className="font-medium text-gray-900 dark:text-white">{item.name}</p>
                                            <p className="text-xs text-gray-500 font-mono">{item.sku}</p>
                                        </td>
                                        <td className="px-4 py-3">
                                            <input type="number" className="w-full px-2 py-1 border dark:border-slate-700 rounded bg-transparent text-center dark:text-white" value={item.quantity} onChange={e => updateItem(idx, 'quantity', parseFloat(e.target.value))} />
                                        </td>
                                        <td className="px-4 py-3">
                                            <input type="number" className="w-full px-2 py-1 border dark:border-slate-700 rounded bg-transparent text-center dark:text-white" value={item.unitCost} onChange={e => updateItem(idx, 'unitCost', parseFloat(e.target.value))} />
                                        </td>
                                        <td className="px-4 py-3 text-right font-mono font-bold dark:text-white">
                                            ${(item.quantity * item.unitCost).toFixed(2)}
                                        </td>
                                        <td className="px-4 py-3 text-right">
                                            <button onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700"><X size={16}/></button>
                                        </td>
                                    </tr>
                                ))}
                                {selectedItems.length === 0 && (
                                    <tr><td colSpan={5} className="py-8 text-center text-gray-400">No items added.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="p-6 border-t border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-950 flex justify-between items-center rounded-b-2xl">
                    <div className="text-lg font-bold text-gray-900 dark:text-white">
                        Total: <span className="text-blue-600 dark:text-blue-400 font-mono">${totalAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex gap-3">
                        <button onClick={onClose} className="px-5 py-2.5 text-gray-600 dark:text-gray-400 font-bold hover:bg-gray-200 dark:hover:bg-slate-800 rounded-xl transition-colors">Cancel</button>
                        <button onClick={handleSubmit} className="px-6 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-200 dark:shadow-none transition-all active:scale-95">Save Draft</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

const Purchasing: React.FC = () => {
    const { purchaseOrders, addPurchaseOrder, updatePurchaseOrder, deletePurchaseOrder, products, currentUser } = useInventory();
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState<string>('ALL');
    const [isCreateOpen, setIsCreateOpen] = useState(false);

    const filteredOrders = purchaseOrders.filter(po => {
        const matchesSearch = po.poNumber.toLowerCase().includes(searchTerm.toLowerCase()) || po.supplier.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'ALL' || po.status === statusFilter;
        return matchesSearch && matchesStatus;
    });

    const handleCreateSubmit = (poData: any) => {
        addPurchaseOrder({
            id: crypto.randomUUID(),
            ...poData,
            createdBy: currentUser?.name || 'Admin'
        });
    };

    const handleStatusChange = (id: string, newStatus: PurchaseOrder['status']) => {
        const po = purchaseOrders.find(p => p.id === id);
        if (po) updatePurchaseOrder({ ...po, status: newStatus });
    };

    const handleDelete = (id: string) => {
        if(confirm("Are you sure you want to delete this order?")) {
            deletePurchaseOrder(id);
        }
    };

    return (
        <div className="p-6 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors duration-300 flex flex-col">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                        <ShoppingCart className="text-blue-600 dark:text-blue-400" />
                        Purchase Planning
                    </h1>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Manage supplier orders and draft plans.</p>
                </div>
                <button 
                    onClick={() => setIsCreateOpen(true)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-200 dark:shadow-none hover:bg-blue-700 transition-all active:scale-95 flex items-center gap-2"
                >
                    <Plus size={18} /> Create PO
                </button>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col flex-1 overflow-hidden transition-colors">
                <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex flex-col md:flex-row gap-4 bg-gray-50/50 dark:bg-slate-950/50">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                        <input 
                            className="w-full pl-10 pr-4 py-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                            placeholder="Search PO Number, Supplier..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex gap-2 overflow-x-auto no-scrollbar">
                        {['ALL', 'DRAFT', 'ORDERED', 'COMPLETED', 'CANCELLED'].map(status => (
                            <button 
                                key={status}
                                onClick={() => setStatusFilter(status)}
                                className={`px-4 py-2 rounded-lg text-xs font-bold border transition-colors whitespace-nowrap ${
                                    statusFilter === status 
                                    ? 'bg-blue-600 text-white border-blue-600' 
                                    : 'bg-white dark:bg-slate-800 text-gray-600 dark:text-gray-400 border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700'
                                }`}
                            >
                                {status === 'ALL' ? 'All Orders' : status.charAt(0) + status.slice(1).toLowerCase()}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="flex-1 overflow-auto">
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-gray-50 dark:bg-slate-950 sticky top-0 z-10 shadow-sm">
                            <tr>
                                <th className="px-6 py-3 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">PO Number</th>
                                <th className="px-6 py-3 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Supplier</th>
                                <th className="px-6 py-3 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Dates</th>
                                <th className="px-6 py-3 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-3 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-right">Items</th>
                                <th className="px-6 py-3 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-right">Total</th>
                                <th className="px-6 py-3 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                            {filteredOrders.map(po => (
                                <tr key={po.id} className="hover:bg-blue-50/30 dark:hover:bg-blue-900/10 transition-colors text-sm">
                                    <td className="px-6 py-4 font-mono font-bold text-blue-600 dark:text-blue-400">{po.poNumber}</td>
                                    <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{po.supplier}</td>
                                    <td className="px-6 py-4">
                                        <div className="flex flex-col text-xs text-gray-500 dark:text-gray-400">
                                            <span className="flex items-center gap-1"><Calendar size={10}/> Order: {po.orderDate}</span>
                                            <span className="flex items-center gap-1"><Clock size={10}/> Expect: {po.expectedDate}</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4"><StatusBadge status={po.status} /></td>
                                    <td className="px-6 py-4 text-right font-bold text-gray-700 dark:text-gray-300">{po.items.length}</td>
                                    <td className="px-6 py-4 text-right font-mono font-bold text-gray-900 dark:text-white">${po.totalAmount.toFixed(2)}</td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex justify-end gap-2">
                                            {po.status === 'DRAFT' && (
                                                <button 
                                                    onClick={() => handleStatusChange(po.id, 'ORDERED')}
                                                    className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-xs font-bold hover:bg-blue-100 border border-blue-200 transition-colors"
                                                >
                                                    Confirm Order
                                                </button>
                                            )}
                                            {po.status === 'ORDERED' && (
                                                <button 
                                                    onClick={() => handleStatusChange(po.id, 'COMPLETED')}
                                                    className="px-3 py-1.5 bg-green-50 text-green-600 rounded-lg text-xs font-bold hover:bg-green-100 border border-green-200 transition-colors"
                                                >
                                                    Mark Received
                                                </button>
                                            )}
                                            {po.status === 'DRAFT' && (
                                                <button onClick={() => handleDelete(po.id)} className="p-1.5 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors">
                                                    <Trash2 size={16} />
                                                </button>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            ))}
                            {filteredOrders.length === 0 && (
                                <tr>
                                    <td colSpan={7} className="py-20 text-center text-gray-400 dark:text-gray-600">
                                        <ShoppingCart size={48} className="mx-auto mb-3 opacity-20" />
                                        <p>No purchase orders found.</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <CreatePOModal 
                isOpen={isCreateOpen} 
                onClose={() => setIsCreateOpen(false)} 
                onSubmit={handleCreateSubmit} 
                products={products}
            />
        </div>
    );
};

export default Purchasing;

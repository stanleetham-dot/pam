
import React, { useState, useMemo } from 'react';
import { useInventory } from '../context/InventoryContext';
import { DistributionOrder } from '../types';
import { 
    Truck, MapPin, Search, Calendar, CheckCircle2, 
    XCircle, Clock, Package, ChevronRight, User, 
    Image as ImageIcon, PenTool, FileText, Phone,
    Navigation, X, Building
} from 'lucide-react';

const DeliveryTracking: React.FC = () => {
    const { distributionOrders, drivers, language } = useInventory();
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('ALL');
    const [selectedOrder, setSelectedOrder] = useState<DistributionOrder | null>(null);

    // Derived Stats
    const stats = useMemo(() => {
        return {
            inTransit: distributionOrders.filter(o => o.status === 'In Transit').length,
            delivered: distributionOrders.filter(o => o.status === 'Delivered').length,
            failed: distributionOrders.filter(o => o.status === 'Delivery Failed').length,
            total: distributionOrders.length
        };
    }, [distributionOrders]);

    const filteredOrders = useMemo(() => {
        return distributionOrders.filter(o => {
            const matchesSearch = 
                o.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
                o.deliveryDetails?.recipient.toLowerCase().includes(searchTerm.toLowerCase()) ||
                o.deliveryDetails?.address.toLowerCase().includes(searchTerm.toLowerCase());
            
            const matchesStatus = statusFilter === 'ALL' || o.status === statusFilter;
            
            // Only show relevant statuses for tracking
            const isTrackable = ['Ready to Ship', 'Shipped', 'In Transit', 'Delivered', 'Delivery Failed'].includes(o.status);
            
            return matchesSearch && matchesStatus && isTrackable;
        }).sort((a, b) => new Date(b.createTime).getTime() - new Date(a.createTime).getTime());
    }, [distributionOrders, searchTerm, statusFilter]);

    const getDriverName = (id?: string) => {
        if (!id) return t('Unassigned', '未分配');
        return drivers.find(d => d.id === id)?.name || t('Unknown Driver', '未知司机');
    };

    const getStatusColor = (status: string) => {
        switch(status) {
            case 'Delivered': return 'text-green-600 bg-green-50 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-900';
            case 'Delivery Failed': return 'text-red-600 bg-red-50 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-900';
            case 'In Transit': return 'text-blue-600 bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-900 animate-pulse';
            case 'Ready to Ship': return 'text-amber-600 bg-amber-50 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-900';
            default: return 'text-gray-600 bg-gray-50 border-gray-200 dark:bg-slate-800 dark:text-gray-400 dark:border-slate-700';
        }
    };

    return (
        <div className="flex h-full bg-gray-50 dark:bg-slate-950 transition-colors">
            
            {/* LEFT PANEL: LIST */}
            <div className={`w-full md:w-[450px] flex flex-col border-r border-gray-200 dark:border-slate-800 bg-white dark:bg-slate-900 z-10 ${selectedOrder ? 'hidden md:flex' : 'flex'}`}>
                
                {/* Header & Stats */}
                <div className="p-6 border-b border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
                    <h1 className="text-2xl font-black text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                        <Navigation className="text-blue-600 dark:text-blue-400" />
                        {t('Track Deliveries', '物流追踪')}
                    </h1>
                    
                    <div className="grid grid-cols-3 gap-2 mb-4">
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-xl border border-blue-100 dark:border-blue-900/30 text-center">
                            <span className="block text-2xl font-black text-blue-600 dark:text-blue-400">{stats.inTransit}</span>
                            <span className="text-[10px] font-bold text-blue-400 uppercase">{t('In Transit', '运输中')}</span>
                        </div>
                        <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-xl border border-green-100 dark:border-green-900/30 text-center">
                            <span className="block text-2xl font-black text-green-600 dark:text-green-400">{stats.delivered}</span>
                            <span className="text-[10px] font-bold text-green-400 uppercase">{t('Delivered', '已送达')}</span>
                        </div>
                        <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-xl border border-red-100 dark:border-red-900/30 text-center">
                            <span className="block text-2xl font-black text-red-600 dark:text-red-400">{stats.failed}</span>
                            <span className="text-[10px] font-bold text-red-400 uppercase">{t('Failed', '失败')}</span>
                        </div>
                    </div>

                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                        <input 
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500 transition-colors text-gray-900 dark:text-white placeholder:text-gray-400"
                            placeholder={t("Search order, customer...", "搜索订单、客户...")}
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                {/* Filter Tabs */}
                <div className="flex gap-2 p-2 overflow-x-auto border-b border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-950/30 shrink-0 no-scrollbar">
                    {['ALL', 'In Transit', 'Delivered', 'Delivery Failed', 'Ready to Ship'].map(status => (
                        <button
                            key={status}
                            onClick={() => setStatusFilter(status)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                                statusFilter === status 
                                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm border border-gray-200 dark:border-slate-700' 
                                : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-800'
                            }`}
                        >
                            {status}
                        </button>
                    ))}
                </div>

                {/* Order List */}
                <div className="flex-1 overflow-y-auto p-2 space-y-2 bg-gray-50/30 dark:bg-slate-950/30">
                    {filteredOrders.map(order => (
                        <div 
                            key={order.id}
                            onClick={() => setSelectedOrder(order)}
                            className={`p-4 rounded-xl border cursor-pointer transition-all hover:shadow-md ${
                                selectedOrder?.id === order.id 
                                ? 'bg-blue-50 dark:bg-blue-900/10 border-blue-200 dark:border-blue-800 ring-1 ring-blue-200 dark:ring-blue-800' 
                                : 'bg-white dark:bg-slate-900 border-gray-100 dark:border-slate-800 hover:border-blue-100 dark:hover:border-slate-700'
                            }`}
                        >
                            <div className="flex justify-between items-start mb-2">
                                <span className="font-mono text-xs font-bold text-gray-500 dark:text-gray-400">{order.orderNumber}</span>
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase tracking-wider ${getStatusColor(order.status)}`}>
                                    {order.status}
                                </span>
                            </div>
                            <h3 className="font-bold text-gray-900 dark:text-white text-sm mb-1">{order.deliveryDetails?.recipient || 'Unknown Recipient'}</h3>
                            <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                                <Truck size={12} />
                                <span>{getDriverName(order.assignedDriverId)}</span>
                            </div>
                            <div className="mt-3 pt-3 border-t border-gray-100 dark:border-slate-800 flex justify-between items-center text-xs">
                                <span className="text-gray-400 dark:text-gray-500 flex items-center gap-1">
                                    <Clock size={10} /> {new Date(order.createTime).toLocaleDateString()}
                                </span>
                                <ChevronRight size={14} className="text-gray-300 dark:text-gray-600" />
                            </div>
                        </div>
                    ))}
                    {filteredOrders.length === 0 && (
                        <div className="text-center py-10 text-gray-400 dark:text-gray-600">
                            <Package size={48} className="mx-auto mb-2 opacity-20" />
                            <p className="text-sm font-medium">{t('No shipments found', '未找到运输单')}</p>
                        </div>
                    )}
                </div>
            </div>

            {/* RIGHT PANEL: DETAILS (Mobile: Full Screen, Desktop: Side Panel) */}
            <div className={`flex-1 bg-gray-50 dark:bg-slate-950 flex flex-col h-full overflow-hidden absolute inset-0 md:relative z-20 md:z-0 bg-white md:bg-gray-50 transition-transform duration-300 ${selectedOrder ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}`}>
                
                {selectedOrder ? (
                    <div className="flex flex-col h-full w-full max-w-4xl mx-auto md:p-6">
                        {/* Mobile Back Button */}
                        <div className="md:hidden p-4 border-b border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2">
                            <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full">
                                <X size={20} className="text-gray-600 dark:text-gray-300" />
                            </button>
                            <span className="font-bold text-gray-900 dark:text-white">{t('Shipment Details', '运输详情')}</span>
                        </div>

                        <div className="flex-1 overflow-y-auto space-y-6 p-4 md:p-0">
                            {/* Status Card */}
                            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-6">
                                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                                    <div>
                                        <h2 className="text-2xl font-black text-gray-900 dark:text-white">{selectedOrder.orderNumber}</h2>
                                        <div className="flex items-center gap-4 mt-2">
                                            <div className="flex items-center gap-1.5 text-sm font-medium text-gray-600 dark:text-gray-400">
                                                <Building size={14} />
                                                <span>Branch: <strong>{selectedOrder.receivingBranch || 'Main'}</strong></span>
                                            </div>
                                            <div className="w-1 h-1 bg-gray-300 rounded-full"></div>
                                            <span className="text-xs text-gray-500">{new Date(selectedOrder.createTime).toLocaleString()}</span>
                                        </div>
                                    </div>
                                    <div className={`px-4 py-2 rounded-xl border-2 text-sm font-bold uppercase tracking-wider flex items-center gap-2 ${getStatusColor(selectedOrder.status)}`}>
                                        {selectedOrder.status === 'Delivered' && <CheckCircle2 size={18} />}
                                        {selectedOrder.status === 'In Transit' && <Truck size={18} />}
                                        {selectedOrder.status === 'Delivery Failed' && <XCircle size={18} />}
                                        {selectedOrder.status}
                                    </div>
                                </div>

                                {/* Tracking Timeline with User Attribution */}
                                <div className="relative pl-4 border-l-2 border-gray-100 dark:border-slate-800 space-y-8 my-4 ml-2">
                                    
                                    {/* Created Step */}
                                    <div className="relative group">
                                        <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-blue-500 ring-4 ring-white dark:ring-slate-900 group-hover:scale-110 transition-transform"></div>
                                        <div className="flex flex-col">
                                            <p className="text-sm font-bold text-gray-900 dark:text-white">Order Created</p>
                                            <p className="text-xs text-gray-500 mt-0.5">by <span className="font-bold text-gray-700 dark:text-gray-300">{selectedOrder.creator}</span></p>
                                            <p className="text-[10px] text-gray-400 mt-0.5">{new Date(selectedOrder.createTime).toLocaleString()}</p>
                                        </div>
                                    </div>

                                    {/* Scheduled Step */}
                                    {selectedOrder.scheduledAt && (
                                        <div className="relative group">
                                            <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-blue-500 ring-4 ring-white dark:ring-slate-900 group-hover:scale-110 transition-transform"></div>
                                            <div className="flex flex-col">
                                                <p className="text-sm font-bold text-gray-900 dark:text-white">Scheduled for Delivery</p>
                                                <p className="text-xs text-gray-500 mt-0.5">by <span className="font-bold text-gray-700 dark:text-gray-300">{selectedOrder.scheduledBy || 'System'}</span></p>
                                                <p className="text-[10px] text-gray-400 mt-0.5">{new Date(selectedOrder.scheduledAt).toLocaleString()}</p>
                                            </div>
                                        </div>
                                    )}
                                    
                                    {/* Assigned Step */}
                                    {selectedOrder.assignedAt && (
                                        <div className="relative group">
                                            <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-blue-500 ring-4 ring-white dark:ring-slate-900 group-hover:scale-110 transition-transform"></div>
                                            <div className="flex flex-col">
                                                <p className="text-sm font-bold text-gray-900 dark:text-white">Driver Assigned</p>
                                                <p className="text-xs text-gray-500 mt-0.5">Assigned to: <span className="font-bold text-blue-600 dark:text-blue-400">{getDriverName(selectedOrder.assignedDriverId)}</span></p>
                                                <p className="text-[10px] text-gray-400 mt-0.5">{new Date(selectedOrder.assignedAt).toLocaleString()}</p>
                                            </div>
                                        </div>
                                    )}

                                    {/* Delivery Step */}
                                    {selectedOrder.deliveryTimestamp && (
                                        <div className="relative group">
                                            <div className={`absolute -left-[21px] top-1 w-3 h-3 rounded-full ${selectedOrder.status === 'Delivered' ? 'bg-green-500' : 'bg-red-500'} ring-4 ring-white dark:ring-slate-900 group-hover:scale-110 transition-transform`}></div>
                                            <div className="flex flex-col">
                                                <p className="text-sm font-bold text-gray-900 dark:text-white">
                                                    {selectedOrder.status === 'Delivered' 
                                                        ? (selectedOrder.driverNote?.includes('[Manual Handover]') ? 'Manual Handover Complete' : 'Delivered') 
                                                        : 'Attempted Delivery'}
                                                </p>
                                                <p className="text-xs text-gray-500 mt-0.5">
                                                    {selectedOrder.driverNote?.includes('[Manual Handover]') ? (
                                                         <>
                                                            Authorized by <span className="font-bold text-amber-600 dark:text-amber-400">
                                                                {selectedOrder.driverNote.split('Authorized by: ')[1]?.split('.')[0] || 'Staff'}
                                                            </span>
                                                         </>
                                                    ) : (
                                                         <>by Driver <span className="font-bold text-blue-600 dark:text-blue-400">{getDriverName(selectedOrder.assignedDriverId)}</span></>
                                                    )}
                                                </p>
                                                <p className="text-[10px] text-gray-400 mt-0.5">{new Date(selectedOrder.deliveryTimestamp).toLocaleString()}</p>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Driver & Location */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-6">
                                    <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-2"><User size={16}/> Driver Info</h3>
                                    <div className="flex items-center gap-4">
                                        <div className="w-12 h-12 bg-gray-100 dark:bg-slate-800 rounded-full flex items-center justify-center text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-slate-700">
                                            <User size={24} />
                                        </div>
                                        <div>
                                            <p className="font-bold text-gray-900 dark:text-white">{getDriverName(selectedOrder.assignedDriverId)}</p>
                                            <p className="text-sm text-gray-500 dark:text-gray-400 italic">"{selectedOrder.driverNote || t('No specific instructions', '无特定指示')}"</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-6">
                                    <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-2"><MapPin size={16}/> Destination</h3>
                                    <p className="font-bold text-gray-900 dark:text-white">{selectedOrder.deliveryDetails?.recipient}</p>
                                    <p className="text-sm text-gray-600 dark:text-gray-300 mt-1 leading-relaxed">
                                        {selectedOrder.deliveryDetails?.address}
                                        {selectedOrder.deliveryDetails?.unit && `, ${selectedOrder.deliveryDetails.unit}`}
                                    </p>
                                    <div className="flex gap-2 mt-4">
                                        <span className="px-2 py-1 bg-gray-100 dark:bg-slate-800 rounded text-xs font-mono font-bold text-gray-600 dark:text-gray-400">{selectedOrder.deliveryDetails?.postCode}</span>
                                        <span className="px-2 py-1 bg-gray-100 dark:bg-slate-800 rounded text-xs font-bold text-gray-600 dark:text-gray-400 flex items-center gap-1"><Phone size={10} /> {selectedOrder.deliveryDetails?.phone}</span>
                                    </div>
                                </div>
                            </div>

                            {/* PROOF OF DELIVERY (Only if Delivered/Attempted) */}
                            {(selectedOrder.proofOfDelivery || selectedOrder.signature || selectedOrder.driverNote) && (
                                <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 p-6">
                                    <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-6 flex items-center gap-2">
                                        <CheckCircle2 size={16} className="text-green-500" /> Proof of Delivery
                                    </h3>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                        {/* Photo */}
                                        {selectedOrder.proofOfDelivery ? (
                                            <div className="space-y-2">
                                                <span className="text-xs font-bold text-gray-500 flex items-center gap-1"><ImageIcon size={12}/> Photo Evidence</span>
                                                <div className="rounded-xl overflow-hidden border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 bg-black/5 dark:bg-black/40">
                                                    <img 
                                                        src={selectedOrder.proofOfDelivery} 
                                                        alt="POD" 
                                                        className="w-full h-auto max-h-96 object-contain mx-auto hover:scale-105 transition-transform cursor-zoom-in" 
                                                        onClick={() => window.open(selectedOrder.proofOfDelivery, '_blank')} 
                                                    />
                                                </div>
                                            </div>
                                        ) : (
                                            <div className="h-48 rounded-xl border-2 border-dashed border-gray-200 dark:border-slate-700 flex flex-col items-center justify-center text-gray-400">
                                                <ImageIcon size={24} className="mb-2 opacity-50" />
                                                <span className="text-xs">No Photo</span>
                                            </div>
                                        )}

                                        <div className="space-y-6">
                                            {/* Signature */}
                                            <div className="space-y-2">
                                                <span className="text-xs font-bold text-gray-500 flex items-center gap-1"><PenTool size={12}/> {selectedOrder.driverNote?.includes('[Manual Handover]') ? 'Authorized Signature' : 'Customer Signature'}</span>
                                                {selectedOrder.signature ? (
                                                    <div className="h-24 bg-gray-50 dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-2 flex items-center justify-center">
                                                        <img src={selectedOrder.signature} alt="Signature" className="max-h-full max-w-full mix-blend-multiply dark:mix-blend-screen" />
                                                    </div>
                                                ) : (
                                                    <div className="h-24 bg-gray-50 dark:bg-slate-800 rounded-xl border-2 border-dashed border-gray-200 dark:border-slate-700 flex items-center justify-center text-gray-400 text-xs">
                                                        No Signature
                                                    </div>
                                                )}
                                            </div>

                                            {/* Note */}
                                            {selectedOrder.driverNote && (
                                                <div className="space-y-2">
                                                    <span className="text-xs font-bold text-gray-500 flex items-center gap-1"><FileText size={12}/> {selectedOrder.driverNote?.includes('[Manual Handover]') ? 'Handover Note' : 'Driver Note'}</span>
                                                    <div className="p-3 bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-100 dark:border-yellow-900/30 rounded-lg text-sm text-yellow-800 dark:text-yellow-200 italic">
                                                        "{selectedOrder.driverNote}"
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400 dark:text-gray-600">
                        <Truck size={64} className="mb-4 opacity-20" />
                        <p className="text-lg font-bold">Select a shipment</p>
                        <p className="text-sm">View details and proof of delivery.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default DeliveryTracking;

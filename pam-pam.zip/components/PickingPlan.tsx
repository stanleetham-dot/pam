
import React, { useState } from 'react';
import { ClipboardList, ArrowRight, MapPin, Zap, CheckCircle2 } from 'lucide-react';
import { PickingPlan } from '../types';

const PickingPlanView: React.FC = () => {
    const [plans, setPlans] = useState<PickingPlan[]>([
        { 
            id: '1', orderId: 'ORD-1001', status: 'PENDING', priority: 'HIGH',
            items: [
                { productId: '1', name: 'Wireless Mouse', location: 'AZ01-3-5B', qty: 2, picked: false },
                { productId: '5', name: 'USB-C Cable', location: 'AZ02-1-4A', qty: 5, picked: false },
            ]
        },
        { 
            id: '2', orderId: 'ORD-1002', status: 'IN_PROGRESS', priority: 'NORMAL',
            items: [
                { productId: '3', name: 'Almond Milk', location: 'BZ05-1-2C', qty: 12, picked: true },
                { productId: '2', name: 'Mech Keyboard', location: 'AZ01-2-1A', qty: 1, picked: false },
            ]
        }
    ]);

    const handleOptimize = (id: string) => {
        setPlans(prev => prev.map(plan => {
            if (plan.id === id) {
                const sortedItems = [...plan.items].sort((a, b) => a.location.localeCompare(b.location));
                return { ...plan, items: sortedItems };
            }
            return plan;
        }));
    };

    return (
        <div className="p-6 bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors duration-300">
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6 flex items-center gap-2">
                <ClipboardList className="text-blue-600 dark:text-blue-400" /> Picking Plans
            </h1>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {plans.map(plan => (
                    <div key={plan.id} className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden transition-colors">
                        <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-950/50">
                            <div>
                                <h3 className="font-bold text-gray-800 dark:text-white">{plan.orderId}</h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 flex items-center gap-1">
                                    {plan.priority === 'HIGH' && <span className="text-red-500 dark:text-red-400 font-bold">HIGH PRIORITY</span>}
                                    <span>• {plan.items.length} Items</span>
                                </p>
                            </div>
                            <div className="flex gap-2">
                                <span className={`px-2 py-1 rounded text-xs font-bold ${
                                    plan.status === 'PENDING' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400' : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                                }`}>
                                    {plan.status}
                                </span>
                                <button 
                                    onClick={() => handleOptimize(plan.id)}
                                    className="p-1.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded hover:text-blue-600 dark:hover:text-blue-400 hover:border-blue-300 dark:hover:border-blue-700 transition-colors shadow-sm"
                                    title="Optimize Route"
                                >
                                    <Zap size={16} />
                                </button>
                            </div>
                        </div>
                        <div className="p-2 bg-white dark:bg-slate-900">
                            {plan.items.map((item, idx) => (
                                <div key={idx} className="flex items-center gap-3 p-3 border-b border-gray-50 dark:border-slate-800 last:border-0 hover:bg-gray-50 dark:hover:bg-slate-800/50 rounded-lg transition-colors">
                                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${item.picked ? 'bg-green-500 border-green-500 text-white' : 'border-gray-300 dark:border-slate-700'}`}>
                                        {item.picked && <CheckCircle2 size={14} />}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{item.name}</p>
                                        <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                                            <MapPin size={12} className="text-gray-400 dark:text-gray-600" /> {item.location}
                                        </div>
                                    </div>
                                    <div className="text-right font-bold text-gray-700 dark:text-gray-300 text-lg tabular-nums">
                                        x{item.qty}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="p-3 bg-gray-50 dark:bg-slate-950 border-t border-gray-100 dark:border-slate-800 text-center transition-colors">
                            <button className="text-blue-600 dark:text-blue-400 text-sm font-bold flex items-center justify-center gap-1 hover:underline mx-auto">
                                Start Picking <ArrowRight size={16} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default PickingPlanView;

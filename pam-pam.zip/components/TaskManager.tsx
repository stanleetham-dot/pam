
import React, { useState, useMemo, useEffect } from 'react';
import { useInventory } from '../context/InventoryContext';
import { 
    CheckSquare, Plus, Calendar, Trash2, 
    X, Check, Bell, BellOff, Clock,
    Settings2, Volume2, Music, ArrowUp,
    Filter, ArrowDownWideNarrow, AlertCircle,
    MoreVertical, Flag, CalendarDays
} from 'lucide-react';
import { Task, NotificationSettings } from '../types';

interface DeleteConfirmModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    taskTitle: string;
}

const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({ isOpen, onClose, onConfirm, taskTitle }) => {
    useEffect(() => {
        const handleEscape = (e: KeyboardEvent) => {
            if (e.key === 'Escape') onClose();
        };
        if (isOpen) {
            window.addEventListener('keydown', handleEscape);
        }
        return () => window.removeEventListener('keydown', handleEscape);
    }, [isOpen, onClose]);

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 backdrop-blur-sm transition-all duration-200"
            onClick={onClose}
        >
            <div 
                className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl p-6 max-w-sm w-full animate-in fade-in zoom-in-95 duration-200 border border-gray-100 dark:border-slate-800"
                onClick={e => e.stopPropagation()}
            >
                <div className="flex flex-col items-center text-center">
                    <div className="w-14 h-14 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-full flex items-center justify-center mb-5 border-4 border-red-100 dark:border-red-900/30">
                        <Trash2 size={28} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Delete Task?</h3>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mb-8 leading-relaxed">
                        Are you sure you want to permanently remove <span className="font-bold text-gray-800 dark:text-gray-200">"{taskTitle}"</span>?
                    </p>
                    <div className="flex gap-3 w-full">
                        <button onClick={onClose} className="flex-1 px-4 py-3 bg-gray-50 dark:bg-slate-800 text-gray-700 dark:text-gray-300 font-bold rounded-xl hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors outline-none">Cancel</button>
                        <button onClick={onConfirm} className="flex-1 px-4 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-200 dark:shadow-none transition-all hover:scale-[1.02] active:scale-[0.98]">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

const getSmartDate = (dateStr?: string) => {
    if (!dateStr) return null;
    const d = new Date(dateStr);
    const today = new Date();
    today.setHours(0,0,0,0);
    
    const target = new Date(d);
    target.setHours(0,0,0,0);
    
    const diffTime = target.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { text: 'Overdue', color: 'text-red-500 font-bold' };
    if (diffDays === 0) return { text: 'Today', color: 'text-orange-500 font-bold' };
    if (diffDays === 1) return { text: 'Tomorrow', color: 'text-blue-500 font-bold' };
    return { text: d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), color: 'text-gray-400' };
};

const TaskManager: React.FC = () => {
    const { tasks, addTask, toggleTaskCompletion, deleteTask, currentUser, updateNotificationSettings } = useInventory();
    
    const [newTaskTitle, setNewTaskTitle] = useState('');
    const [newTaskDueDate, setNewTaskDueDate] = useState('');
    const [newTaskPriority, setNewTaskPriority] = useState<'HIGH' | 'MEDIUM' | 'LOW'>('MEDIUM');
    const [sortBy, setSortBy] = useState<'CREATED' | 'DUE_DATE' | 'PRIORITY'>('PRIORITY');
    const [filter, setFilter] = useState<'ALL' | 'ACTIVE' | 'COMPLETED'>('ACTIVE');
    const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);
    const [notificationsEnabled, setNotificationsEnabled] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const [isAddOpen, setIsAddOpen] = useState(false);
    
    const defaultSettings: NotificationSettings = {
        alertTiming: 60,
        enableSound: true,
        soundType: 'chime'
    };

    const settings = currentUser?.notificationSettings || defaultSettings;

    useEffect(() => {
        if ('Notification' in window) {
            setNotificationsEnabled(Notification.permission === 'granted');
        }
    }, []);

    const requestNotificationPermission = async () => {
        if (!('Notification' in window)) return;
        const permission = await Notification.requestPermission();
        setNotificationsEnabled(permission === 'granted');
    };

    const handleAddTask = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newTaskTitle.trim()) return;
        addTask(newTaskTitle, newTaskDueDate || undefined, newTaskPriority);
        setNewTaskTitle('');
        setNewTaskDueDate('');
        setNewTaskPriority('MEDIUM');
        setIsAddOpen(false);
    };

    const sortedTasks = useMemo(() => {
        let result = tasks;
        
        // Filter
        if (filter === 'ACTIVE') result = result.filter(t => !t.isCompleted);
        if (filter === 'COMPLETED') result = result.filter(t => t.isCompleted);

        // Sort
        return result.sort((a, b) => {
            // Completed tasks usually at bottom if sorting mixed, but here we strictly follow sort criteria or split by completion
            if (filter === 'ALL' && a.isCompleted !== b.isCompleted) return a.isCompleted ? 1 : -1;
            
            let diff = 0;
            if (sortBy === 'DUE_DATE') {
                if (a.dueDate && !b.dueDate) diff = -1;
                else if (!a.dueDate && b.dueDate) diff = 1;
                else if (!a.dueDate && !b.dueDate) diff = 0;
                else diff = new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime();
            } else if (sortBy === 'PRIORITY') {
                const map: Record<string, number> = { 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3 };
                diff = (map[a.priority || 'MEDIUM'] ?? 2) - (map[b.priority || 'MEDIUM'] ?? 2);
            } else {
                // Created
                diff = new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
            }
            return diff;
        });
    }, [tasks, sortBy, filter]);

    const stats = {
        active: tasks.filter(t => !t.isCompleted).length,
        completed: tasks.filter(t => t.isCompleted).length,
        highPriority: tasks.filter(t => !t.isCompleted && t.priority === 'HIGH').length
    };

    const priorityConfig = {
        HIGH: { color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', icon: AlertCircle },
        MEDIUM: { color: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400', icon: Clock },
        LOW: { color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400', icon: Flag }
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 transition-colors overflow-hidden">
            
            {/* Header Section */}
            <div className="shrink-0 p-6 md:px-10 md:pt-10 md:pb-4 z-20 bg-gray-50 dark:bg-slate-950 transition-colors">
                <div className="max-w-4xl mx-auto w-full">
                    {/* Title & Main Actions */}
                    <div className="flex justify-between items-end mb-6">
                        <div>
                            <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white mb-1 tracking-tight">Task Board</h1>
                            <p className="text-gray-500 dark:text-gray-400 text-sm font-medium flex items-center gap-2">
                                You have <span className="text-blue-600 dark:text-blue-400 font-bold">{stats.active}</span> pending tasks
                                {stats.highPriority > 0 && <span className="text-red-500 font-bold ml-1">• {stats.highPriority} High Priority</span>}
                            </p>
                        </div>
                        <div className="flex gap-2">
                            <button 
                                onClick={() => setShowSettings(!showSettings)}
                                className={`p-2.5 rounded-xl transition-all ${showSettings ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' : 'bg-white dark:bg-slate-900 text-gray-400 border border-gray-200 dark:border-slate-800 hover:bg-gray-100 dark:hover:bg-slate-800'}`}
                                title="Notification Settings"
                            >
                                <Settings2 size={20} />
                            </button>
                        </div>
                    </div>

                    {/* Settings Panel */}
                    {showSettings && (
                        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-lg border border-gray-200 dark:border-slate-800 mb-6 animate-in slide-in-from-top-2">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-sm font-bold text-gray-700 dark:text-gray-200 uppercase flex items-center gap-2">
                                    <Bell size={14} className="text-blue-500"/> Preferences
                                </h3>
                                <button 
                                    onClick={notificationsEnabled ? () => setNotificationsEnabled(false) : requestNotificationPermission}
                                    className={`text-xs font-bold px-3 py-1 rounded-full transition-colors ${notificationsEnabled ? 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400' : 'bg-gray-100 text-gray-500 dark:bg-slate-800'}`}
                                >
                                    {notificationsEnabled ? 'Notifications On' : 'Enable Notifications'}
                                </button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-1.5">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase">Alert Timing</label>
                                    <select 
                                        className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-100 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
                                        value={settings.alertTiming}
                                        onChange={e => updateNotificationSettings({...settings, alertTiming: parseInt(e.target.value)})}
                                    >
                                        <option value={15}>15 mins before</option>
                                        <option value={30}>30 mins before</option>
                                        <option value={60}>1 hour before</option>
                                        <option value={1440}>1 day before</option>
                                    </select>
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase">Alert Sound</label>
                                    <div className="flex gap-2">
                                        <select 
                                            className="flex-1 bg-gray-50 dark:bg-slate-800 border border-gray-100 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
                                            value={settings.soundType}
                                            onChange={e => updateNotificationSettings({...settings, soundType: e.target.value as any})}
                                        >
                                            <option value="default">Default Alert</option>
                                            <option value="chime">Gentle Chime</option>
                                            <option value="pulse">Digital Pulse</option>
                                        </select>
                                        <button 
                                            onClick={() => updateNotificationSettings({...settings, enableSound: !settings.enableSound})}
                                            className={`px-3 rounded-lg transition-colors ${settings.enableSound ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30' : 'bg-gray-100 text-gray-400 dark:bg-slate-800'}`}
                                        >
                                            {settings.enableSound ? <Volume2 size={18}/> : <BellOff size={18}/>}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Filters & Actions Bar */}
                    <div className="flex flex-col sm:flex-row gap-3 justify-between items-center bg-white dark:bg-slate-900 p-2 rounded-2xl border border-gray-200 dark:border-slate-800 shadow-sm relative z-20">
                        <div className="flex bg-gray-100 dark:bg-slate-800 p-1 rounded-xl w-full sm:w-auto">
                            {['ACTIVE', 'COMPLETED', 'ALL'].map(f => (
                                <button
                                    key={f}
                                    onClick={() => setFilter(f as any)}
                                    className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all ${filter === f ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'}`}
                                >
                                    {f === 'ACTIVE' ? 'Active' : f === 'COMPLETED' ? 'Done' : 'All'}
                                </button>
                            ))}
                        </div>
                        
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                            <div className="relative flex-1 sm:flex-none">
                                <select 
                                    className="w-full sm:w-auto bg-transparent text-xs font-bold text-gray-600 dark:text-gray-300 outline-none cursor-pointer pl-2 pr-6 py-2 hover:bg-gray-50 dark:hover:bg-slate-800 rounded-lg appearance-none"
                                    value={sortBy}
                                    onChange={(e) => setSortBy(e.target.value as any)}
                                >
                                    <option value="PRIORITY">Priority First</option>
                                    <option value="DUE_DATE">Due Date First</option>
                                    <option value="CREATED">Recently Added</option>
                                </select>
                                <ArrowDownWideNarrow size={14} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
                            </div>
                            
                            <button 
                                onClick={() => setIsAddOpen(!isAddOpen)}
                                className={`px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold transition-all shadow-sm active:scale-95 ${isAddOpen ? 'bg-gray-200 dark:bg-slate-700 text-gray-800 dark:text-white' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
                            >
                                <Plus size={16} className={`transition-transform duration-300 ${isAddOpen ? 'rotate-45' : ''}`}/>
                                {isAddOpen ? 'Close' : 'New Task'}
                            </button>
                        </div>
                    </div>

                    {/* Add Task Form (Collapsible) */}
                    <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isAddOpen ? 'max-h-96 opacity-100 mt-4' : 'max-h-0 opacity-0'}`}>
                        <form onSubmit={handleAddTask} className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800">
                             <div className="flex flex-col gap-3">
                                 <input 
                                     className="w-full text-lg font-bold placeholder:text-gray-300 dark:placeholder:text-gray-600 bg-transparent outline-none text-gray-900 dark:text-white" 
                                     placeholder="What needs to be done?" 
                                     value={newTaskTitle} 
                                     autoFocus={isAddOpen}
                                     onChange={e => setNewTaskTitle(e.target.value)} 
                                 />
                                 <div className="flex flex-wrap gap-2 items-center">
                                     <div className="flex items-center gap-2 bg-gray-50 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-gray-100 dark:border-slate-700">
                                         <Calendar size={14} className="text-gray-400"/>
                                         <input 
                                             type="date" 
                                             className="bg-transparent text-xs font-bold text-gray-600 dark:text-gray-300 outline-none"
                                             value={newTaskDueDate}
                                             onChange={e => setNewTaskDueDate(e.target.value)}
                                         />
                                     </div>
                                     <div className="flex bg-gray-50 dark:bg-slate-800 p-1 rounded-lg border border-gray-100 dark:border-slate-700">
                                         {['HIGH', 'MEDIUM', 'LOW'].map(p => (
                                             <button
                                                 key={p}
                                                 type="button"
                                                 onClick={() => setNewTaskPriority(p as any)}
                                                 className={`px-3 py-1 rounded-md text-[10px] font-bold transition-colors ${newTaskPriority === p ? priorityConfig[p as keyof typeof priorityConfig].color : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'}`}
                                             >
                                                 {p}
                                             </button>
                                         ))}
                                     </div>
                                     <div className="flex-1 text-right">
                                         <button 
                                             type="submit" 
                                             disabled={!newTaskTitle.trim()}
                                             className="bg-blue-600 text-white px-6 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
                                         >
                                             Add Task
                                         </button>
                                     </div>
                                 </div>
                             </div>
                        </form>
                    </div>
                </div>
            </div>

            {/* Task List */}
            <div className="flex-1 overflow-y-auto px-6 md:px-10 pb-20 pt-2 space-y-3">
                <div className="max-w-4xl mx-auto w-full space-y-3">
                    {sortedTasks.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-24 text-center">
                            <div className="w-20 h-20 bg-gray-100 dark:bg-slate-900 rounded-full flex items-center justify-center mb-4">
                                <CheckSquare size={32} className="text-gray-300 dark:text-slate-700" />
                            </div>
                            <h3 className="text-lg font-bold text-gray-400 dark:text-gray-500">No tasks found</h3>
                            <p className="text-sm text-gray-400 dark:text-gray-600">Enjoy your free time or add a new task!</p>
                        </div>
                    ) : (
                        sortedTasks.map(task => {
                            const dateInfo = getSmartDate(task.dueDate);
                            const PriorityIcon = priorityConfig[task.priority || 'MEDIUM'].icon;
                            
                            return (
                                <div 
                                    key={task.id} 
                                    className={`group relative bg-white dark:bg-slate-900 p-4 rounded-xl border transition-all duration-300 hover:shadow-md flex items-center gap-4 
                                        ${task.isCompleted 
                                            ? 'border-gray-100 dark:border-slate-800 opacity-60 bg-gray-50/50 dark:bg-slate-900/50' 
                                            : 'border-gray-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700'
                                        }`
                                    }
                                >
                                    <button 
                                        onClick={() => toggleTaskCompletion(task.id)} 
                                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-300 shrink-0 ${task.isCompleted ? 'bg-blue-500 border-blue-500 text-white scale-110' : 'border-gray-300 dark:border-slate-600 hover:border-blue-400 text-transparent'}`}
                                    >
                                        <Check size={12} strokeWidth={4} />
                                    </button>
                                    
                                    <div className="flex-1 min-w-0">
                                        <div className="flex justify-between items-start">
                                            <p className={`font-semibold text-base text-gray-900 dark:text-white truncate pr-2 transition-all ${task.isCompleted ? 'line-through text-gray-400 dark:text-gray-500' : ''}`}>
                                                {task.title}
                                            </p>
                                            {!task.isCompleted && (
                                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 shrink-0 ${priorityConfig[task.priority || 'MEDIUM'].color}`}>
                                                    <PriorityIcon size={10} /> {task.priority}
                                                </span>
                                            )}
                                        </div>
                                        
                                        <div className="flex items-center gap-4 mt-1.5">
                                            {dateInfo && (
                                                <span className={`text-xs flex items-center gap-1.5 ${task.isCompleted ? 'text-gray-400' : dateInfo.color}`}>
                                                    <CalendarDays size={12} /> {dateInfo.text}
                                                </span>
                                            )}
                                            {task.isCompleted && (
                                                 <span className="text-[10px] font-bold text-green-600 dark:text-green-500 bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded">Completed</span>
                                            )}
                                        </div>
                                    </div>

                                    <button 
                                        onClick={() => setTaskToDelete(task)} 
                                        className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all opacity-0 group-hover:opacity-100 focus:opacity-100"
                                        title="Delete Task"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </div>
                            );
                        })
                    )}
                </div>
            </div>

            <DeleteConfirmModal isOpen={!!taskToDelete} onClose={() => setTaskToDelete(null)} onConfirm={() => { if(taskToDelete) deleteTask(taskToDelete.id); setTaskToDelete(null); }} taskTitle={taskToDelete?.title || ''} />
        </div>
    );
};

export default TaskManager;

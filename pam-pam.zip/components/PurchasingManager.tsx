
import React, { useState, useMemo, useRef } from 'react';
import { useInventory } from '../context/InventoryContext';
import { ReceivingOrder, ReceivingOrderItem, Product } from '../types';
import { 
    Search, Plus, Save, ArrowLeft, Trash2,
    CheckCircle2, Scan, FileText, XCircle, UploadCloud, FileDown,
    X, Package, RotateCcw, MapPin, Minus
} from 'lucide-react';
import Scanner from './Scanner';
import * as XLSX from 'xlsx';

const getStatusColor = (status: string) => {
    switch (status) {
        case 'APPROVED': return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-300 dark:border-emerald-500/30';
        case 'REJECTED': return 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-500/20 dark:text-rose-300 dark:border-rose-500/30';
        case 'PENDING': return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-300 dark:border-amber-500/30';
        default: return 'bg-slate-50 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700';
    }
};

export default function PurchasingManager() {
    const { 
        receivingOrders, addReceivingOrder, updateReceivingOrder, deleteReceivingOrder, approveReceivingOrder, rejectReceivingOrder, undoReceivingOrder,
        products, warehouses, language, checkPermission
    } = useInventory();

    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    const [view, setView] = useState<'LIST' | 'EDIT'>('LIST');
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('ALL');
    
    // Permission Checks
    const canCreate = checkPermission('RECEIVING_ORDERS', 'create');
    const canEdit = checkPermission('RECEIVING_ORDERS', 'edit');
    const canDelete = checkPermission('RECEIVING_ORDERS', 'delete');
    
    // Edit State
    const [formData, setFormData] = useState<Partial<ReceivingOrder>>({});
    const [items, setItems] = useState<ReceivingOrderItem[]>([]);
    
    // Helper State
    const [isScannerOpen, setIsScannerOpen] = useState(false);
    const [showProductPicker, setShowProductPicker] = useState(false);
    const [pickerSearch, setPickerSearch] = useState('');
    
    // Item Input & Filter State
    const [itemTableFilter, setItemTableFilter] = useState('');
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    const filterInputRef = useRef<HTMLInputElement>(null);

    const filteredOrders = useMemo(() => {
        return receivingOrders.filter(o => {
            const matchesSearch = o.receivingSerial.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                  o.supplierName.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesStatus = statusFilter === 'ALL' || o.reviewStatus === statusFilter;
            return matchesSearch && matchesStatus;
        });
    }, [receivingOrders, searchTerm, statusFilter]);

    const filteredProducts = useMemo(() => {
        return products.filter(p => 
            p.name.toLowerCase().includes(pickerSearch.toLowerCase()) || 
            p.sku.toLowerCase().includes(pickerSearch.toLowerCase()) ||
            p.barcode.includes(pickerSearch)
        ).slice(0, 10);
    }, [products, pickerSearch]);

    // Filter Items in the table
    const filteredItems = useMemo(() => {
        if (!itemTableFilter) return items;
        const lowerFilter = itemTableFilter.toLowerCase();
        return items.filter(i => 
            i.productName.toLowerCase().includes(lowerFilter) || 
            i.productCode.toLowerCase().includes(lowerFilter) ||
            i.productId === itemTableFilter
        );
    }, [items, itemTableFilter]);

    const handleCreate = () => {
        if (!canCreate) return;
        // Find default main warehouse
        const mainWarehouse = warehouses.find(w => w.isMain || w.type === 'MAIN');

        setFormData({
            receivingSerial: `REC-${Date.now()}`,
            purchaseSerial: '',
            supplierName: '',
            receivingBranch: mainWarehouse ? mainWarehouse.name : '', 
            receiptDate: new Date().toISOString().split('T')[0],
            reviewStatus: 'PENDING',
            numberOfPieces: 0,
            remarks: ''
        });
        setItems([]);
        setItemTableFilter('');
        setView('EDIT');
    };

    const handleEdit = (order: ReceivingOrder) => {
        setFormData({ ...order });
        setItems(order.items ? [...order.items] : []);
        setItemTableFilter('');
        setView('EDIT');
    };

    const saveOrder = () => { if (!canEdit) return; if (!formData.receivingSerial || !formData.supplierName) { alert("Please fill in required fields."); return; } const orderData = { ...formData, items: items, numberOfPieces: items.reduce((sum, item) => sum + (item.receivedQty || 0), 0) } as ReceivingOrder; if (formData.id) { updateReceivingOrder(orderData); } else { addReceivingOrder(orderData); } setView('LIST'); };
    const onDelete = (id: string, e?: React.MouseEvent) => { if (e) e.stopPropagation(); if (!canDelete) return; if (confirm("Are you sure you want to delete this receiving order? This action cannot be undone.")) { deleteReceivingOrder(id); setView('LIST'); } };
    const handleApprove = () => { if (formData.id) { approveReceivingOrder(formData.id); setView('LIST'); } };
    const handleReject = () => { if (formData.id) { if (confirm(t("Are you sure you want to reject this order?", "您确定要拒绝此订单吗？"))) { rejectReceivingOrder(formData.id); setView('LIST'); } } };
    const handleUndo = () => { if (formData.id) { if (confirm(t("Undo review status? This will revert the order to Pending.", "撤销审核状态？这将使订单恢复为待处理。"))) { undoReceivingOrder(formData.id); setView('LIST'); } } };
    const addItem = (product: Product) => { if (!canEdit) return; if (items.some(i => i.productId === product.id)) return; const newItem: ReceivingOrderItem = { id: crypto.randomUUID(), orderId: formData.id || '', productId: product.id, productCode: product.barcode, productName: product.name, specification: product.specification, unit: product.unit, purchaseUnit: 'BOX', orderQty: 1, receivedQty: 1, storageLocation: product.location, category: product.category, inventoryQty: product.stock }; setItems(prev => [newItem, ...prev]); setShowProductPicker(false); setPickerSearch(''); };
    const updateItem = (id: string, updates: Partial<ReceivingOrderItem>) => { if (!canEdit) return; setItems(prevItems => prevItems.map(item => { if (item.id === id) { return { ...item, ...updates }; } return item; })); };
    const removeItem = (id: string) => { if (!canEdit) return; setItems(items.filter(i => i.id !== id)); };
    const handleScanInput = (code: string) => { if (!canEdit) return; const term = code.trim(); if (!term) return; const product = products.find(p => p.barcode === term || p.sku === term); if (product) { const existingItem = items.find(i => i.productId === product.id); if (existingItem) { updateItem(existingItem.id, { receivedQty: (existingItem.receivedQty || 0) + 1 }); } else { addItem(product); } setItemTableFilter(term); setTimeout(() => { if (filterInputRef.current) { filterInputRef.current.focus(); filterInputRef.current.select(); } }, 50); } else { setItemTableFilter(term); alert(`Product with code "${term}" not found in database.`); } };
    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => { if (e.key === 'Enter') { e.preventDefault(); handleScanInput(itemTableFilter); } };
    const getItemStatus = (item: ReceivingOrderItem) => { const rcv = item.receivedQty || 0; const ord = item.orderQty || 0; if (rcv === 0) return { label: 'Not Received', color: 'bg-slate-100 text-slate-600 border-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700' }; if (rcv === ord) return { label: 'Received', color: 'bg-emerald-100 text-emerald-700 border-emerald-300 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800' }; return { label: 'Discrepancy', color: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-900/30 dark:text-amber-400 dark:border-amber-800' }; };
    const handleDownloadTemplate = () => { const headers = ['no.', 'Purchase unit', 'Basic unit', 'Product code', 'Product name', 'Product spec', 'Order quantity', 'Received quantity', 'Remarks', 'Storage location', 'Product category', 'Inventory quantity']; const ws = XLSX.utils.aoa_to_sheet([headers]); const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Template"); XLSX.writeFile(wb, "Receiving_Items_Template.xlsx"); };
    const handleImportItems = (e: React.ChangeEvent<HTMLInputElement>) => { if (!canCreate) return; const file = e.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = (evt) => { try { const data = evt.target?.result; const wb = XLSX.read(data, { type: 'array' }); const ws = wb.Sheets[wb.SheetNames[0]]; const jsonData = XLSX.utils.sheet_to_json<any>(ws); if (jsonData.length === 0) { alert("File is empty."); return; } const newItems: ReceivingOrderItem[] = []; jsonData.forEach((row, index) => { const code = row['Product code'] || row['Product Code'] || row['商品代码'] || ''; const name = row['Product name'] || row['Product Name'] || row['商品名称'] || 'Unknown'; const product = products.find(p => (code && p.sku === code) || (code && p.barcode === code) || (name && p.name === name) ); if (items.some(i => (product && i.productId === product.id) || (code && i.productCode === code))) return; const item: ReceivingOrderItem = { id: crypto.randomUUID(), orderId: formData.id || '', productId: product?.id || 'UNKNOWN', productCode: code || product?.barcode || 'N/A', productName: name, specification: row['Product spec'] || row['Product Spec'] || row['商品规格'] || product?.specification || '', unit: row['Basic unit'] || row['Basic Unit'] || row['基本单位'] || product?.unit || 'PCS', purchaseUnit: row['Purchase unit'] || row['Purchase Unit'] || row['采购单位'] || 'BOX', orderQty: Number(row['Order quantity'] || row['Order Quantity'] || row['订购数量'] || 0), receivedQty: Number(row['Received quantity'] || row['Received Quantity'] || row['收货数量'] || row['Order quantity'] || 0), storageLocation: row['Storage location'] || row['Storage Location'] || row['仓储位置'] || product?.location || '', category: row['Product category'] || row['Product Category'] || row['商品类别'] || product?.category || 'General', inventoryQty: Number(row['Inventory quantity'] || row['Inventory Quantity'] || row['库存数量'] || product?.stock || 0), remarks: row['Remarks'] || row['备注'] || '' }; newItems.push(item); }); if (newItems.length > 0) { setItems(prev => [...prev, ...newItems]); alert(`Successfully imported ${newItems.length} items.`); } else { alert("No valid items found to import or all items already exist in the list."); } } catch (err) { console.error("Import Error", err); alert("Failed to parse Excel file."); } finally { if (fileInputRef.current) fileInputRef.current.value = ''; } }; reader.readAsArrayBuffer(file); };

    if (view === 'LIST') {
        return (
            <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 transition-colors">
                <div className="shrink-0 p-6 pb-2">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                        <div>
                            <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white flex items-center gap-2">
                                <FileText size={28} className="text-blue-600 dark:text-blue-400" />
                                Receiving Orders
                            </h1>
                            <p className="text-gray-500 dark:text-gray-400 mt-1 font-medium ml-1">Manage inbound stock and supplier receipts.</p>
                        </div>
                        {canCreate && (
                            <button onClick={handleCreate} className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg transition-all flex items-center gap-2 active:scale-95">
                                <Plus size={18} /> New Receipt
                            </button>
                        )}
                    </div>

                    <div className="bg-white dark:bg-slate-900 p-1.5 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col md:flex-row gap-2 transition-colors mb-4">
                        <div className="relative flex-1">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                            <input 
                                className="w-full pl-12 pr-4 py-3 bg-transparent text-gray-900 dark:text-white placeholder:text-gray-400 outline-none text-sm font-medium"
                                placeholder="Search serial number or supplier..." 
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="flex gap-2 p-1 overflow-x-auto no-scrollbar">
                            {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map(status => (
                                <button 
                                    key={status} 
                                    onClick={() => setStatusFilter(status)}
                                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap border ${
                                        statusFilter === status 
                                        ? 'bg-blue-600 text-white border-blue-600 shadow-md' 
                                        : 'bg-gray-50 dark:bg-slate-800 text-gray-600 dark:text-gray-400 border-gray-200 dark:border-slate-700 hover:bg-gray-100 dark:hover:bg-slate-700'
                                    }`}
                                >
                                    {status}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="flex-1 overflow-hidden px-6 pb-6">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col h-full">
                        <div className="overflow-auto flex-1">
                            <table className="w-full text-left border-collapse relative">
                                <thead className="bg-gray-50 dark:bg-slate-950 sticky top-0 z-10 border-b border-gray-200 dark:border-slate-800 shadow-sm">
                                    <tr>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Serial</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Supplier</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider hidden md:table-cell">Date</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-right hidden md:table-cell">Items</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                                    {filteredOrders.map(order => (
                                        <tr key={order.id} className="hover:bg-blue-50/30 dark:hover:bg-blue-900/10 cursor-pointer transition-colors" onClick={() => handleEdit(order)}>
                                            <td className="px-6 py-4 font-mono font-bold text-gray-700 dark:text-gray-300 text-sm">{order.receivingSerial}</td>
                                            <td className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-gray-400">{order.supplierName}</td>
                                            <td className="px-6 py-4 text-xs font-medium text-gray-600 dark:text-gray-400 hidden md:table-cell">{new Date(order.createTime).toLocaleDateString()}</td>
                                            <td className="px-6 py-4"><span className={`px-2 py-1 rounded text-[10px] font-black uppercase border ${getStatusColor(order.reviewStatus)}`}>{order.reviewStatus}</span></td>
                                            <td className="px-6 py-4 text-right text-xs font-bold text-gray-700 dark:text-gray-300 hidden md:table-cell">{order.items?.length || 0}</td>
                                            <td className="px-6 py-4 text-right">
                                                <button onClick={(e) => onDelete(order.id, e)} className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 text-gray-400 hover:text-red-500 rounded transition-colors"><Trash2 size={16} /></button>
                                            </td>
                                        </tr>
                                    ))}
                                    {filteredOrders.length === 0 && (
                                        <tr>
                                            <td colSpan={6} className="py-12 text-center text-gray-400 dark:text-gray-600">
                                                <FileText size={48} className="mx-auto mb-3 opacity-20" />
                                                <p className="text-sm font-medium">{t('No receiving orders found.', '未找到收货单。')}</p>
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 transition-colors">
            {isScannerOpen && <Scanner onScan={handleScanInput} onClose={() => setIsScannerOpen(false)} title={t("Scan Product", "扫描商品")} />}
            
            {/* Detail View Header */}
            <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between shrink-0 shadow-sm z-30 dark:bg-slate-900 dark:border-slate-800">
                <div className="flex items-center gap-4">
                    <button onClick={() => setView('LIST')} className="p-2 -ml-2 hover:bg-gray-100 rounded-xl text-gray-500 transition-colors group dark:hover:bg-slate-800">
                        <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
                    </button>
                    <div>
                        <div className="flex items-center gap-3">
                            <input 
                                className="text-xl font-black text-black bg-transparent border-b-2 border-transparent hover:border-gray-200 focus:border-black outline-none transition-colors w-auto min-w-[200px] placeholder:text-gray-300 dark:text-white dark:focus:border-blue-500" 
                                value={formData.receivingSerial} 
                                onChange={e => setFormData({...formData, receivingSerial: e.target.value.toUpperCase()})} 
                                placeholder="SERIAL NO." 
                                disabled={!canEdit}
                            />
                            <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border tracking-wide whitespace-nowrap ${getStatusColor(formData.reviewStatus || 'PENDING')}`}>
                                {formData.reviewStatus || 'PENDING'}
                            </span>
                        </div>
                        <input 
                            className="text-xs font-bold text-gray-500 mt-0.5 bg-transparent outline-none w-full placeholder:text-gray-300 dark:text-gray-400" 
                            value={formData.supplierName} 
                            onChange={e => setFormData({...formData, supplierName: e.target.value})} 
                            placeholder={t("Enter Supplier Name", "输入供应商名称")} 
                            disabled={!canEdit}
                        />
                    </div>
                </div>
                <div className="flex gap-3">
                    {canEdit && (
                        <>
                            <button onClick={saveOrder} className="px-5 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg transition-all flex items-center gap-2"><Save size={18} /> {t('Save', '保存')}</button>
                            {formData.reviewStatus === 'PENDING' && (
                                <button onClick={handleApprove} className="px-5 py-2.5 bg-green-600 text-white font-bold rounded-xl hover:bg-green-700 shadow-lg transition-all flex items-center gap-2"><CheckCircle2 size={18} /> {t('Approve', '批准')}</button>
                            )}
                            {formData.reviewStatus === 'APPROVED' && (
                                <button onClick={handleUndo} className="px-5 py-2.5 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 shadow-sm transition-all flex items-center gap-2 dark:bg-slate-800 dark:text-gray-300 dark:hover:bg-slate-700"><RotateCcw size={18} /> {t('Undo', '撤销')}</button>
                            )}
                        </>
                    )}
                </div>
            </div>

            {/* Detail Content */}
            <div className="flex-1 overflow-hidden flex flex-col relative">
                <div className={`p-4 flex flex-col md:flex-row justify-between items-center gap-4 bg-gray-50 dark:bg-slate-950/30 border-b border-gray-100 dark:border-slate-800 shrink-0 ${!canEdit ? 'pointer-events-none opacity-60' : ''}`}>
                    <div className="flex items-center gap-3 flex-1 w-full">
                        <div className="relative flex-1 max-w-lg">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                            <input 
                                ref={filterInputRef}
                                className="w-full pl-10 pr-10 py-3 md:py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-xl text-base md:text-sm font-medium text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-gray-400"
                                placeholder="Scan or Search items..."
                                value={itemTableFilter}
                                onChange={e => setItemTableFilter(e.target.value)}
                                onKeyDown={handleKeyDown}
                                onFocus={(e) => e.target.select()}
                                autoFocus
                            />
                            {itemTableFilter && (
                                <button onClick={() => setItemTableFilter('')} className="absolute right-10 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                                    <X size={14} />
                                </button>
                            )}
                            <button 
                                onClick={() => setIsScannerOpen(true)}
                                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 p-1"
                                title="Camera Scan"
                            >
                                <Scan size={18} />
                            </button>
                        </div>
                    </div>
                    
                    {canEdit && (
                        <div className="relative">
                            <button onClick={() => setShowProductPicker(!showProductPicker)} className="px-4 py-2 bg-black text-white rounded-lg text-xs font-bold hover:bg-gray-800 flex items-center gap-2 shadow-md transition-all active:scale-95 dark:bg-blue-600 dark:hover:bg-blue-700"><Plus size={16} strokeWidth={3} /> {t('Add Product', '添加商品')}</button>
                            {showProductPicker && (
                                <div className="absolute right-0 top-full mt-2 w-80 md:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-slate-800 z-50 overflow-hidden animate-in fade-in zoom-in-95 origin-top-right">
                                    <div className="p-4 border-b border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-950/50">
                                        <div className="relative">
                                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                                            <input 
                                                className="w-full pl-9 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm font-medium text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 placeholder:text-gray-400 dark:placeholder:text-gray-500 transition-all"
                                                placeholder={t("Search by Name, SKU...", "按名称, SKU搜索...")}
                                                value={pickerSearch}
                                                onChange={e => setPickerSearch(e.target.value)}
                                                autoFocus
                                            />
                                        </div>
                                    </div>
                                    <div className="max-h-[320px] overflow-y-auto p-1 scroll-smooth">
                                        {filteredProducts.map(p => (
                                            <button 
                                                key={p.id} 
                                                onClick={() => addItem(p)} 
                                                className="w-full text-left p-3 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-xl transition-colors group flex items-start gap-3 border border-transparent hover:border-blue-100 dark:hover:border-blue-900/30 mb-1"
                                            >
                                                <div className="w-10 h-10 rounded-lg bg-gray-100 dark:bg-slate-800 flex items-center justify-center shrink-0 border border-gray-200 dark:border-slate-700 overflow-hidden">
                                                        {p.imageUrl ? <img src={p.imageUrl} className="w-full h-full object-cover" alt="" /> : <Package size={18} className="text-gray-400" />}
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <div className="text-sm font-bold text-gray-900 dark:text-white truncate">{p.name}</div>
                                                    <div className="flex items-center gap-2 mt-0.5">
                                                        <span className="text-[10px] font-mono text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-slate-800 px-1.5 py-0.5 rounded border border-gray-200 dark:border-slate-700">{p.sku}</span>
                                                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${p.stock > 0 ? 'bg-green-50 text-green-700 border-green-100 dark:bg-green-900/20 dark:text-green-400 dark:border-green-900/30' : 'bg-red-50 text-red-700 border-red-100 dark:bg-red-900/20 dark:text-red-400 dark:border-red-900/30'}`}>
                                                            {p.stock} {p.unit}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="self-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <Plus size={18} className="text-blue-600 dark:text-blue-400" />
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <div className="flex-1 overflow-auto bg-gray-50 dark:bg-slate-950/30">
                    <table className="w-full text-left text-sm border-collapse min-w-[1000px]">
                        <thead className="bg-white text-gray-600 font-bold sticky top-0 z-10 border-b border-gray-200 shadow-sm text-xs uppercase tracking-wider dark:bg-slate-900 dark:text-gray-400 dark:border-slate-800">
                            <tr>
                                <th className="px-6 py-3 w-12 text-center">#</th>
                                <th className="px-6 py-3">{t('Product Name', '商品名称')}</th>
                                <th className="px-6 py-3 w-40">{t('Code', '代码')}</th>
                                <th className="px-6 py-3 w-48">{t('Location', '货位')}</th>
                                <th className="px-6 py-3 text-right w-32">{t('Order Qty', '订购数')}</th>
                                <th className="px-6 py-3 text-right w-32">{t('Recv Qty', '收货数')}</th>
                                <th className="px-6 py-3 text-center w-32">{t('Status', '状态')}</th>
                                <th className="px-6 py-3 w-16"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 bg-white dark:bg-slate-900 dark:divide-slate-800">
                            {filteredItems.map((item, idx) => {
                                const status = getItemStatus(item);
                                const isComplete = (item.receivedQty || 0) >= item.orderQty;
                                const isPartial = (item.receivedQty || 0) > 0 && (item.receivedQty || 0) < item.orderQty;
                                const rowClass = isComplete ? 'bg-green-50 dark:bg-green-900/10' : isPartial ? 'bg-amber-50 dark:bg-amber-900/10' : 'hover:bg-gray-50 dark:hover:bg-slate-800';
                                
                                return (
                                <tr key={item.id} className={`group transition-colors ${rowClass}`}>
                                    <td className="px-6 py-4 text-center text-gray-400 font-mono text-xs">{idx + 1}</td>
                                    <td className="px-6 py-4"><div className="font-bold text-gray-900 text-sm dark:text-white">{item.productName}</div><div className="text-[10px] text-gray-500 mt-0.5">{item.specification}</div></td>
                                    <td className="px-6 py-4"><span className="font-mono text-xs font-bold text-gray-600 dark:text-gray-400">{item.productCode}</span></td>
                                    <td className="px-6 py-4"><div className="flex items-center gap-2"><MapPin size={14} className="text-blue-500" /><span className="font-mono text-sm font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded border border-slate-200 dark:border-slate-700">{item.storageLocation}</span></div></td>
                                    <td className="px-6 py-4 text-right">
                                        <input 
                                            type="number" 
                                            className="w-20 text-center border-b border-gray-300 dark:border-slate-700 bg-transparent outline-none font-medium focus:border-blue-500 text-gray-900 dark:text-white"
                                            value={item.orderQty}
                                            onChange={e => updateItem(item.id, { orderQty: Number(e.target.value) })}
                                            disabled={!canEdit}
                                        />
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <input 
                                            type="number" 
                                            className="w-20 text-center border-b border-gray-300 dark:border-slate-700 bg-transparent outline-none font-bold focus:border-blue-500 text-gray-900 dark:text-white"
                                            value={item.receivedQty}
                                            onChange={e => updateItem(item.id, { receivedQty: Number(e.target.value) })}
                                            disabled={!canEdit}
                                        />
                                    </td>
                                    <td className="px-6 py-4 text-center"><span className={`px-2 py-1 rounded text-[10px] font-black uppercase border ${status.color}`}>{status.label}</span></td>
                                    <td className="px-6 py-4 text-center">
                                        {canEdit && (
                                            <button onClick={() => removeItem(item.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                                                <XCircle size={18} />
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            )})}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}


import React from 'react';
import { useInventory } from '../context/InventoryContext';
import { CheckCircle2, AlertOctagon, AlertCircle, Info, X } from 'lucide-react';

const ToastContainer: React.FC = () => {
    const { appNotifications, dismissAppNotification } = useInventory();
    
    return (
        <div className="fixed top-4 right-4 z-[100] flex flex-col gap-3 pointer-events-none">
            {(appNotifications || []).map(n => {
                let bgColor = 'bg-white dark:bg-slate-800';
                let borderColor = 'border-gray-100 dark:border-slate-700';
                let iconColor = 'text-blue-500';
                let Icon = Info;

                switch(n.type) {
                    case 'success':
                        borderColor = 'border-green-100 dark:border-green-900';
                        iconColor = 'text-green-500';
                        Icon = CheckCircle2;
                        break;
                    case 'error':
                        borderColor = 'border-red-100 dark:border-red-900';
                        iconColor = 'text-red-500';
                        Icon = AlertOctagon;
                        break;
                    case 'warning':
                        borderColor = 'border-amber-100 dark:border-amber-900';
                        iconColor = 'text-amber-500';
                        Icon = AlertCircle;
                        break;
                }

                return (
                    <div 
                        key={n.id} 
                        className={`pointer-events-auto w-80 p-4 rounded-xl shadow-lg border ${borderColor} ${bgColor} flex gap-3 animate-in slide-in-from-right-10 fade-in duration-300 transition-all`}
                    >
                        <div className={`mt-0.5 ${iconColor}`}>
                            <Icon size={20} />
                        </div>
                        <div className="flex-1 min-w-0">
                            <h4 className="text-sm font-bold text-gray-900 dark:text-white leading-tight mb-1">{n.title}</h4>
                            <p className="text-xs text-gray-500 dark:text-gray-400 leading-snug">{n.message}</p>
                        </div>
                        <button 
                            onClick={() => dismissAppNotification(n.id)}
                            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 self-start p-1"
                        >
                            <X size={14} />
                        </button>
                    </div>
                );
            })}
        </div>
    );
};

export default ToastContainer;

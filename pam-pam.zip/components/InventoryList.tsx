
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useInventory } from '../context/InventoryContext';
import { Product } from '../types';
import { 
    Search, Filter, Plus, Edit2, Trash2, Box, AlertCircle, 
    CheckCircle2, Clock, MoreVertical, FileText,
    ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight,
    UploadCloud, ChevronDown, Package, ArrowUp, ArrowDown, ArrowUpDown, FileDown
} from 'lucide-react';
import ProductDetailModal from './ProductDetailModal';
import ImportProductModal from './ImportProductModal';
import * as XLSX from 'xlsx';

interface InventoryListProps {
    enableExport?: boolean;
    enableImport?: boolean;
    showWholesalePrice?: boolean;
    allowEdit?: boolean;
}

const InventoryList: React.FC<InventoryListProps> = ({ 
    enableExport = true, 
    enableImport = true,
    showWholesalePrice = false,
    allowEdit = true
}) => {
    const { products, inventory, updateProduct, deleteProduct, transactions, currentUser, bulkUpsertProducts, addProduct, language, checkPermission } = useInventory();
    
    const t = (en: string, zh: string) => language === 'ZH' ? zh : en;

    const [searchTerm, setSearchTerm] = useState('');
    const [warehouseFilter, setWarehouseFilter] = useState('ALL');
    const [statusFilter, setStatusFilter] = useState('ALL');
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [isDetailOpen, setIsDetailOpen] = useState(false);
    const [isImportOpen, setIsImportOpen] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    
    // Permission Checks
    const canCreate = checkPermission('INVENTORY_PRODUCT', 'create');
    const canEdit = checkPermission('INVENTORY_PRODUCT', 'edit');
    const canDelete = checkPermission('INVENTORY_PRODUCT', 'delete');
    
    // Sorting State
    const [sortConfig, setSortConfig] = useState<{ key: keyof Product | 'stock'; direction: 'asc' | 'desc' }>({ key: 'updatedAt', direction: 'desc' });

    // Pagination State
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);

    // Performance Optimization: Pre-calculate inventory maps
    const inventoryMap = useMemo(() => {
        const map = new Map<string, { total: number, warehouses: Set<string>, byWh: Record<string, number> }>();
        
        inventory.forEach(item => {
            if (!map.has(item.productId)) {
                map.set(item.productId, { total: 0, warehouses: new Set(), byWh: {} });
            }
            const entry = map.get(item.productId)!;
            const qty = item.quantity || 0;
            
            entry.total += qty;
            if (item.warehouse) {
                entry.warehouses.add(item.warehouse);
                entry.byWh[item.warehouse] = (entry.byWh[item.warehouse] || 0) + qty;
            }
        });
        
        return map;
    }, [inventory]);

    // Calculate display stock based on warehouse filter using the Map (O(1) lookup)
    const getDisplayStock = useCallback((product: Product) => {
        const entry = inventoryMap.get(product.id);
        
        if (warehouseFilter === 'ALL') {
            // Use aggregated total if inventory records exist
            if (entry) return entry.total;
            // Fallback to legacy product.stock
            return product.stock || 0;
        }
        
        // Filter specific warehouse
        if (entry && entry.byWh[warehouseFilter] !== undefined) {
            return entry.byWh[warehouseFilter];
        }
            
        // Fallback if product default warehouse matches
        if (product.warehouse === warehouseFilter) return product.stock || 0;
        
        return 0;
    }, [inventoryMap, warehouseFilter]);

    // Filter Logic
    const filteredProducts = useMemo(() => {
        const term = searchTerm.toLowerCase();
        
        return products.filter(product => {
            // 1. Search Filter
            const matchesSearch = !term || 
                                  product.name.toLowerCase().includes(term) || 
                                  product.sku.toLowerCase().includes(term) ||
                                  (product.barcode && product.barcode.includes(term));
            
            if (!matchesSearch) return false;

            // 2. Warehouse Filter
            let matchesWarehouse = true;
            if (warehouseFilter !== 'ALL') {
                const entry = inventoryMap.get(product.id);
                const hasInWh = entry ? entry.warehouses.has(warehouseFilter) : false;
                const isDefault = product.warehouse === warehouseFilter;
                matchesWarehouse = hasInWh || isDefault;
            }
            
            if (!matchesWarehouse) return false;

            // 3. Status Filter (Calculated based on displayed stock)
            if (statusFilter === 'ALL') return true;

            const currentStock = getDisplayStock(product);
            
            if (statusFilter === 'LOW') return currentStock > 0 && currentStock < 20;
            if (statusFilter === 'OUT') return currentStock === 0;
            if (statusFilter === 'IN') return currentStock >= 20;

            return true;
        });
    }, [products, inventoryMap, searchTerm, warehouseFilter, statusFilter, getDisplayStock]);

    // Sorting Logic
    const sortedProducts = useMemo(() => {
        const sorted = [...filteredProducts];
        if (sortConfig.key) {
            sorted.sort((a, b) => {
                let aValue: any = a[sortConfig.key as keyof Product];
                let bValue: any = b[sortConfig.key as keyof Product];

                // Special handling for dynamic stock
                if (sortConfig.key === 'stock') {
                    aValue = getDisplayStock(a);
                    bValue = getDisplayStock(b);
                }

                if (aValue === undefined || aValue === null) return 1;
                if (bValue === undefined || bValue === null) return -1;

                if (typeof aValue === 'string') {
                    aValue = aValue.toLowerCase();
                    bValue = bValue.toLowerCase();
                }

                if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
                if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
                return 0;
            });
        }
        return sorted;
    }, [filteredProducts, sortConfig, getDisplayStock]);

    // Reset pagination on filter change
    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, warehouseFilter, statusFilter]);

    // Pagination Calculations
    const totalItems = sortedProducts.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = sortedProducts.slice(indexOfFirstItem, indexOfLastItem);

    const handlePageChange = (page: number) => {
        if (page >= 1 && page <= totalPages) setCurrentPage(page);
    };

    const handleSort = (key: keyof Product | 'stock') => {
        setSortConfig(current => ({
            key,
            direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc'
        }));
    };

    const handleEditProduct = (product: Product) => {
        if (!canEdit || !allowEdit) return;
        setSelectedProduct(product);
        setIsEditing(true);
        setIsDetailOpen(true);
    };

    const handleViewProduct = (product: Product) => {
        setSelectedProduct(product);
        setIsEditing(false);
        setIsDetailOpen(true);
    };

    const handleAddNew = () => {
        if (!canCreate) return;
        const newProduct: Product = {
            id: crypto.randomUUID(),
            barcode: '',
            sku: '',
            name: '',
            category: 'General',
            location: '',
            specification: '',
            unit: 'PCS',
            stock: 0,
            expiryDate: '',
            status: 'Out of Stock',
            standardPrice: 0,
            wholesalePrice: 0,
            wholesalePrice2: 0,
            purchasePrice: 0,
            origin: '',
            brand: '',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        setSelectedProduct(newProduct);
        setIsEditing(true);
        setIsDetailOpen(true);
    };

    const handleExport = () => {
        // Exporting ALL products (ignoring pagination and local filters), but respecting warehouse context for stock
        // We sort by updatedAt descending to give a consistent order
        const allProducts = [...products].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

        const dataToExport = allProducts.map(p => ({
            'Product Name': p.name,
            'SKU': p.sku,
            'Barcode': p.barcode,
            'Category': p.category,
            'Location': p.location || '', // Force empty string if null/undefined
            'Stock': getDisplayStock(p),
            'Unit': p.unit,
            'Warehouse': p.warehouse || '', // Force empty string if null/undefined
            'Price': p.standardPrice,
            'Last Updated': new Date(p.updatedAt).toLocaleDateString('en-GB')
        }));

        const ws = XLSX.utils.json_to_sheet(dataToExport);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Inventory_All");
        XLSX.writeFile(wb, `Inventory_Export_All_${new Date().toISOString().slice(0,10)}.xlsx`);
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950 transition-colors">
            {/* Fixed Header Section */}
            <div className="shrink-0 p-6 pb-2">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                    <div>
                        <h1 className="text-3xl font-black text-gray-900 dark:text-white flex items-center gap-3 tracking-tight">
                            <div className="p-3 bg-blue-600 rounded-2xl shadow-lg shadow-blue-500/20 text-white">
                                <Box size={24} />
                            </div>
                            {t('Product Inventory', '商品库存')}
                        </h1>
                        <p className="text-gray-500 dark:text-gray-400 mt-2 font-medium ml-1">
                            {t('Manage catalog, track stock levels, and audit inventory.', '管理目录，跟踪库存水平和审计库存。')}
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        {enableExport && (
                            <button 
                                onClick={handleExport}
                                className="px-5 py-2.5 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 rounded-xl text-sm font-bold hover:bg-gray-50 dark:hover:bg-slate-800 transition-all shadow-sm flex items-center gap-2 group"
                            >
                                <FileDown size={18} className="text-gray-400 group-hover:text-green-600 transition-colors"/>
                                {t('Export All', '导出全部')}
                            </button>
                        )}
                        {canCreate && (
                            <>
                                {enableImport && (
                                    <button 
                                        onClick={() => setIsImportOpen(true)}
                                        className="px-5 py-2.5 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 rounded-xl text-sm font-bold hover:bg-gray-50 dark:hover:bg-slate-800 transition-all shadow-sm flex items-center gap-2 group"
                                    >
                                        <UploadCloud size={18} className="text-gray-400 group-hover:text-blue-500 transition-colors"/>
                                        {t('Import Data', '导入数据')}
                                    </button>
                                )}
                                <button 
                                    onClick={handleAddNew}
                                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-200 dark:shadow-none transition-all flex items-center gap-2 active:scale-95"
                                >
                                    <Plus size={18} strokeWidth={3} />
                                    {t('Add Product', '添加商品')}
                                </button>
                            </>
                        )}
                    </div>
                </div>

                {/* Control Bar (Search & Filter) */}
                <div className="bg-white dark:bg-slate-900 p-1.5 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col md:flex-row gap-2 transition-colors">
                    <div className="relative flex-1">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                        <input 
                            className="w-full pl-12 pr-4 py-3 bg-transparent text-gray-900 dark:text-white placeholder:text-gray-400 outline-none text-sm font-medium"
                            placeholder={t("Search by product name, SKU, barcode...", "搜索商品名称, SKU, 条码...")}
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                    
                    <div className="flex items-center gap-2 p-1 overflow-x-auto no-scrollbar">
                        <div className="h-8 w-px bg-gray-200 dark:bg-slate-700 mx-2 hidden md:block"></div>
                        
                        {/* Warehouse Filter */}
                        <div className="relative group">
                            <select 
                                className="appearance-none bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl pl-4 pr-10 py-2.5 text-sm font-bold text-gray-700 dark:text-gray-200 outline-none focus:ring-2 focus:ring-blue-500 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors cursor-pointer min-w-[160px]"
                                value={warehouseFilter}
                                onChange={e => setWarehouseFilter(e.target.value)}
                            >
                                <option value="ALL">{t('All Warehouses', '所有仓库')}</option>
                                {Array.from(new Set(inventory.map(i => i.warehouse))).map(w => <option key={String(w)} value={String(w)}>{w}</option>)}
                            </select>
                            <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none group-hover:text-gray-600 dark:group-hover:text-gray-300" />
                        </div>

                        {/* Status Filter */}
                        <div className="relative group">
                            <select 
                                className="appearance-none bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl pl-4 pr-10 py-2.5 text-sm font-bold text-gray-700 dark:text-gray-200 outline-none focus:ring-2 focus:ring-blue-500 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors cursor-pointer min-w-[140px]"
                                value={statusFilter}
                                onChange={e => setStatusFilter(e.target.value)}
                            >
                                <option value="ALL">{t('All Status', '所有状态')}</option>
                                <option value="IN">{t('In Stock', '有库存')}</option>
                                <option value="LOW">{t('Low Stock', '低库存')}</option>
                                <option value="OUT">{t('Out of Stock', '缺货')}</option>
                            </select>
                            <Filter size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none group-hover:text-gray-600 dark:group-hover:text-gray-300" />
                        </div>
                    </div>
                </div>
            </div>

            {/* List Section - Flex column to take remaining space */}
            <div className="flex-1 overflow-hidden px-6 pb-6">
                <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-gray-200 dark:border-slate-800 flex flex-col h-full">
                    {/* Scrollable Table Area */}
                    <div className="overflow-auto flex-1">
                        <table className="w-full text-left text-sm relative">
                            <thead className="bg-gray-50 dark:bg-slate-950 text-gray-500 dark:text-gray-400 font-bold uppercase text-[11px] tracking-wider sticky top-0 z-10 shadow-sm border-b border-gray-200 dark:border-slate-800">
                                <tr>
                                    <th 
                                        className="px-6 py-4 cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors select-none group"
                                        onClick={() => handleSort('name')}
                                    >
                                        <div className="flex items-center gap-1">
                                            {t('Product Info', '商品信息')}
                                            <span className="text-gray-400">
                                                {sortConfig.key === 'name' ? (sortConfig.direction === 'asc' ? <ArrowUp size={12}/> : <ArrowDown size={12}/>) : <ArrowUpDown size={12} className="opacity-0 group-hover:opacity-100"/>}
                                            </span>
                                        </div>
                                    </th>
                                    <th 
                                        className="px-6 py-4 cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors select-none group"
                                        onClick={() => handleSort('category')}
                                    >
                                        <div className="flex items-center gap-1">
                                            {t('Category', '分类')}
                                            <span className="text-gray-400">
                                                {sortConfig.key === 'category' ? (sortConfig.direction === 'asc' ? <ArrowUp size={12}/> : <ArrowDown size={12}/>) : <ArrowUpDown size={12} className="opacity-0 group-hover:opacity-100"/>}
                                            </span>
                                        </div>
                                    </th>
                                    <th 
                                        className="px-6 py-4 cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors select-none group"
                                        onClick={() => handleSort('location')}
                                    >
                                        <div className="flex items-center gap-1">
                                            {t('Location', '库位')}
                                            <span className="text-gray-400">
                                                {sortConfig.key === 'location' ? (sortConfig.direction === 'asc' ? <ArrowUp size={12}/> : <ArrowDown size={12}/>) : <ArrowUpDown size={12} className="opacity-0 group-hover:opacity-100"/>}
                                            </span>
                                        </div>
                                    </th>
                                    <th 
                                        className="px-6 py-4 text-right cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors select-none group"
                                        onClick={() => handleSort('stock')}
                                    >
                                        <div className="flex items-center justify-end gap-1">
                                            {t('Stock', '库存')}
                                            <span className="text-gray-400">
                                                {sortConfig.key === 'stock' ? (sortConfig.direction === 'asc' ? <ArrowUp size={12}/> : <ArrowDown size={12}/>) : <ArrowUpDown size={12} className="opacity-0 group-hover:opacity-100"/>}
                                            </span>
                                        </div>
                                    </th>
                                    <th 
                                        className="px-6 py-4 text-center cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors select-none group"
                                        onClick={() => handleSort('status')}
                                    >
                                        <div className="flex items-center justify-center gap-1">
                                            {t('Status', '状态')}
                                            <span className="text-gray-400">
                                                {sortConfig.key === 'status' ? (sortConfig.direction === 'asc' ? <ArrowUp size={12}/> : <ArrowDown size={12}/>) : <ArrowUpDown size={12} className="opacity-0 group-hover:opacity-100"/>}
                                            </span>
                                        </div>
                                    </th>
                                    <th className="px-6 py-4 text-right bg-gray-50 dark:bg-slate-950">{t('Actions', '操作')}</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                                {currentItems.map(product => {
                                    const stock = getDisplayStock(product);
                                    return (
                                        <tr key={product.id} className="hover:bg-blue-50/30 dark:hover:bg-blue-900/10 transition-colors group cursor-pointer" onClick={() => handleViewProduct(product)}>
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-4">
                                                    <div className="w-12 h-12 rounded-xl bg-gray-100 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 flex items-center justify-center shrink-0 overflow-hidden shadow-sm">
                                                        {product.imageUrl ? (
                                                            <img src={product.imageUrl} className="w-full h-full object-cover"/> 
                                                        ) : (
                                                            <Package size={20} className="text-gray-400 dark:text-gray-600"/>
                                                        )}
                                                    </div>
                                                    <div>
                                                        <div className="font-bold text-gray-900 dark:text-white text-sm mb-0.5">{product.name}</div>
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-[10px] font-mono text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-slate-800 px-1.5 py-0.5 rounded border border-gray-100 dark:border-slate-700">
                                                                {product.sku}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{product.category}</span>
                                            </td>
                                            <td className="px-6 py-4">
                                                {product.location ? (
                                                    <span className="bg-white dark:bg-slate-800 px-2.5 py-1 rounded-lg text-xs font-bold text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-slate-700 shadow-sm font-mono">
                                                        {product.location}
                                                    </span>
                                                ) : (
                                                    <span className="text-xs text-gray-400 italic">Unassigned</span>
                                                )}
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex flex-col items-end">
                                                    <span className="font-black text-gray-900 dark:text-white text-base">{stock}</span>
                                                    <span className="text-[10px] font-bold text-gray-400 uppercase">{product.unit}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wide border ${
                                                    stock === 0 ? 'bg-red-50 text-red-600 border-red-100 dark:bg-red-900/20 dark:border-red-900/30 dark:text-red-400' :
                                                    stock < 20 ? 'bg-amber-50 text-amber-600 border-amber-100 dark:bg-amber-900/20 dark:border-amber-900/30 dark:text-amber-400' :
                                                    'bg-emerald-50 text-emerald-600 border-emerald-100 dark:bg-emerald-900/20 dark:border-emerald-900/30 dark:text-emerald-400'
                                                }`}>
                                                    <span className={`w-1.5 h-1.5 rounded-full ${
                                                        stock === 0 ? 'bg-red-500' : stock < 20 ? 'bg-amber-500' : 'bg-emerald-500'
                                                    }`}></span>
                                                    {stock === 0 ? t('Out', '缺货') : stock < 20 ? t('Low', '低') : t('OK', '正常')}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                    {canEdit && allowEdit && (
                                                        <button 
                                                            onClick={(e) => { e.stopPropagation(); handleEditProduct(product); }}
                                                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors border border-transparent hover:border-blue-100 dark:hover:border-blue-900/50"
                                                            title="Edit"
                                                        >
                                                            <Edit2 size={16} />
                                                        </button>
                                                    )}
                                                    {canDelete && (
                                                        <button 
                                                            onClick={(e) => { e.stopPropagation(); if(confirm('Delete product?')) deleteProduct(product.id); }}
                                                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors border border-transparent hover:border-red-100 dark:hover:border-red-900/50"
                                                            title="Delete"
                                                        >
                                                            <Trash2 size={16} />
                                                        </button>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })}
                                {currentItems.length === 0 && (
                                    <tr>
                                        <td colSpan={6} className="py-24 text-center">
                                            <div className="flex flex-col items-center justify-center">
                                                <div className="w-16 h-16 bg-gray-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4 text-gray-400 dark:text-gray-500">
                                                    <FileText size={32} />
                                                </div>
                                                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">{t('No products found', '未找到商品')}</h3>
                                                <p className="text-sm text-gray-500 dark:text-gray-400 max-w-xs mx-auto">
                                                    {t("We couldn't find any products matching your search filters.", "我们找不到符合您搜索条件的任何商品。")}
                                                </p>
                                                <button 
                                                    onClick={() => { setSearchTerm(''); setStatusFilter('ALL'); setWarehouseFilter('ALL'); }}
                                                    className="mt-6 px-4 py-2 bg-gray-900 dark:bg-white text-white dark:text-slate-900 text-sm font-bold rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors"
                                                >
                                                    {t('Clear Filters', '清除过滤')}
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Pagination Footer - Fixed at bottom of card */}
                    <div className="p-4 border-t border-gray-200 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 bg-gray-50/50 dark:bg-slate-950/50 transition-colors shrink-0">
                         <div className="flex items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
                             <span className="text-xs font-bold uppercase tracking-wider">{t('Rows per page', '每页行数')}</span>
                             <select 
                                 className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-2 py-1 outline-none text-xs font-bold cursor-pointer transition-colors text-gray-700 dark:text-gray-300 focus:ring-2 focus:ring-blue-500"
                                 value={itemsPerPage}
                                 onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                             >
                                 <option value={10}>10</option>
                                 <option value={20}>20</option>
                                 <option value={50}>50</option>
                                 <option value={100}>100</option>
                             </select>
                             <div className="h-4 w-px bg-gray-300 dark:bg-slate-700 mx-2"></div>
                             <span className="text-xs font-medium">
                                 {t('Showing', '显示')} {totalItems === 0 ? 0 : indexOfFirstItem + 1}-{Math.min(indexOfLastItem, totalItems)} {t('of', '/')} {totalItems}
                             </span>
                         </div>
                         
                         <div className="flex items-center gap-2">
                             <button 
                                onClick={() => handlePageChange(1)} 
                                disabled={currentPage === 1} 
                                className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-gray-600 dark:text-gray-400"
                                title="First Page"
                            >
                                <ChevronsLeft size={16} />
                            </button>
                             <button 
                                onClick={() => handlePageChange(currentPage - 1)} 
                                disabled={currentPage === 1} 
                                className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-gray-600 dark:text-gray-400"
                                title="Previous Page"
                            >
                                <ChevronLeft size={16} />
                            </button>
                             
                             <span className="px-4 text-xs font-bold text-gray-700 dark:text-gray-300">
                                 {t('Page', '页')} {currentPage} {t('of', '/')} {totalPages || 1}
                             </span>

                             <button 
                                onClick={() => handlePageChange(currentPage + 1)} 
                                disabled={currentPage === totalPages || totalPages === 0} 
                                className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-gray-600 dark:text-gray-400"
                                title="Next Page"
                            >
                                <ChevronRight size={16} />
                            </button>
                             <button 
                                onClick={() => handlePageChange(totalPages)} 
                                disabled={currentPage === totalPages || totalPages === 0} 
                                className="p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-gray-600 dark:text-gray-400"
                                title="Last Page"
                            >
                                <ChevronsRight size={16} />
                            </button>
                         </div>
                     </div>
                </div>
            </div>

            <ProductDetailModal 
                isOpen={isDetailOpen}
                onClose={() => setIsDetailOpen(false)}
                product={selectedProduct}
                initialIsEditing={isEditing}
                onUpdate={(updated, reason) => {
                    if (!selectedProduct?.id || selectedProduct.id.length < 10) { 
                        addProduct(updated);
                    } else {
                        updateProduct(updated, reason);
                    }
                    setIsDetailOpen(false);
                }}
                transactions={transactions}
                currentUser={currentUser}
                allowStockEditing={canEdit} 
                showWholesalePrice={showWholesalePrice}
                allowEdit={allowEdit && canEdit}
            />

            <ImportProductModal 
                isOpen={isImportOpen}
                onClose={() => setIsImportOpen(false)}
                onImport={async (importedProducts, mode) => {
                    await bulkUpsertProducts(importedProducts); 
                    setIsImportOpen(false);
                }}
            />
        </div>
    );
};

export default InventoryList;

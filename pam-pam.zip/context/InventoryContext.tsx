
import React, { createContext, useContext, useState, ReactNode, useEffect, useCallback, useRef, useMemo } from 'react';
import { Product, Transaction, DashboardStats, UserProfile, UserRole, AdjustmentBill, AdjustmentItem, AdjustmentStatus, Task, Warehouse, RoleConfig, PermissionObject, Theme, NotificationSettings, ShelfLog, ReceivingOrder, DistributionOrder, PurchaseOrder, Driver, DistributionOutlet, AppNotification, InventoryItem, DistributionOrderItem, DiscrepancyReport, ShelfLane } from '../types';
import { PERMISSION_MODULES, USER_ROLES } from '../constants';
import { supabase } from '../supabaseClient';

interface InventoryContextType {
  products: Product[];
  transactions: Transaction[];
  shelfLogs: ShelfLog[];
  stats: DashboardStats;
  currentUser: UserProfile | null;
  users: UserProfile[];
  adjustmentBills: AdjustmentBill[];
  tasks: Task[];
  warehouses: Warehouse[];
  shelfLanes: ShelfLane[];
  roleConfigs: Record<string, RoleConfig>;
  theme: Theme;
  receivingOrders: ReceivingOrder[];
  distributionOrders: DistributionOrder[];
  purchaseOrders: PurchaseOrder[];
  drivers: Driver[];
  outlets: DistributionOutlet[];
  appNotifications: AppNotification[];
  inventory: InventoryItem[];
  discrepancyReports: DiscrepancyReport[];
  language: 'EN' | 'ZH';
  lastSynced: Date;
  
  // Product Actions
  moveProduct: (barcode: string, newLocation: string, method?: ShelfLog['method']) => { success: boolean; message: string };
  searchProduct: (query: string) => Product | undefined;
  addProduct: (product: Product) => void;
  updateProduct: (product: Product, adjustmentReason?: string) => void;
  adjustProductStock: (productId: string, newStock: number, reason: string) => void;
  deleteProduct: (id: string) => void;
  bulkUpsertProducts: (products: Partial<Product>[]) => Promise<void>;
  bulkUpdateProducts: (ids: string[], updates: Partial<Product>) => void;
  createAdjustmentBill: (items: AdjustmentItem[], note?: string, status?: AdjustmentStatus) => void;
  approveAdjustmentBill: (id: string) => void;
  rejectAdjustmentBill: (id: string) => void;
  getLatestShelfLog: (productId: string) => ShelfLog | undefined;
  
  // Receiving Order Actions
  addReceivingOrder: (order: Omit<ReceivingOrder, 'id' | 'createTime' | 'modificationTime' | 'reviewStatus'>) => void;
  approveReceivingOrder: (id: string) => void;
  bulkImportReceivingOrders: (orders: ReceivingOrder[]) => void;
  rejectReceivingOrder: (id: string) => void;
  undoReceivingOrder: (id: string) => void;
  deleteReceivingOrder: (id: string) => void;
  updateReceivingOrder: (order: ReceivingOrder) => void;

  // Distribution Order Actions
  addDistributionOrder: (order: DistributionOrder) => Promise<DistributionOrder>;
  bulkAddDistributionOrders: (orders: DistributionOrder[]) => Promise<void>;
  updateDistributionOrder: (order: DistributionOrder) => Promise<void>;
  deleteDistributionOrder: (id: string) => void;
  approveDistributionOrder: (id: string) => void;
  startPicking: (orderId: string) => Promise<{ success: boolean; message: string }>;
  completePicking: (orderId: string, status: 'Pick Complete' | 'Discrepancy', items: DistributionOrderItem[]) => Promise<{ success: boolean; message?: string }>;

  // Discrepancy Reports
  addDiscrepancyReport: (report: DiscrepancyReport) => Promise<void>;
  updateDiscrepancyReport: (report: DiscrepancyReport) => Promise<void>;

  // Purchase Order Actions
  addPurchaseOrder: (order: PurchaseOrder) => void;
  updatePurchaseOrder: (order: PurchaseOrder) => void;
  deletePurchaseOrder: (id: string) => void;

  // Driver/Outlet Actions
  addOutlet: (outlet: Omit<DistributionOutlet, 'id'>) => void;
  bulkAddOutlets: (outlets: Omit<DistributionOutlet, 'id'>[]) => Promise<void>;
  updateOutlet: (outlet: DistributionOutlet) => void;
  deleteOutlet: (id: string) => void;
  updateDriver: (id: string, data: Partial<Driver>) => void;
  assignDriverToOrders: (orderIds: string[], driverId: string, note?: string) => Promise<void>;
  unassignDriverFromOrder: (orderId: string) => Promise<void>;

  // Task Actions
  addTask: (title: string, dueDate?: string, priority?: 'HIGH' | 'MEDIUM' | 'LOW', relatedOrderId?: string) => void;
  toggleTaskCompletion: (id: string) => void;
  deleteTask: (id: string) => void;
  
  // Warehouse Actions
  addWarehouse: (wh: Omit<Warehouse, 'id'>) => void;
  updateWarehouse: (id: string, updates: Partial<Warehouse>) => void;
  deleteWarehouse: (id: string) => void;
  
  // Shelf Lane Actions
  addShelfLane: (lane: ShelfLane) => Promise<void>;
  updateShelfLane: (lane: ShelfLane) => Promise<void>;
  deleteShelfLane: (id: string) => Promise<void>;

  // User/Auth Actions
  login: (username: string, password: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  addUser: (user: UserProfile) => void;
  updateUser: (user: UserProfile) => void;
  deleteUser: (id: string) => void;
  resetPassword: (id: string) => void;
  changePassword: (newPassword: string) => void;
  setGlobalTheme: (theme: Theme) => void;
  setGlobalLanguage: (lang: 'EN' | 'ZH') => void;
  updateNotificationSettings: (settings: NotificationSettings) => void;
  
  // Permission Actions
  updateRoleConfig: (role: string, config: RoleConfig) => void;
  addRole: (roleName: string, description: string) => void;
  checkPermission: (scope: string, action: 'create' | 'read' | 'edit' | 'delete' | 'approve' | 'reject' | 'undo' | 'special', specialActionKey?: string) => boolean;

  // Notifications
  addNotification: (type: AppNotification['type'], title: string, message: string) => void;
  dismissAppNotification: (id: string) => void;
  refreshData: () => Promise<void>;
  bulkImportInventory: (items: any[], mode: 'MERGE' | 'REPLACE') => Promise<void>;
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

// Helper to validate UUID format
const isValidUUID = (id: string) => {
    const regex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return regex.test(id);
};

// Helper to ensure an ID is a valid UUID
const ensureUUID = (id?: string) => {
    if (id && isValidUUID(id)) return id;
    return crypto.randomUUID();
};

const isOfflineError = (error: any) => {
    if (!error) return false;
    const msg = error.message || '';
    const details = error.details || '';
    return msg.includes("Failed to fetch") || details.includes("Failed to fetch") || msg.includes("is not a valid URL");
};

const getRoleMetadata = (role: string) => {
    switch(role) {
        case 'ADMIN': return { description: 'Full system access and configuration.', color: 'bg-purple-600' };
        case 'MANAGER': return { description: 'Operational oversight and reporting.', color: 'bg-blue-600' };
        case 'INSPECTOR': return { description: 'Inventory verification and quality control.', color: 'bg-orange-500' };
        case 'TRADER': return { description: 'Sales and market data access.', color: 'bg-emerald-600' };
        case 'USER': return { description: 'Standard access to assigned tasks.', color: 'bg-gray-600' };
        case 'DRIVER': return { description: 'Access to assigned deliveries and routing.', color: 'bg-teal-600' };
        case 'BRANCH': return { description: 'Branch specific inventory and orders.', color: 'bg-indigo-600' };
        default: return { description: 'Custom user role.', color: 'bg-indigo-500' };
    }
};

const generateDefaultConfig = (role: string): RoleConfig => {
    const isAdmin = role === 'ADMIN';
    const objects: Record<string, PermissionObject> = {};
    PERMISSION_MODULES.forEach(mod => {
        objects[mod.key] = {
            create: isAdmin,
            read: isAdmin || role !== 'USER' || mod.key === 'MOBILE_USER' || mod.key === 'MOBILE_BRANCH' || mod.key === 'MOBILE_DRIVER', 
            edit: isAdmin,
            delete: isAdmin,
            approve: isAdmin,
            reject: isAdmin,
            undo: isAdmin,
            sharing: isAdmin ? 'Everyone' : 'Own Only'
        };
        if (role === 'USER') {
             if (mod.key === 'DASHBOARD' || mod.key === 'TASK_MANAGER' || mod.key === 'MOBILE_USER') objects[mod.key].read = true;
             else objects[mod.key].read = false;
        }
        if (role === 'DRIVER') {
             if (mod.key === 'MOBILE_DRIVER') objects[mod.key].read = true;
        }
        if (role === 'BRANCH') {
             if (mod.key === 'MOBILE_BRANCH') objects[mod.key].read = true;
        }
        if (role === 'INSPECTOR' || role === 'MANAGER') {
             objects[mod.key].read = true;
        }
    });
    
    const actions: Record<string, boolean> = {
        'view_cost_price': isAdmin || role === 'MANAGER',
        'approve_adjustments': isAdmin || role === 'MANAGER',
        'export_data': isAdmin || role === 'MANAGER' || role === 'TRADER',
        'manage_users': isAdmin,
        'manage_settings': isAdmin
    };

    const metadata = getRoleMetadata(role);

    return { objects, actions, metadata };
};

export const InventoryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [shelfLogs, setShelfLogs] = useState<ShelfLog[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [adjustmentBills, setAdjustmentBills] = useState<AdjustmentBill[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [receivingOrders, setReceivingOrders] = useState<ReceivingOrder[]>([]);
  const [distributionOrders, setDistributionOrders] = useState<DistributionOrder[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [rawDriverDetails, setRawDriverDetails] = useState<Driver[]>([]);
  const [outlets, setOutlets] = useState<DistributionOutlet[]>([]);
  const [discrepancyReports, setDiscrepancyReports] = useState<DiscrepancyReport[]>([]);
  const [shelfLanes, setShelfLanes] = useState<ShelfLane[]>([]);
  const [appNotifications, setAppNotifications] = useState<AppNotification[]>([]);
  const [lastSynced, setLastSynced] = useState<Date>(new Date());
  
  const [roleConfigs, setRoleConfigs] = useState<Record<string, RoleConfig>>(() => {
      const defaults: Record<string, RoleConfig> = {};
      USER_ROLES.forEach(role => defaults[role] = generateDefaultConfig(role));
      return defaults;
  });
  
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('pampam_theme') as Theme) || 'light');
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [language, setLanguage] = useState<'EN'|'ZH'>('EN');

  const drivers = useMemo(() => {
      const driverUsers = users.filter(u => u.role === 'DRIVER');
      return driverUsers.map(u => {
          const details = rawDriverDetails.find(d => d.id === u.id);
          return {
              id: u.id,
              name: u.name,
              phone: u.phone || details?.phone || '',
              plateNumber: u.plateNumber || details?.plateNumber || '',
              vehicleType: details?.vehicleType || 'Van',
              deliveryMethods: details?.deliveryMethods || ['Standard'],
              type: details?.type || 'Fulltime',
              maxPacks: details?.maxPacks,
              currentPacks: details?.currentPacks || distributionOrders.filter(o => o.assignedDriverId === u.id && o.status !== 'Delivered').length,
              avatar: u.avatar || details?.avatar
          } as Driver;
      });
  }, [users, rawDriverDetails, distributionOrders]);

  const fetchDistributionOrders = async () => {
      const { data, error } = await supabase.from('distribution_orders').select('*');
      if (!error && data) {
          setDistributionOrders(data);
      }
  };

  const refreshData = async () => {
      const [p, t, s, w, tk, ab, u, rc, dist, po, drv, out, ro, dr, inv, sl] = await Promise.all([
        supabase.from('products').select('*'),
        supabase.from('transactions').select('*').order('timestamp', { ascending: false }),
        supabase.from('shelf_logs').select('*').order('timestamp', { ascending: false }),
        supabase.from('warehouses').select('*'),
        supabase.from('tasks').select('*').order('createdAt', { ascending: false }),
        supabase.from('adjustment_bills').select('*').order('createdAt', { ascending: false }),
        supabase.from('user_profiles').select('*'),
        supabase.from('role_configs').select('*'),
        supabase.from('distribution_orders').select('*'),
        supabase.from('purchase_orders').select('*'),
        supabase.from('drivers').select('*'),
        supabase.from('outlets').select('*'),
        supabase.from('receiving_orders').select('*').order('createTime', { ascending: false }),
        supabase.from('discrepancy_reports').select('*').order('createdAt', { ascending: false }),
        supabase.from('inventory').select('*'),
        supabase.from('shelf_lanes').select('*').order('sortOrder', { ascending: true })
      ]);

      if (p.data) setProducts(p.data);
      if (t.data) setTransactions(t.data);
      if (s.data) setShelfLogs(s.data);
      if (w.data) setWarehouses(w.data);
      if (tk.data) setTasks(tk.data);
      if (ab.data) setAdjustmentBills(ab.data);
      if (u.data) setUsers(u.data);
      if (dist.data) setDistributionOrders(dist.data);
      if (po.data) setPurchaseOrders(po.data);
      if (drv.data) setRawDriverDetails(drv.data);
      if (out.data) setOutlets(out.data);
      if (ro.data) setReceivingOrders(ro.data);
      if (dr.data) setDiscrepancyReports(dr.data);
      if (inv.data) setInventory(inv.data);
      if (sl.data) setShelfLanes(sl.data);

      if (rc.data && rc.data.length > 0) {
          const newConfigs: Record<string, RoleConfig> = {};
          USER_ROLES.forEach(role => newConfigs[role] = generateDefaultConfig(role));

          rc.data.forEach((row: any) => {
              const savedConfig = row.config as RoleConfig;
              const mergedObjects = { ...newConfigs[row.role]?.objects, ...savedConfig.objects };
              const defaultMeta = getRoleMetadata(row.role);
              
              if (newConfigs[row.role]) {
                  Object.keys(newConfigs[row.role].objects).forEach(key => {
                      if (!mergedObjects[key]) mergedObjects[key] = newConfigs[row.role].objects[key];
                  });
              }
              newConfigs[row.role] = { ...savedConfig, objects: mergedObjects, metadata: { ...defaultMeta, ...savedConfig.metadata } };
          });
          setRoleConfigs(newConfigs);
      }
      setLastSynced(new Date());
  };

  useEffect(() => {
    refreshData().catch(e => console.warn("Initial fetch failed - Offline Mode", e));
    
    const handleVisibilityChange = () => {
        if (document.visibilityState === 'visible') {
            refreshData().catch(e => console.warn("Refresh failed", e));
        }
    };
    
    document.addEventListener("visibilitychange", handleVisibilityChange);

    const orderInterval = setInterval(() => {
        fetchDistributionOrders().catch(console.error);
    }, 10000);

    const fullInterval = setInterval(() => {
        refreshData().catch(console.error);
    }, 60000);

    const storedUser = localStorage.getItem('pampam_user');
    if (storedUser) {
        try {
            const parsed = JSON.parse(storedUser);
            setCurrentUser(parsed);
        } catch (e) {
            console.error("Failed to parse stored user", e);
            localStorage.removeItem('pampam_user');
        }
    }

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) fetchUserProfile(session.user.id);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
          fetchUserProfile(session.user.id);
      } else if (!localStorage.getItem('pampam_user')) {
          setCurrentUser(null);
      }
    });

    // --- REALTIME SUBSCRIPTIONS ---
    const handleRealtime = (payload: any, setState: React.Dispatch<React.SetStateAction<any[]>>) => {
        if (payload.eventType === 'INSERT') {
            setState(prev => {
                if (prev.some(i => i.id === payload.new.id)) return prev;
                return [payload.new, ...prev];
            });
        } else if (payload.eventType === 'UPDATE') {
            setState(prev => prev.map(item => item.id === payload.new.id ? payload.new : item));
        } else if (payload.eventType === 'DELETE') {
            setState(prev => prev.filter(item => item.id !== payload.old.id));
        }
    };

    const realtimeChannel = supabase.channel('main-channel')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, (payload) => handleRealtime(payload, setProducts))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'distribution_orders' }, (payload) => handleRealtime(payload, setDistributionOrders))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'receiving_orders' }, (payload) => handleRealtime(payload, setReceivingOrders))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, (payload) => handleRealtime(payload, setTasks))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'adjustment_bills' }, (payload) => handleRealtime(payload, setAdjustmentBills))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'transactions' }, (payload) => handleRealtime(payload, setTransactions))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'shelf_logs' }, (payload) => handleRealtime(payload, setShelfLogs))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'drivers' }, (payload) => handleRealtime(payload, setRawDriverDetails))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'outlets' }, (payload) => handleRealtime(payload, setOutlets))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'discrepancy_reports' }, (payload) => handleRealtime(payload, setDiscrepancyReports))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'inventory' }, (payload) => handleRealtime(payload, setInventory))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'shelf_lanes' }, (payload) => handleRealtime(payload, setShelfLanes))
        .subscribe();

    return () => { 
        document.removeEventListener("visibilitychange", handleVisibilityChange);
        clearInterval(orderInterval);
        clearInterval(fullInterval);
        subscription.unsubscribe(); 
        supabase.removeChannel(realtimeChannel);
    };
  }, []);

  const fetchUserProfile = async (userId: string) => {
    const { data } = await supabase.from('user_profiles').select('*').eq('id', userId).single();
    if (data) setCurrentUser(data);
  };

  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
    localStorage.setItem('pampam_theme', theme);
  }, [theme]);

  const setGlobalTheme = (newTheme: Theme) => setTheme(newTheme);
  const setGlobalLanguage = (lang: 'EN'|'ZH') => setLanguage(lang);
  const getTimestamp = () => new Date().toISOString();
  const getUpdaterName = () => currentUser?.name || 'System';

  const addNotification = (type: AppNotification['type'], title: string, message: string) => {
      const id = crypto.randomUUID();
      setAppNotifications(prev => [...prev, { id, type, title, message, timestamp: getTimestamp() }]);
      setTimeout(() => dismissAppNotification(id), 5000);
  };
  const dismissAppNotification = (id: string) => setAppNotifications(prev => prev.filter(n => n.id !== id));

  const login = async (identifier: string, p: string): Promise<{ success: boolean; message?: string }> => {
    // 1. Admin Backdoor
    if ((identifier.toLowerCase() === 'admin' || identifier.toLowerCase() === 'admin@pampam.com') && p === '11111') {
        const mockAdmin: UserProfile = { id: 'admin-dev-override', name: 'System Admin', username: 'admin', email: 'admin@pampam.com', role: 'ADMIN', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Admin', status: 'Active', permissions: ['ALL'], landingPage: 'DASHBOARD' };
        setCurrentUser(mockAdmin);
        localStorage.setItem('pampam_user', JSON.stringify(mockAdmin));
        setUsers(prev => { if (!prev.find(u => u.username === 'admin')) return [...prev, mockAdmin]; return prev; });
        return { success: true };
    }

    try {
        // 2. Lookup Profile
        let foundProfile: UserProfile | null = null;
        
        if (identifier.includes('@')) {
            const { data } = await supabase.from('user_profiles').select('*').eq('email', identifier);
            if (data && data.length > 0) foundProfile = data[0];
        } else {
            const { data } = await supabase.from('user_profiles').select('*').eq('username', identifier);
            if (data && data.length > 0) foundProfile = data[0];
        }

        if (!foundProfile) {
            return { 
                success: false, 
                message: identifier.includes('@') ? 'Email not found' : 'Username not found' 
            };
        }

        // 3. Check Virtual Password
        if (foundProfile.password === p) {
            if (foundProfile.status !== 'Active') return { success: false, message: 'Account inactive' };
            setCurrentUser(foundProfile);
            localStorage.setItem('pampam_user', JSON.stringify(foundProfile));
            return { success: true };
        }

        // 4. Check Supabase Auth
        if (foundProfile.email) {
            const { data, error } = await supabase.auth.signInWithPassword({ email: foundProfile.email, password: p });
            if (!error && data.user) {
                await fetchUserProfile(data.user.id);
                return { success: true };
            }
        }

        // If we are here, profile exists but password failed both virtual and auth checks
        return { success: false, message: 'Wrong password' };

    } catch (err) {
        console.error("Login process error:", err);
        return { success: false, message: 'System error occurred' };
    }
  };

  const logout = async () => { 
      await supabase.auth.signOut(); 
      localStorage.removeItem('pampam_user');
      setCurrentUser(null); 
  };

  const addUser = async (newUser: UserProfile) => {
    const userToInsert = { ...newUser, id: ensureUUID(newUser.id), status: newUser.status || 'Active', permissions: newUser.permissions || [] };
    setUsers(prev => [...prev, userToInsert as UserProfile]);
    await supabase.from('user_profiles').insert(userToInsert);
  };
  const updateUser = async (updatedUser: UserProfile) => {
    setUsers(prev => prev.map(u => u.id === updatedUser.id ? { ...u, ...updatedUser } : u));
    if (currentUser?.id === updatedUser.id) {
        const updated = { ...currentUser, ...updatedUser };
        setCurrentUser(updated);
        if (localStorage.getItem('pampam_user')) {
            localStorage.setItem('pampam_user', JSON.stringify(updated));
        }
    }
    await supabase.from('user_profiles').update(updatedUser).eq('id', updatedUser.id);
  };
  const deleteUser = async (id: string) => {
      setUsers(prev => prev.filter(u => u.id !== id));
      await supabase.from('user_profiles').delete().eq('id', id);
  };
  const resetPassword = async (id: string) => {
      const user = users.find(u => u.id === id);
      if (user && user.email) await supabase.auth.resetPasswordForEmail(user.email);
  };
  const changePassword = async (newPassword: string) => {
      if (currentUser && !currentUser.email) {
          await updateUser({ ...currentUser, password: newPassword });
          return;
      }
      await supabase.auth.updateUser({ password: newPassword });
  };
  const updateNotificationSettings = async (settings: NotificationSettings) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, notificationSettings: settings };
    setCurrentUser(updatedUser);
    if (localStorage.getItem('pampam_user')) {
        localStorage.setItem('pampam_user', JSON.stringify(updatedUser));
    }
    await supabase.from('user_profiles').update({ notificationSettings: settings }).eq('id', currentUser.id);
  };

  // ... (Product actions) ...
  const moveProduct = (barcode: string, newLocation: string, method: ShelfLog['method'] = 'SCAN') => {
    const product = products.find(p => p.barcode === barcode);
    if (!product) return { success: false, message: 'Product not found' };
    if (product.location === newLocation) return { success: true, message: 'Already at location' };
    const timestamp = getTimestamp();
    const updater = getUpdaterName();
    const updatedProduct = { ...product, location: newLocation, updatedAt: timestamp, updatedBy: updater };
    setProducts(prev => prev.map(p => p.id === product.id ? updatedProduct : p));
    supabase.from('products').update({ location: newLocation, updatedAt: timestamp, updatedBy: updater }).eq('id', product.id);
    return { success: true, message: `Moved ${product.name} to ${newLocation}` };
  };

  const addProduct = async (product: Product) => {
    const validId = ensureUUID(product.id);
    const productWithMeta = { ...product, id: validId, updatedAt: getTimestamp(), updatedBy: getUpdaterName() };
    setProducts(prev => [...prev, productWithMeta as Product]);
    await supabase.from('products').insert(productWithMeta);
  };
  const updateProduct = async (updatedProduct: Product, adjustmentReason?: string) => {
    const finalProduct = { ...updatedProduct, updatedAt: getTimestamp(), updatedBy: getUpdaterName() };
    setProducts(prev => prev.map(p => p.id === finalProduct.id ? finalProduct : p));
    await supabase.from('products').update(finalProduct).eq('id', finalProduct.id);
  };
  const deleteProduct = async (id: string) => {
      setProducts(prev => prev.filter(p => p.id !== id));
      await supabase.from('products').delete().eq('id', id);
  };
  
  // --- Distribution Orders ---
  const addDistributionOrder = async (order: DistributionOrder) => {
      setDistributionOrders(prev => [order, ...prev]);
      const { error } = await supabase.from('distribution_orders').insert(order);
      if (error) console.error("Error adding order:", error);
      return order;
  };
  
  const bulkAddDistributionOrders = async (orders: DistributionOrder[]) => {
      setDistributionOrders(prev => [...orders, ...prev]);
      await supabase.from('distribution_orders').insert(orders);
  };

  const updateDistributionOrder = async (order: DistributionOrder) => {
      // Optimistic update
      setDistributionOrders(prev => prev.map(o => o.id === order.id ? order : o));
      
      const { error } = await supabase.from('distribution_orders').update(order).eq('id', order.id);
      
      if (error && !isOfflineError(error)) {
          console.error("Update Distribution Order failed:", error);
          // Optional: You could implement rollback logic here if needed
          addNotification('error', 'Update Failed', 'Failed to save changes to the database.');
      }
  };

  const deleteDistributionOrder = async (id: string) => {
      setDistributionOrders(prev => prev.filter(o => o.id !== id));
      await supabase.from('distribution_orders').delete().eq('id', id);
  };
  const approveDistributionOrder = (id: string) => {
      const updates = { status: 'Approved' as const };
      setDistributionOrders(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
      supabase.from('distribution_orders').update(updates).eq('id', id);
  };
  
  const startPicking = async (orderId: string) => {
      const order = distributionOrders.find(o => o.id === orderId);
      if (!order) return { success: false, message: 'Not found' };
      if (order.pickedByUserId && order.pickedByUserId !== currentUser?.id) return { success: false, message: 'Locked by other' };
      
      const updates = { status: 'Picking' as const, pickedByUserId: currentUser?.id, pickedByName: currentUser?.name };
      
      // Optimistic update
      setDistributionOrders(prev => prev.map(o => o.id === orderId ? { ...o, ...updates } : o));
      
      const { error } = await supabase.from('distribution_orders').update(updates).eq('id', orderId);
      if (error) {
          console.error("Failed to start picking", error);
          return { success: false, message: error.message };
      }
      
      addTask(`Pick Order: ${order.orderNumber}`, undefined, 'HIGH', orderId);
      return { success: true, message: 'Started' };
  };
  
  const completePicking = async (orderId: string, status: 'Pick Complete' | 'Discrepancy', items: DistributionOrderItem[]) => {
      const updates = { status, pickedByUserId: null, pickedByName: null, pickedCompletedBy: currentUser?.name, items };
      
      // Optimistic update
      setDistributionOrders(prev => prev.map(o => o.id === orderId ? { ...o, ...updates } : o));
      
      const { error } = await supabase.from('distribution_orders').update(updates).eq('id', orderId);
      
      if (error) {
          console.error("Failed to complete picking:", error);
          // Rollback optimistic update if needed
          return { success: false, message: error.message };
      }

      const task = tasks.find(t => t.relatedOrderId === orderId && !t.isCompleted);
      if (task) toggleTaskCompletion(task.id);
      
      return { success: true };
  };

  // ... (Other functions: purchase orders, receiving, tasks, warehouse, adjustment, etc. - Keep existing) ...
  const addPurchaseOrder = async (order: PurchaseOrder) => {
      setPurchaseOrders(prev => [order, ...prev]);
      await supabase.from('purchase_orders').insert(order);
  };
  const updatePurchaseOrder = async (order: PurchaseOrder) => {
      setPurchaseOrders(prev => prev.map(o => o.id === order.id ? order : o));
      await supabase.from('purchase_orders').update(order).eq('id', order.id);
  };
  const deletePurchaseOrder = async (id: string) => {
      setPurchaseOrders(prev => prev.filter(o => o.id !== id));
      await supabase.from('purchase_orders').delete().eq('id', id);
  };

  const addReceivingOrder = (order: Omit<ReceivingOrder, 'id' | 'createTime' | 'modificationTime' | 'reviewStatus'>) => {
      const newOrder = { ...order, id: crypto.randomUUID(), createTime: getTimestamp(), modificationTime: getTimestamp(), reviewStatus: 'PENDING', orderStatus: 'Pending', creator: getUpdaterName() } as ReceivingOrder;
      setReceivingOrders(prev => [newOrder, ...prev]);
      supabase.from('receiving_orders').insert(newOrder);
  };
  const updateReceivingOrder = (order: ReceivingOrder) => {
      setReceivingOrders(prev => prev.map(o => o.id === order.id ? order : o));
      supabase.from('receiving_orders').update(order).eq('id', order.id);
  };
  const deleteReceivingOrder = (id: string) => {
      setReceivingOrders(prev => prev.filter(o => o.id !== id));
      supabase.from('receiving_orders').delete().eq('id', id);
  };
  const approveReceivingOrder = (id: string) => {
      const now = getTimestamp();
      updateReceivingOrder({ ...receivingOrders.find(o=>o.id===id)!, reviewStatus: 'APPROVED', reviewer: getUpdaterName(), reviewTime: now, orderStatus: 'Received' });
  };
  const rejectReceivingOrder = (id: string) => {
      const now = getTimestamp();
      updateReceivingOrder({ ...receivingOrders.find(o=>o.id===id)!, reviewStatus: 'REJECTED', reviewer: getUpdaterName(), reviewTime: now });
  };
  const undoReceivingOrder = (id: string) => {
      updateReceivingOrder({ ...receivingOrders.find(o=>o.id===id)!, reviewStatus: 'PENDING', reviewer: undefined, reviewTime: undefined, orderStatus: 'Pending' });
  };
  const bulkImportReceivingOrders = (orders: ReceivingOrder[]) => setReceivingOrders(prev => [...orders, ...prev]);

  const addTask = async (title: string, dueDate?: string, priority: 'HIGH' | 'MEDIUM' | 'LOW' = 'MEDIUM', relatedOrderId?: string) => {
      const newTask: Task = { id: crypto.randomUUID(), title, isCompleted: false, dueDate, priority, createdAt: getTimestamp(), relatedOrderId };
      setTasks(prev => [newTask, ...prev]);
      await supabase.from('tasks').insert(newTask);
  };
  const toggleTaskCompletion = async (id: string) => {
      const task = tasks.find(t => t.id === id);
      if(task) {
          const newVal = !task.isCompleted;
          setTasks(prev => prev.map(t => t.id === id ? { ...t, isCompleted: newVal } : t));
          await supabase.from('tasks').update({ isCompleted: newVal }).eq('id', id);
      }
  };
  const deleteTask = async (id: string) => { setTasks(prev => prev.filter(t => t.id !== id)); await supabase.from('tasks').delete().eq('id', id); };
  
  const addWarehouse = async (wh: Omit<Warehouse, 'id'>) => {
      const newWh = { ...wh, id: crypto.randomUUID(), status: 'ACTIVE' } as Warehouse;
      setWarehouses(prev => [...prev, newWh]);
      await supabase.from('warehouses').insert(newWh);
  };
  const updateWarehouse = async (id: string, updates: Partial<Warehouse>) => {
      setWarehouses(prev => prev.map(w => w.id === id ? { ...w, ...updates } : w));
      await supabase.from('warehouses').update(updates).eq('id', id);
  };
  const deleteWarehouse = async (id: string) => {
      setWarehouses(prev => prev.filter(w => w.id !== id));
      await supabase.from('warehouses').delete().eq('id', id);
  };

  // Shelf Lanes Persistence
  const addShelfLane = async (lane: ShelfLane) => {
      // Ensure unique ID if not present
      const laneWithId = { ...lane, id: lane.id || crypto.randomUUID() };
      setShelfLanes(prev => [...prev, laneWithId]);
      await supabase.from('shelf_lanes').insert(laneWithId);
  };

  const updateShelfLane = async (updatedLane: ShelfLane) => {
      setShelfLanes(prev => prev.map(l => l.id === updatedLane.id ? updatedLane : l));
      await supabase.from('shelf_lanes').update(updatedLane).eq('id', updatedLane.id);
  };

  const deleteShelfLane = async (id: string) => {
      setShelfLanes(prev => prev.filter(l => l.id !== id));
      await supabase.from('shelf_lanes').delete().eq('id', id);
  };

  const createAdjustmentBill = async (items: AdjustmentItem[], note?: string, status: AdjustmentStatus = 'PENDING') => {
      const newBill: AdjustmentBill = { id: crypto.randomUUID(), serialNumber: `ADJ-${Date.now()}`, createdAt: getTimestamp(), createdBy: getUpdaterName(), items, note, status };
      setAdjustmentBills(prev => [newBill, ...prev]);
      await supabase.from('adjustment_bills').insert(newBill);
  };
  const approveAdjustmentBill = async (id: string) => {
      const bill = adjustmentBills.find(b => b.id === id);
      if(bill) {
          setAdjustmentBills(prev => prev.map(b => b.id === id ? { ...b, status: 'APPROVED', reviewedBy: getUpdaterName(), reviewedAt: getTimestamp() } : b));
          await supabase.from('adjustment_bills').update({ status: 'APPROVED' }).eq('id', id);
          bill.items.forEach(item => {
              const p = products.find(prod => prod.id === item.productId);
              if(p) updateProduct({ ...p, stock: item.actualStock }, `Adjustment ${bill.serialNumber}`);
          });
      }
  };
  const rejectAdjustmentBill = async (id: string) => {
      setAdjustmentBills(prev => prev.map(b => b.id === id ? { ...b, status: 'REJECTED' } : b));
      await supabase.from('adjustment_bills').update({ status: 'REJECTED' }).eq('id', id);
  };

  const bulkUpsertProducts = async (newProducts: Partial<Product>[]) => {
      const sanitized = newProducts.map(p => ({ ...p, id: p.id || crypto.randomUUID() }));
      setProducts(prev => [...prev, ...sanitized as Product[]]);
  };
  const bulkUpdateProducts = async (ids: string[], updates: Partial<Product>) => {
      setProducts(prev => prev.map(p => ids.includes(p.id) ? { ...p, ...updates } : p));
  };
  const adjustProductStock = (productId: string, newStock: number, reason: string) => {
      const p = products.find(prod => prod.id === productId);
      if(p) updateProduct({ ...p, stock: newStock }, reason);
  };

  const updateRoleConfig = async (role: string, config: RoleConfig) => {
      setRoleConfigs(prev => ({ ...prev, [role]: config }));
      await supabase.from('role_configs').upsert({ role, config });
  };
  const addRole = async (roleName: string, description: string) => {
      const newConfig = generateDefaultConfig('USER');
      newConfig.metadata = { description, isCustom: true, color: 'bg-indigo-600' };
      setRoleConfigs(prev => ({ ...prev, [roleName]: newConfig }));
      await supabase.from('role_configs').upsert({ role: roleName, config: newConfig });
  };

  // ... rest of context
  const searchProduct = (query: string) => products.find(p => p.barcode === query || p.sku === query);
  const getLatestShelfLog = (productId: string) => shelfLogs.find(log => log.productId === productId);

  const checkPermission = (scope: string, action: 'create' | 'read' | 'edit' | 'delete' | 'approve' | 'reject' | 'undo' | 'special', specialActionKey?: string): boolean => {
      if (!currentUser) return false;
      const config = roleConfigs[currentUser.role];
      if (!config) return false;
      if (action === 'special' && specialActionKey) return !!config.actions[specialActionKey];
      const objectPerm = config.objects[scope];
      if (!objectPerm) return currentUser.role === 'ADMIN'; 
      return !!objectPerm[action as keyof PermissionObject];
  };

  const addDiscrepancyReport = async (report: DiscrepancyReport) => {
      setDiscrepancyReports(prev => [report, ...prev]);
      await supabase.from('discrepancy_reports').insert(report);
  };

  const updateDiscrepancyReport = async (report: DiscrepancyReport) => {
      setDiscrepancyReports(prev => prev.map(r => r.id === report.id ? report : r));
      await supabase.from('discrepancy_reports').update(report).eq('id', report.id);
  };

  const addOutlet = async (outlet: Omit<DistributionOutlet, 'id'>) => {
      const newOutlet = { ...outlet, id: crypto.randomUUID() };
      setOutlets(prev => [newOutlet, ...prev]);
      await supabase.from('outlets').insert(newOutlet);
  };

  const bulkAddOutlets = async (newOutlets: Omit<DistributionOutlet, 'id'>[]) => {
      const formatted = newOutlets.map(o => ({ ...o, id: crypto.randomUUID() }));
      setOutlets(prev => [...formatted, ...prev]);
      await supabase.from('outlets').insert(formatted);
  };

  const updateOutlet = async (outlet: DistributionOutlet) => {
      setOutlets(prev => prev.map(o => o.id === outlet.id ? outlet : o));
      await supabase.from('outlets').update(outlet).eq('id', outlet.id);
  };

  const deleteOutlet = async (id: string) => {
      setOutlets(prev => prev.filter(o => o.id !== id));
      await supabase.from('outlets').delete().eq('id', id);
  };

  const updateDriver = async (id: string, data: Partial<Driver>) => {
      setRawDriverDetails(prev => {
          const existing = prev.find(d => d.id === id);
          if (existing) {
              return prev.map(d => d.id === id ? { ...d, ...data } : d);
          }
          return [...prev, { id, ...data } as Driver];
      });
      
      const { data: existing } = await supabase.from('drivers').select('*').eq('id', id).single();
      if (existing) {
          await supabase.from('drivers').update(data).eq('id', id);
      } else {
          await supabase.from('drivers').insert({ id, ...data });
      }
  };

  const assignDriverToOrders = async (orderIds: string[], driverId: string, note?: string) => {
      const updates = { 
          assignedDriverId: driverId, 
          driverNote: note,
          assignedAt: getTimestamp(),
          status: 'Ready to Ship' as const
      };
      
      setDistributionOrders(prev => prev.map(o => orderIds.includes(o.id) ? { ...o, ...updates } : o));
      await supabase.from('distribution_orders').update(updates).in('id', orderIds);
  };

  const unassignDriverFromOrder = async (orderId: string) => {
      const updates = { 
          assignedDriverId: null, 
          driverNote: null,
          assignedAt: null,
          status: 'Approved' as const
      };
      setDistributionOrders(prev => prev.map(o => o.id === orderId ? { ...o, ...updates } : o));
      await supabase.from('distribution_orders').update(updates).eq('id', orderId);
  };

  const bulkImportInventory = async (items: InventoryItem[], mode: 'MERGE' | 'REPLACE') => {
      if (mode === 'REPLACE') {
          // In a real app, you might delete existing inventory for these products first
          // For now, we'll just upsert
      }
      setInventory(prev => {
          const newInv = [...prev];
          items.forEach(newItem => {
              const existingIdx = newInv.findIndex(i => i.productCode === newItem.productCode && i.location === newItem.location);
              if (existingIdx >= 0) {
                  if (mode === 'MERGE') {
                      newInv[existingIdx].quantity += newItem.quantity;
                  } else {
                      newInv[existingIdx] = newItem;
                  }
              } else {
                  newInv.push(newItem);
              }
          });
          return newInv;
      });
      
      // Sync to DB
      await supabase.from('inventory').upsert(items);
  };

  const stats: DashboardStats = {
    totalProducts: products.length,
    lowStockItems: products.filter(p => p.stock < 20).length,
    totalInboundToday: transactions.filter(t => t.type === 'INBOUND' && new Date(t.timestamp).toDateString() === new Date().toDateString()).length, 
    totalOutboundToday: transactions.filter(t => t.type === 'OUTBOUND' && new Date(t.timestamp).toDateString() === new Date().toDateString()).length, 
    warehouseCapacity: 78, 
  };

  return (
    <InventoryContext.Provider value={{ 
      products, transactions, shelfLogs, stats, currentUser, users, adjustmentBills, tasks, warehouses, roleConfigs, theme, receivingOrders, distributionOrders, purchaseOrders, drivers, outlets, appNotifications, inventory, discrepancyReports, language, shelfLanes, lastSynced,
      moveProduct, searchProduct, addProduct, updateProduct, adjustProductStock, deleteProduct,
      bulkUpsertProducts, bulkUpdateProducts, createAdjustmentBill, approveAdjustmentBill, rejectAdjustmentBill, getLatestShelfLog,
      addReceivingOrder, approveReceivingOrder, bulkImportReceivingOrders, rejectReceivingOrder, undoReceivingOrder, deleteReceivingOrder, updateReceivingOrder,
      addDistributionOrder, bulkAddDistributionOrders, updateDistributionOrder, deleteDistributionOrder, approveDistributionOrder, startPicking, completePicking,
      addPurchaseOrder, updatePurchaseOrder, deletePurchaseOrder,
      addOutlet, bulkAddOutlets, updateOutlet, deleteOutlet, updateDriver, assignDriverToOrders, unassignDriverFromOrder,
      addTask, toggleTaskCompletion, deleteTask, addWarehouse, updateWarehouse, deleteWarehouse,
      login, logout, addUser, updateUser, deleteUser, resetPassword, changePassword,
      updateRoleConfig, addRole, checkPermission, setGlobalTheme, updateNotificationSettings, setGlobalLanguage,
      addNotification, dismissAppNotification, refreshData,
      addDiscrepancyReport, updateDiscrepancyReport, bulkImportInventory,
      addShelfLane, updateShelfLane, deleteShelfLane
    }}>
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (context === undefined) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};
